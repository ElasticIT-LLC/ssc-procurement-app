# ElasticIT UI Kit — CLAUDE.md

Published as `@elasticit-llc/ui-kit` **v0.5.4** — React component library + design token system for ElasticIT client portals.

For the full architecture and examples, see [README.md](README.md), [docs/tokens.md](docs/tokens.md), [docs/brand-json.md](docs/brand-json.md), and [docs/migration-guide.md](docs/migration-guide.md).

## Critical Rules

### DO
- Use **semantic tokens** — `bg-card`, `text-foreground`, `bg-primary`, `text-muted-foreground`, `border-border`, etc. (see [tokens.md](docs/tokens.md))
- Use **chrome tokens** (`bg-chrome-bg`, `text-chrome-foreground`, `bg-chrome-active-bg`) for shell chrome only (sidebar/topbar) — they stay dark always
- Use **status tokens** (`bg-success`, `bg-warning`, `bg-danger`, `bg-info`) for semantic status indicators, optionally with opacity (`bg-warning/15`)
- Let the `brandCompiler` generate the brand-* spectrum — a client supplies one `primary` hex and gets 50-900 shades

### DO NOT
- **Hardcode hex colors** — `bg-[#3b82f6]`, `style={{ color: '#abc' }}`, etc. They lock the bundle to one client's palette
- **Use raw Tailwind palettes** — `bg-gray-800`, `text-slate-500`, `bg-amber-100` — they don't flip in light mode. Use semantic equivalents instead
- **Use legacy `shell-*` tokens in new code** — `bg-shell-800`, `text-shell-100` still work via compatibility aliases but are deprecated
- **Import Supabase, app-bridge, or shell dependencies** — this is a pure UI + token library
- **Add animation libraries** — keep the bundle light; use CSS transitions

## Token System (summary)

Three layers, compiled into a Tailwind v4 `@theme` block by `brandCompiler`:

1. **Defaults** (in ui-kit) — neutral palette, typography, radii, shadows, motion, z-index
2. **Brand overrides** (per-client `brand.json`) — brand/secondary colors, fonts, optional chrome overrides
3. **User preference** (runtime) — `.light` / `.dark` class on `<html>` flips only content-area tokens

**Chrome tokens stay dark** regardless of the user's toggle — sidebar/topbar chrome doesn't change. **Content tokens flip** between dark and light values based on the class.

Full reference: [docs/tokens.md](docs/tokens.md).

## Component Reference

All components use semantic tokens under the hood and work in both modes. Props that accept Tailwind class strings (like `valueColor`) should use semantic tokens, not literal colors.

### KPICard

```tsx
import { KPICard } from '@elasticit-llc/ui-kit'

<KPICard
  label="Total Printers"
  value={142}
  detail="12 offline"
  icon={<PrinterIcon />}
  trend="+8%"
  trendDirection="up"
  valueColor="text-primary"
/>
```

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `label` | `string` | required | Label text (uppercase, `text-muted-foreground`) |
| `value` | `string \| number` | required | Primary display value |
| `detail?` | `string` | — | Secondary detail text |
| `icon?` | `ReactNode` | — | Icon in top-right (rounded box) |
| `trend?` | `string` | — | Trend text (e.g., "+8%") |
| `trendDirection?` | `'up' \| 'down' \| 'neutral'` | `'neutral'` | Colors trend green/red/muted |
| `valueColor?` | `string` | `'text-foreground'` | Tailwind class (prefer semantic) |

### DataTable

```tsx
import { DataTable, type Column } from '@elasticit-llc/ui-kit'

const columns: Column<Printer>[] = [
  { key: 'name', header: 'Name', sortable: true },
  { key: 'status', header: 'Status', render: (val) => (
    <StatusBadge status={val} variant={val === 'online' ? 'success' : 'error'} />
  ) },
]

<DataTable
  columns={columns}
  data={printers}
  searchable
  onExportCSV={() => exportCsv(printers, columns, 'printers.csv')}
/>
```

| Prop | Type | Default |
|------|------|---------|
| `columns` | `Column<T>[]` | required |
| `data` | `T[]` | required |
| `searchable?` | `boolean` | `false` |
| `searchPlaceholder?` | `string` | `'Search...'` |
| `emptyMessage?` | `string` | `'No data'` |
| `pageSize?` | `number` | `25` |
| `onExportCSV?` | `() => void` | — |

### StatusBadge

```tsx
<StatusBadge status="Connected" variant="success" />
<StatusBadge status="Pending" variant="warning" />
<StatusBadge status="Offline" variant="error" />
<StatusBadge status="N/A" variant="neutral" />
```

Variants: `success` | `warning` | `error`/`danger` | `info` | `default`/`neutral`. Each maps to the corresponding semantic token (`bg-success/15 text-success`, etc.).

### Chart

Recharts wrapper for bar/line/area/pie. Uses `brand-*` and `secondary-*` palette tokens for categorical series (so the chart re-skins per client automatically).

```tsx
<Chart type="bar" data={monthlyData} xKey="month" yKey="revenue" height={300} />
<Chart type="line" data={data} xKey="date" yKey={['actual', 'budget']} height={400} />
```

| Prop | Type | Default |
|------|------|---------|
| `type` | `'bar' \| 'line' \| 'area' \| 'pie'` | required |
| `data` | `Record<string, unknown>[]` | required |
| `xKey` | `string` | required |
| `yKey` | `string \| string[]` | required |
| `height?` | `number` | `300` |

### ReportPage

Report layout wrapper with title, description, export buttons, action slot.

```tsx
<ReportPage
  title="Fleet Report"
  description="Monthly printer fleet analysis"
  onExportCSV={() => exportCsv(data, columns, 'fleet.csv')}
  onExportPDF={() => generatePdf()}
  action={<DateRangePicker />}
>
  {/* content */}
</ReportPage>
```

### CardContainer

Card wrapper (`bg-card text-card-foreground border border-border`) with optional header.

```tsx
<CardContainer title="Connection Status" action={<RefreshButton />}>
  <ConnectionList />
</CardContainer>
```

### EmptyState

Centered empty data state.

```tsx
<EmptyState
  icon={<DatabaseIcon className="w-8 h-8" />}
  title="No data available"
  description="Connect QBO entities to generate reports"
  action={<button className="bg-primary text-primary-foreground px-4 py-2 rounded-md">Go to Connections</button>}
/>
```

### PageHeader

Page title with brand accent line and optional action slot.

```tsx
<PageHeader title="Printer Fleet" description="Manage and monitor all printers" action={<button>Add Printer</button>} />
```

### Skeleton / LoadingSkeleton

```tsx
<Skeleton className="h-8 w-full" />
<LoadingSkeleton variant="table" rows={6} />
<LoadingSkeleton variant="card" rows={3} />
<LoadingSkeleton variant="text" rows={4} />
```

### exportCsv()

```tsx
exportCsv(data, [{ key: 'name', header: 'Name' }, ...], 'my-export.csv')
```

Handles comma/quote escaping. Creates a Blob, triggers download.

## brandCompiler Vite plugin

See [docs/brand-json.md](docs/brand-json.md) for the full schema.

```ts
// client-shell/vite.config.ts
import { brandCompiler } from '@elasticit-llc/ui-kit/vite'

export default defineConfig({
  plugins: [brandCompiler(), react(), tailwindcss()],
})
```

Emits:
- `src/generated-brand.css` — Tailwind v4 `@theme` block + `:where(.light)` override block
- `src/generated-brand.ts` — typed `BrandConfig` export (logo paths, client name, mode, etc.)
- `<link>` tags for favicon + Google Fonts (via `transformIndexHtml`)

Watches `brand.json` and triggers a full-reload on save.

## Integration

### For app developers

1. `npm install @elasticit-llc/ui-kit recharts`
2. Import components: `import { KPICard, DataTable } from '@elasticit-llc/ui-kit'`
3. Use semantic tokens in your own components so your app flips in light mode
4. The client shell's CSS build scans ui-kit's `dist/` for Tailwind classes

### For client shells

Add `@source` directive in `src/index.css`:

```css
@import 'tailwindcss';
@import './generated-brand.css';

@source "../node_modules/@elasticit-llc/ui-kit/dist/**/*.js";
@source "../node_modules/@elasticit-llc/printix-app/dist/**/*.js";
/* …@source lines for every installed app */
```

## Key Files

| File | Purpose |
|------|---------|
| `src/index.ts` | Barrel export (10 components + exportCsv) |
| `src/tokens/defaults.ts` | Neutral palette, typography, radii, shadows, motion, z-index defaults + chrome/content token definitions |
| `src/tokens/schema.ts` | Zod schema for `brand.json` |
| `src/tokens/spectrum.ts` | Auto-generates brand 50-900 from a single hex via HSL |
| `src/tokens/generate-css.ts` | Compiles a `BrandConfig` into a Tailwind v4 `@theme` block + `:where(.light)` overrides |
| `src/vite/brandCompiler.ts` | Vite plugin — reads `brand.json`, writes `generated-brand.{css,ts}`, injects favicon + Google Fonts |
| `src/KPICard.tsx`, `src/DataTable.tsx`, etc. | Component implementations |
| `src/export-csv.ts` | CSV export utility |

## Versioning (SemVer)

`@elasticit-llc/ui-kit` follows **Semantic Versioning** — `MAJOR.MINOR.PATCH`. Its public API — **every exported component, its props, the `exportCsv` util, the `brandCompiler` plugin, and the public token names** (semantic/chrome/status tokens consumers reference) — is consumed by every app and client shell. Renaming or removing a component, prop, or token ripples to all of them.

| Segment | Bump when | Example |
|---------|-----------|---------|
| **MAJOR** | Backwards-**incompatible** change — removing/renaming a component, prop, or public token; changing a prop's type or required-ness; renaming a `@theme` token | `1.2.0 → 2.0.0` |
| **MINOR** | Backwards-**compatible** new feature — a new component, a new optional prop, or a new token | `0.5.4 → 0.6.0` |
| **PATCH** | Backwards-**compatible** styling/bug fix — no API or token change | `0.5.4 → 0.5.5` |

Pre-1.0 (`0.y.z`): treat MINOR (`y`) as the breaking segment, PATCH (`z`) as feature + fix.

**Breaking changes must be DELIBERATE, DOCUMENTED, and version-signaled — never slipped into a `feat`/`fix` commit.** Before `npm publish`, diff the public surface (`src/index.ts` exports + each component's props + the token names in `src/tokens/defaults.ts`): if any export, prop, or token name was removed or renamed, it's **breaking** — bump accordingly and call it out. (Lesson from `@elasticit-llc/app-bridge@0.8.0`, where an accidentally-dropped `ProxyClient` option silently broke a consumer in prod — see that repo's `CLAUDE.md`.)

## Commands

```bash
npm install
npm run build      # Vite library build (ESM + CJS + types)
npm test
npm publish        # GitHub Packages, on version bump
```

## Architecture

- **Pure UI + token library** — no auth, no data fetching, no shell dependencies
- **Peer deps**: react, react-dom, recharts
- Components emit Tailwind class strings against semantic tokens; the client's compiled `generated-brand.css` provides concrete values
- Same bundle re-skins per client just by changing `brand.json`
- Builds to `dist/` in ESM (`index.js`) + CJS (`index.cjs`) with TypeScript declarations; exports map surfaces three paths: main (`.`), `/vite` (brand compiler plugin), `/tokens` (runtime types)

## AI Tooling

### Active hooks
- **Pre-commit guard**: blocks commits with secrets (`.env`, credentials) and TypeScript errors
- **Color token validation** (ui-kit only): warns about hardcoded colors in TSX files

### Common mistakes to avoid
- Using raw Tailwind palettes (`bg-gray-800`, `text-slate-500`) instead of semantic tokens
- Hardcoding hex colors in `className="bg-[#...]"` or inline `style`
- Putting `react` or `recharts` in `dependencies` instead of `peerDependencies`
- Forgetting to update barrel exports in `src/index.ts` when adding new components
- Confusing chrome tokens (always dark) with content tokens (flip with user toggle) — chrome is for sidebar/topbar only
- **Shipping a breaking API change (removed/renamed component, prop, or token) as a MINOR/PATCH** — see **[Versioning (SemVer)](#versioning-semver)**. Breaking = MAJOR (MINOR pre-1.0), and must be deliberate + documented.
