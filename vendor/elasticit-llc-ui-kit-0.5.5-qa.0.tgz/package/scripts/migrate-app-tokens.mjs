#!/usr/bin/env node
// Migration: replaces legacy shell-* / brand-* / raw Tailwind palette tokens
// with semantic tokens (card, muted, accent, foreground, primary, success, etc.)
// across all .ts/.tsx files in a given src/ directory.
//
// Usage:
//   node scripts/migrate-app-tokens.mjs <path-to-app-src>                # apply
//   node scripts/migrate-app-tokens.mjs <path-to-app-src> --dry-run     # preview
//   node scripts/migrate-app-tokens.mjs <path-to-app-src> --dry-run -v  # verbose, show diffs
//
// Design notes:
// - Patterns are ordered longest-first so specific patterns match before generics.
// - Compound patterns (e.g. bg-green-900/30 text-green-300) run first so we don't
//   half-match and leave orphans.
// - Raw Tailwind palette fallback (bg-<palette>-<shade>) is conservative: we map
//   by semantic intent (amber/yellow=warning, emerald/green=success, red=danger,
//   blue=info, teal=primary, slate/gray=muted). Opacity modifiers are preserved.
// - Chart fills via inline hex / recharts props are OUT of scope — regex doesn't
//   match those (they're prop values, not className tokens).
// - SVG stroke/fill with hex colors also out of scope.

import { readFileSync, writeFileSync, statSync, readdirSync } from 'node:fs'
import { join, resolve } from 'node:path'

const args = process.argv.slice(2)
const target = args.find((a) => !a.startsWith('--'))
const dryRun = args.includes('--dry-run')
const verbose = args.includes('-v') || args.includes('--verbose')

if (!target) {
  console.error('Usage: node migrate-app-tokens.mjs <path-to-app-src> [--dry-run] [-v]')
  process.exit(1)
}

// Palette → semantic intent mapping. Used to generate the broad fallback rules.
// Leaves categorical chart colors alone (e.g., distinct hues for 6 series).
const PALETTE_INTENT = {
  // Positive / success
  emerald: 'success',
  green: 'success',
  lime: 'success',
  // Warning
  amber: 'warning',
  yellow: 'warning',
  orange: 'warning',
  // Danger
  red: 'danger',
  rose: 'danger',
  // Info / primary-adjacent
  blue: 'info',
  sky: 'info',
  cyan: 'info',
  indigo: 'info',
  violet: 'info',
  purple: 'info',
  fuchsia: 'info',
  pink: 'info',
  // Neutral surfaces
  slate: 'muted',
  gray: 'muted',
  zinc: 'muted',
  neutral: 'muted',
  stone: 'muted',
  teal: 'primary',
}

// Build palette patterns dynamically. Two shapes:
// 1. bg/border/ring with tint → semantic bg with /15 opacity (for tints <400)
//    or solid semantic (for shades 400-700).
// 2. text-<palette>-<shade> → text-semantic (always solid).
// Shades 800-950 are dark — we map them to the semantic solid as well (rare).
const PALETTE_PATTERNS = []
for (const [palette, intent] of Object.entries(PALETTE_INTENT)) {
  const semanticBg = intent === 'muted' ? 'muted' : intent
  const semanticText = intent === 'muted' ? 'muted-foreground' : intent
  const semanticBorder = intent === 'muted' ? 'border' : intent
  const semanticRing = intent === 'muted' ? 'border' : intent

  // bg-<palette>-<shade>/<opacity> → bg-semantic with opacity preserved
  // (Mostly matches bg-amber-100/50 style)
  PALETTE_PATTERNS.push([
    new RegExp(`\\bbg-${palette}-([0-9]+)\\/([0-9]+)\\b`, 'g'),
    `bg-${semanticBg}/$2`,
  ])
  // bg-<palette>-<shade> (no opacity) → bg-semantic (solid for 400-700, /15 tint for <400, /25 for 800-950)
  PALETTE_PATTERNS.push([
    new RegExp(`\\bbg-${palette}-(50|100|200|300)\\b`, 'g'),
    `bg-${semanticBg}/15`,
  ])
  PALETTE_PATTERNS.push([
    new RegExp(`\\bbg-${palette}-(400|500|600|700)\\b`, 'g'),
    `bg-${semanticBg}`,
  ])
  PALETTE_PATTERNS.push([
    new RegExp(`\\bbg-${palette}-(800|900|950)\\b`, 'g'),
    `bg-${semanticBg}/25`,
  ])

  // text-<palette>-<shade>
  PALETTE_PATTERNS.push([
    new RegExp(`\\btext-${palette}-[0-9]+\\b`, 'g'),
    `text-${semanticText}`,
  ])

  // border-<palette>-<shade>/<opacity>
  PALETTE_PATTERNS.push([
    new RegExp(`\\bborder-${palette}-([0-9]+)\\/([0-9]+)\\b`, 'g'),
    `border-${semanticBorder}/$2`,
  ])
  PALETTE_PATTERNS.push([
    new RegExp(`\\bborder-${palette}-[0-9]+\\b`, 'g'),
    `border-${semanticBorder}`,
  ])

  // ring-<palette>-<shade>/<opacity>
  PALETTE_PATTERNS.push([
    new RegExp(`\\bring-${palette}-([0-9]+)\\/([0-9]+)\\b`, 'g'),
    `ring-${semanticRing}/$2`,
  ])
  PALETTE_PATTERNS.push([
    new RegExp(`\\bring-${palette}-[0-9]+\\b`, 'g'),
    `ring-${semanticRing}`,
  ])

  // hover/focus/active variants
  for (const modifier of ['hover', 'focus', 'active']) {
    PALETTE_PATTERNS.push([
      new RegExp(`\\b${modifier}:bg-${palette}-[0-9]+\\b`, 'g'),
      `${modifier}:bg-${semanticBg}`,
    ])
    PALETTE_PATTERNS.push([
      new RegExp(`\\b${modifier}:text-${palette}-[0-9]+\\b`, 'g'),
      `${modifier}:text-${semanticText}`,
    ])
  }
}

// Ordered: compound (legacy) patterns first, then simple shell/brand, then raw palette.
const REPLACEMENTS = [
  // Brand compound patterns (must come before single-token brand patterns)
  [/\baccent-brand-500\b/g, 'accent-primary'],
  [/\bring-brand-500\b/g, 'ring-primary'],
  [/\bfocus:ring-brand-500\b/g, 'focus:ring-primary'],
  [/\bhover:border-brand-500\b/g, 'hover:border-primary'],
  [/\bhover:bg-brand-500\b/g, 'hover:bg-primary-hover'],
  [/\bhover:bg-brand-700\b/g, 'hover:bg-primary-hover'],
  [/\bhover:text-brand-300\b/g, 'hover:opacity-80'],
  [/\bhover:text-brand-400\b/g, 'hover:opacity-80'],
  [/\bbg-brand-500\b/g, 'bg-primary'],
  [/\bbg-brand-600\b/g, 'bg-primary'],
  [/\bbg-brand-700\b/g, 'bg-primary-hover'],
  [/\bbg-brand-800\b/g, 'bg-primary-hover'],
  [/\bbg-brand-900\/([0-9]+)\b/g, 'bg-primary/15'],
  [/\btext-brand-200\b/g, 'text-primary'],
  [/\btext-brand-300\b/g, 'text-primary'],
  [/\btext-brand-400\b/g, 'text-primary'],
  [/\btext-brand-500\b/g, 'text-primary'],
  [/\bborder-brand-500\b/g, 'border-primary'],
  [/\bborder-brand-400\b/g, 'border-primary'],

  // Shell surfaces
  [/\bbg-shell-950\b/g, 'bg-background'],
  [/\bbg-shell-900\b/g, 'bg-card'],
  [/\bbg-shell-800\b/g, 'bg-muted'],
  [/\bbg-shell-750\b/g, 'bg-muted'],
  [/\bbg-shell-700\b/g, 'bg-accent'],
  [/\bbg-shell-600\b/g, 'bg-accent'],

  // Shell text
  [/\btext-shell-50\b/g, 'text-foreground'],
  [/\btext-shell-100\b/g, 'text-foreground'],
  [/\btext-shell-200\b/g, 'text-foreground'],
  [/\btext-shell-300\b/g, 'text-foreground'],
  [/\btext-shell-400\b/g, 'text-muted-foreground'],
  [/\btext-shell-500\b/g, 'text-muted-foreground'],
  [/\btext-shell-600\b/g, 'text-muted-foreground'],
  [/\btext-shell-700\b/g, 'text-muted-foreground'],

  // Shell borders / dividers / rings
  [/\bborder-shell-600\b/g, 'border-input'],
  [/\bborder-shell-700\b/g, 'border-border'],
  [/\bborder-shell-800\b/g, 'border-border'],
  [/\bborder-shell-900\b/g, 'border-border'],
  [/\bdivide-shell-700\b/g, 'divide-border'],
  [/\bdivide-shell-800\b/g, 'divide-border'],
  [/\bring-shell-600\b/g, 'ring-border'],
  [/\bring-shell-700\b/g, 'ring-border'],
  [/\bring-shell-800\b/g, 'ring-border'],
  [/\bplaceholder-shell-500\b/g, 'placeholder-muted-foreground'],
  [/\bplaceholder-shell-400\b/g, 'placeholder-muted-foreground'],

  // Shell hovers
  [/\bhover:bg-shell-700\b/g, 'hover:bg-accent'],
  [/\bhover:bg-shell-800\b/g, 'hover:bg-muted'],
  [/\bhover:text-shell-100\b/g, 'hover:text-foreground'],
  [/\bhover:text-shell-200\b/g, 'hover:text-foreground'],

  // Legacy compound semantic patterns (must come before raw palette fallbacks)
  [/\bbg-green-900\/(\d+)\s+text-green-(300|400)\b/g, 'bg-success/15 text-success'],
  [/\bbg-red-900\/(\d+)\s+text-red-(300|400)\b/g, 'bg-danger/15 text-danger'],
  [/\bbg-yellow-900\/(\d+)\s+text-yellow-(300|400)\b/g, 'bg-warning/15 text-warning'],
  [/\bbg-amber-900\/(\d+)\s+text-amber-(300|400)\b/g, 'bg-warning/15 text-warning'],
  [/\bbg-blue-900\/(\d+)\s+text-blue-(300|400)\b/g, 'bg-info/15 text-info'],
  [/\bbg-purple-900\/(\d+)\s+text-purple-(300|400)\b/g, 'bg-info/15 text-info'],
  [/\bbg-orange-900\/(\d+)\s+text-orange-(300|400)\b/g, 'bg-warning/15 text-warning'],

  // Raw Tailwind palette fallback (auto-generated from PALETTE_INTENT above)
  ...PALETTE_PATTERNS,

  // White text on primary buttons → primary-foreground
  [/\bbg-primary\s+([^'"`]*?)\btext-white\b/g, 'bg-primary $1text-primary-foreground'],
]

const EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx'])

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry)
    const stat = statSync(full)
    if (stat.isDirectory()) {
      if (entry === 'node_modules' || entry === 'dist' || entry === '.git') continue
      walk(full, out)
    } else {
      const dot = entry.lastIndexOf('.')
      if (dot > -1 && EXTENSIONS.has(entry.slice(dot))) {
        out.push(full)
      }
    }
  }
  return out
}

const absTarget = resolve(target)
const files = walk(absTarget)
let filesChanged = 0
let totalReplacements = 0

console.log(`\n${dryRun ? '[DRY-RUN]' : '[APPLYING]'} ${files.length} files in ${absTarget}\n`)

for (const file of files) {
  const original = readFileSync(file, 'utf-8')
  let content = original
  let fileReplacements = 0
  const fileChanges = []

  for (const [pattern, replacement] of REPLACEMENTS) {
    const matches = [...content.matchAll(pattern)]
    if (matches.length === 0) continue

    if (verbose) {
      for (const match of matches) {
        fileChanges.push(`  ${match[0]} → ${replacement.replace(/\$(\d+)/g, (_, i) => match[i] ?? '')}`)
      }
    }

    content = content.replace(pattern, replacement)
    fileReplacements += matches.length
  }

  if (content !== original) {
    if (!dryRun) writeFileSync(file, content)
    filesChanged++
    totalReplacements += fileReplacements
    console.log(`${dryRun ? '  [would change]' : '  '} ${file.replace(absTarget, '.')}: ${fileReplacements} replacements`)
    if (verbose) {
      for (const change of fileChanges.slice(0, 10)) console.log(change)
      if (fileChanges.length > 10) console.log(`    ... and ${fileChanges.length - 10} more`)
    }
  }
}

console.log(`\n${dryRun ? '[DRY-RUN] Would change' : 'Done:'} ${filesChanged} files, ${totalReplacements} total replacements`)
if (dryRun) {
  console.log('Run without --dry-run to apply.')
}
