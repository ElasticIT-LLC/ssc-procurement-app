# brand.json — per-client branding config

Each client shell has a `brand.json` at its repo root. The `brandCompiler` Vite plugin reads it at build start and emits:

- `src/generated-brand.css` — Tailwind v4 `@theme` block + `:where(.light)` overrides
- `src/generated-brand.ts` — typed `BrandConfig` export (logo URLs, client name, mode default) for runtime use
- `<link>` tag injections into `index.html` for the favicon and Google Fonts

Every field except `clientId`, `clientName`, `branding`, and `theme.colors.brand.primary` is optional — clients override only what matters and inherit defaults for everything else.

## Full schema (TypeScript)

```ts
{
  $schema?: string            // Optional schema URL for IDE completion
  clientId: string            // Lowercase/hyphens only, e.g. "acme"
  clientName: string          // Full display name, e.g. "Acme Corp"

  mode?: {
    default?: 'dark' | 'light' | 'system'  // Default color mode, defaults to 'dark'
    userToggle?: boolean                   // Show toggle in topbar, defaults to true
  }

  branding: {
    logoFull?: string          // Wordmark logo URL (used in sidebar + login)
    logoIcon?: string          // Icon-only logo URL (used for compact sidebar)
    favicon?: string           // Favicon URL (injected as <link rel="icon">)
  }

  theme: {
    colors: {
      brand: {
        primary: string                    // Hex, e.g. "#3b82f6"
        spectrum?: { '50'?: string, ..., '900'?: string }  // Optional per-shade overrides
      }
      secondary?: {                        // Optional second accent
        primary: string
        spectrum?: { ... }
      }
      chrome?: {                           // Optional chrome overrides (sidebar/topbar)
        bg?: string                        // Hex or token ref (e.g. "neutral.800")
        foreground?: string
        muted?: string
        activeBg?: string
        activeForeground?: string
        border?: string
      }
    }
    typography?: {
      fontFamily?: {
        heading?: string                   // e.g. "'Inter', sans-serif"
        body?: string
        mono?: string
      }
      fontSources?: Array<{
        family: string                     // e.g. "Inter"
        weights?: number[]                 // e.g. [400, 500, 600]
        source?: 'google' | 'self-hosted' | 'system'
      }>
    }
  }

  supabase?: {
    urlEnv?: string            // Env var holding Supabase URL, defaults to VITE_SUPABASE_URL
    anonKeyEnv?: string        // Env var holding anon key, defaults to VITE_SUPABASE_ANON_KEY
  }
}
```

Validated at compile time via Zod (`src/tokens/schema.ts`). Invalid values fail the build with a helpful error.

## Minimum valid example

```json
{
  "clientId": "acme",
  "clientName": "Acme Corp",
  "branding": {
    "favicon": "/favicon.png"
  },
  "theme": {
    "colors": {
      "brand": { "primary": "#3b82f6" }
    }
  }
}
```

Everything else inherits ui-kit defaults. You'll get:
- Auto-generated brand 50-900 spectrum from `#3b82f6`
- Dark mode default with user toggle
- System sans-serif fonts
- Neutral-950 sidebar background

## Full example

This example shows every top-level field a brand.json can set. Substitute your own client id, name, brand hex, and font choices:

```jsonc
{
  "$schema": "https://elasticit.com/brand-schema-v1.json",
  "clientId": "acme",
  "clientName": "Acme Corp",

  "mode": {
    "default": "dark",
    "userToggle": true
  },

  "branding": {
    "logoFull": "/logo-wordmark.png",
    "logoIcon": "/logo-icon.png",
    "favicon": "/favicon.png"
  },

  "theme": {
    "colors": {
      "brand": { "primary": "#3b82f6" },            // Client's primary hex
      "secondary": { "primary": "#64748b" },         // Optional second accent
      "chrome": {
        "bg": "#1e293b",                             // Optional custom sidebar color
        "border": "#334155",
        "activeBg": "#3b82f6",
        "activeForeground": "#ffffff"
      }
    },
    "typography": {
      "fontFamily": {
        "heading": "'Inter', ui-sans-serif, system-ui, sans-serif",
        "body": "'Inter', ui-sans-serif, system-ui, sans-serif"
      },
      "fontSources": [
        { "family": "Inter", "weights": [400, 500, 600, 700], "source": "google" }
      ]
    }
  }
}
```

## Field reference

### `clientId` — required

Kebab-case identifier. Used internally and for diagnostics. Must match `^[a-z0-9-]+$`.

### `clientName` — required

Free-form display string. Shown on login page and in the browser tab title.

### `mode`

Controls the color-mode toggle behavior.

- `mode.default` — initial mode for users who haven't set a preference. Defaults to `"dark"`. `"system"` follows `prefers-color-scheme`.
- `mode.userToggle` — when `false`, hides the topbar sun/moon button and pins the shell to `mode.default`. Useful for clients who want a single enforced mode.

### `branding`

Paths to logo/favicon assets served from `public/`.

- `logoFull` — full wordmark (used by `LoginPage` and expanded `Sidebar`). Prefer transparent PNG or SVG that blends with the shell's dark background.
- `logoIcon` — icon-only version (used by collapsed sidebar).
- `favicon` — injected as `<link rel="icon" type="image/png" href="...">` during `transformIndexHtml`.

### `theme.colors.brand.primary` — required

Single hex value. The compiler generates a full 50-900 spectrum from this using HSL lightness steps (see `src/tokens/spectrum.ts`).

### `theme.colors.brand.spectrum` — optional

Override individual shades when the auto-generated palette doesn't match your brand guide. Any shade you omit uses the generator's output.

```json
{
  "brand": {
    "primary": "#3b82f6",
    "spectrum": {
      "500": "#3b82f6",   // Pin 500 to the exact primary
      "600": "#2563eb"    // Custom 600 instead of generated
    }
  }
}
```

### `theme.colors.secondary`

Optional second accent palette. Same shape as `brand`. Emits `--color-secondary-50` through `--color-secondary-900`.

### `theme.colors.chrome`

Override chrome token values. Accepts hex literals or token references (e.g. `"neutral.800"` → `var(--color-neutral-800)`). Keys map to chrome tokens:

| Key | Token |
|-----|-------|
| `bg` | `--color-chrome-bg` |
| `foreground` | `--color-chrome-foreground` |
| `muted` | `--color-chrome-muted` |
| `activeBg` | `--color-chrome-active-bg` |
| `activeForeground` | `--color-chrome-active-foreground` |
| `border` | `--color-chrome-border` |

### `theme.typography.fontFamily`

Any CSS `font-family` value. Include fallbacks.

### `theme.typography.fontSources`

Tells the compiler which fonts to pre-load. For `source: "google"`, the plugin injects `<link rel="preconnect">` + `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?...&display=swap">`. For `source: "self-hosted"` or `"system"`, nothing is injected (you're responsible for loading them yourself).

```json
{
  "fontSources": [
    { "family": "Inter", "weights": [400, 600], "source": "google" }
  ]
}
```

### `supabase`

Names of env vars holding your Supabase URL + anon key. The generated TS config exposes these to shell runtime code so it knows where to fetch from.

## Hot-reload

The plugin watches `brand.json` and triggers a full-reload on save, so tweaking brand colors in dev mode is instant.

## Regenerating

Generated files are re-written on every build and on every save of `brand.json`. You can safely delete them — they'll regenerate on the next `vite dev` or `vite build`.
