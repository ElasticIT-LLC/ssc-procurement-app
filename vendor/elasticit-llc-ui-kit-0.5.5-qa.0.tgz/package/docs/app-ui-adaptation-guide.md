# App UI Adaptation Guide

How to build an ElasticIT portal app that adapts cleanly to any client shell's UI design.

> **Target reader:** app developer (EIT or client). You write a React app that gets loaded by the shell as either a compile-time npm dep or a runtime `.eitapp` bundle, and you want it to look native in every client portal without manual per-client skinning.

---

## The contract

The shell owns:
- The brand palette (colors, typography, logos) — driven by each client's `brand.json`
- Light/dark mode state (users toggle, shell persists preference)
- The chrome (sidebar, topbar, login) — always dark
- Layout shell + navigation

Your app owns:
- The content-area UI — everything inside `<main>`
- Data fetching, business logic, interactions

**Your app must adapt to the shell's colors, fonts, and mode state automatically.** A single bundle gets deployed to every client shell (each with its own primary brand hex) — it must look right in all of them, in both dark and light modes, with zero code changes.

---

## Critical Rules

### ✅ DO

- **Use semantic tokens**: `bg-card`, `text-foreground`, `bg-primary`, `text-muted-foreground`, `border-border` — see [tokens.md](tokens.md) for the full set
- **Use status tokens** for semantic meaning: `bg-success`, `bg-warning`, `bg-danger`, `bg-info` — optionally with opacity like `bg-warning/15`
- **Declare tokens in `@theme reference`** in your app's CSS so Tailwind knows to generate their utilities — your app ships its own compiled CSS, and utilities only exist if Tailwind sees them declared
- **Import `tailwindcss/utilities`**, not the full `tailwindcss` — full import bundles a reset + theme layer that will override the shell's brand tokens at runtime
- **Test in both light AND dark mode** — toggling is a first-class feature, not an afterthought
- **Use CSS custom properties for Recharts and other libraries that take color as a prop**: `fill: 'currentColor'`, `backgroundColor: 'var(--color-card)'`, `color: 'var(--color-foreground)'`

### ❌ DO NOT

- **Don't hardcode hex colors**: `bg-[#10b981]`, `style={{ color: '#3b82f6' }}`, `className="bg-red-500"` all lock your bundle to one client's palette
- **Don't use raw Tailwind palettes** for UI surfaces: `bg-gray-800`, `bg-slate-900`, `text-zinc-500` don't flip with light mode. Use `bg-muted`, `bg-card`, `text-muted-foreground`
- **Don't use legacy `shell-*` / `surface-*` tokens in new code**: `bg-shell-800`, `bg-surface-2` still work via compatibility aliases but are deprecated (and never flip in light mode). Note: `brand-50..900` (and `secondary-50..900`) are the **current** accent spectrum — use them for tints (`bg-brand-500/20`) and chart series colors. Use `bg-primary` / `text-primary-foreground` for solid primary UI (handles mode contrast automatically)
- **Don't `@import "tailwindcss"`** in your app's CSS — use `@import "tailwindcss/utilities"` so you don't bundle a full reset that fights the shell
- **Don't assume dark mode** — even if the shell defaults to dark, your app has to work when the user toggles to light
- **Don't import shell or app-bridge in styling decisions** — a good app reads `useTheme()` for brand colors if it needs JS access, but styling should go through CSS custom properties

---

## Quick Start for a new app

### 1. Package setup

Use `npx create-elasticit-app` which sets up all of this correctly. If you're migrating an older app, verify these:

**`package.json`**
```json
{
  "peerDependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "@elasticit-llc/app-bridge": "^0.7.0"
  },
  "elasticitApp": true
}
```

**`vite.config.ts`** — for runtime-loaded apps, you MUST inline dynamic imports (shell's signed-URL scheme can't resolve sibling chunks):
```ts
export default defineConfig({
  build: {
    lib: { entry: resolve(__dirname, 'src/index.ts'), formats: ['es', 'cjs'], fileName: 'index' },
    cssCodeSplit: false,
    rollupOptions: {
      external: ['react', 'react-dom', 'react/jsx-runtime', '@elasticit-llc/app-bridge'],
      output: {
        inlineDynamicImports: true,  // ← CRITICAL for runtime apps
      },
    },
  },
})
```

### 2. App CSS — `src/app.css`

```css
/* Utilities only — full tailwindcss import would override the shell's theme */
@import "tailwindcss/utilities";

/* Scan this app's source for utility class usage */
@source "./";

/*
 * Declare tokens here so Tailwind generates the utility classes.
 * "@theme reference" tells Tailwind: "these utilities exist, the shell
 * will provide the values at runtime." It does NOT emit :root vars.
 */
@theme reference {
  /* Semantic content tokens — flip with .light / .dark on <html> */
  --color-background: var(--color-background);
  --color-foreground: var(--color-foreground);
  --color-card: var(--color-card);
  --color-card-foreground: var(--color-card-foreground);
  --color-popover: var(--color-popover);
  --color-popover-foreground: var(--color-popover-foreground);
  --color-muted: var(--color-muted);
  --color-muted-foreground: var(--color-muted-foreground);
  --color-accent: var(--color-accent);
  --color-accent-foreground: var(--color-accent-foreground);
  --color-border: var(--color-border);
  --color-input: var(--color-input);
  --color-primary: var(--color-primary);
  --color-primary-foreground: var(--color-primary-foreground);
  --color-primary-hover: var(--color-primary-hover);
  --color-destructive: var(--color-destructive);
  --color-destructive-foreground: var(--color-destructive-foreground);

  /* Status intents — fixed across modes */
  --color-success: var(--color-success, #22c55e);
  --color-warning: var(--color-warning, #eab308);
  --color-danger: var(--color-danger, #ef4444);
  --color-info: var(--color-info, #3b82f6);

  /* Brand accent spectrum — resolves to the client's primary hue at runtime */
  --color-brand-50: var(--color-brand-50);
  --color-brand-100: var(--color-brand-100);
  --color-brand-200: var(--color-brand-200);
  --color-brand-300: var(--color-brand-300);
  --color-brand-400: var(--color-brand-400);
  --color-brand-500: var(--color-brand-500);
  --color-brand-600: var(--color-brand-600);
  --color-brand-700: var(--color-brand-700);
  --color-brand-800: var(--color-brand-800);
  --color-brand-900: var(--color-brand-900);
}
```

Import this file once at the top of your app:

```tsx
// src/App.tsx
import './app.css'
```

### 3. Write components with semantic tokens

```tsx
// Dashboard card (content area — flips with mode)
<div className="bg-card text-card-foreground border border-border rounded-md p-4">
  <h3 className="text-foreground font-semibold">Total Revenue</h3>
  <p className="text-muted-foreground text-sm">Last 30 days</p>
  <p className="text-2xl font-bold mt-2">$12,340</p>
</div>

// Primary action button (uses brand primary color)
<button className="bg-primary text-primary-foreground hover:bg-primary-hover px-4 py-2 rounded-md">
  Save
</button>

// Status pill (semantic intent, not a literal color)
<span className="bg-success/15 text-success px-2 py-1 rounded text-xs">Connected</span>
<span className="bg-warning/15 text-warning px-2 py-1 rounded text-xs">Pending</span>
<span className="bg-danger/15 text-danger px-2 py-1 rounded text-xs">Failed</span>

// Input field
<input className="bg-background text-foreground border border-input focus:ring-primary" />
```

### 4. Recharts / chart libraries

Chart libraries take color as JS props, not className. Use CSS variables and `currentColor`:

```tsx
import { ResponsiveContainer, LineChart, XAxis, YAxis, Tooltip, Line } from 'recharts'

<div className="text-foreground">  {/* parent text color — ticks inherit */}
  <ResponsiveContainer height={300}>
    <LineChart data={data}>
      <XAxis dataKey="date" tick={{ fill: 'currentColor' }} />
      <YAxis tick={{ fill: 'currentColor' }} />
      <Tooltip
        contentStyle={{
          backgroundColor: 'var(--color-popover, var(--color-card))',
          border: '1px solid var(--color-border)',
          color: 'var(--color-popover-foreground, var(--color-foreground))',
        }}
      />
      <Line type="monotone" dataKey="revenue" stroke="var(--color-brand-500)" />
    </LineChart>
  </ResponsiveContainer>
</div>
```

`var(--color-brand-500)` picks up whatever the client's primary is at runtime — each client's `brand.json` supplies a different hue. Lines and bars automatically re-skin per client.

---

## Migrating an existing app

If your app uses legacy `shell-*` / `surface-*` tokens or raw Tailwind palettes, run the migration script:

```bash
# Script ships with @elasticit-llc/ui-kit:
node node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs src --dry-run -v   # preview
node node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs src                # apply
```

The script handles ~95% of cases automatically. See [migration-guide.md](migration-guide.md) for the mapping cheat sheet + manual cleanup patterns.

**After running:**

1. Grep for leftovers:
   ```bash
   grep -rE 'bg-shell-|text-shell-|border-shell-|bg-brand-[0-9]|bg-\[#|style=.*color' src/
   ```
   Legitimate matches: categorical chart series with semantic distinct colors, intentional brand tints (`bg-brand-500/20`), string literals.

2. **Update your `app.css`** — add semantic tokens to `@theme reference` per the template above. Older apps often only declared `shell-*` and `brand-*` tokens, which means Tailwind won't generate `bg-card`/`bg-muted`/etc. even if your components try to use them. This is the #1 cause of "I migrated the source but it still renders as a dark island in light mode."

3. **Rebuild + repackage**. Source changes don't ship to client feeds until a new `.eitapp` is built and uploaded. Verify your `dist/index.css` now contains the semantic utilities:
   ```bash
   grep -cE '\.bg-card|\.bg-muted|\.text-foreground' dist/index.css
   ```

---

## Testing checklist

Before shipping any app:

### 1. Dark mode (default)
- [ ] Card surfaces use `bg-card` and look right on the shell's dark content bg
- [ ] Text uses `text-foreground` / `text-muted-foreground`, fully readable
- [ ] Primary actions use `bg-primary`, show in the client's brand color
- [ ] Status badges use `bg-success/warning/danger/info`
- [ ] Charts' axes, tooltips, legends inherit from CSS vars (not hardcoded hex)

### 2. Light mode
Force it in devtools:
```js
localStorage.setItem('elasticit-color-mode', 'light')
document.documentElement.classList.remove('dark')
document.documentElement.classList.add('light')
// Reload
```

- [ ] Content area bg becomes off-white
- [ ] Cards become white with subtle borders
- [ ] Text becomes near-black, readable
- [ ] Sidebar/topbar stay dark (they use chrome tokens — don't flip)
- [ ] Primary buttons still show in brand color with readable text
- [ ] Charts still readable (ticks change from light-on-dark to dark-on-light via `currentColor`)
- [ ] No dark islands — any region that stays dark is a bug
- [ ] No invisible text — anything you can't see in light mode is a bug

### 3. Mode toggle
- [ ] Click the sun/moon in the topbar repeatedly
- [ ] Content flips cleanly with no flash
- [ ] No leftover dark areas after flipping to light
- [ ] No leftover light areas after flipping to dark

### 4. Cross-client sanity
If you have access to multiple clients, load the same app in 2+ portals:
- [ ] Brand primary color changes per client (each client's `brand.json` supplies a different primary hex)
- [ ] Status colors (success/warning/danger) are the same everywhere
- [ ] Layout and spacing are identical

---

## Runtime vs compile-time apps

### Runtime-loaded apps (`.eitapp`)
- Published to the client's Supabase Storage bucket
- Loaded on-demand when user navigates to the app
- Shipped as a self-contained bundle (`index.js` + `index.css`)
- **Must use `inlineDynamicImports: true`** in Vite rollup config — shell's signed-URL scheme can't resolve sibling chunks
- Publishes via `Admin > App Management > Publish App` or `publish-app` CLI
- CSS is injected on-demand when the app page is active

### Compile-time apps (npm dep)
- Installed in the client shell's `package.json` via `npm install @elasticit-llc/your-app`
- Bundled into the client shell's main build at `vite build` time
- Shipped as part of the shell's dist
- Published to GitHub Packages with `npm publish`
- Client shell's `src/index.css` must include `@source "../node_modules/@elasticit-llc/your-app/dist/**/*.js"` so Tailwind scans the app's classes

Either way, **the token rules are identical**. Runtime vs compile-time affects ONLY delivery, not styling.

---

## Assets: logos, favicons, images

If your app has its own brand assets (not the client's logo — e.g. a partner logo for an integration tile):

- **Use SVG or transparent PNG**. JPEGs with baked-in backgrounds will show as boxes on the shell's dark chrome
- **If you only have a JPEG source**, extract with a tool like Python/PIL using luminance-inverse alpha to make the background transparent while keeping the logo strokes
- **Dark-friendly variants**: if an asset has dark text that won't read on the chrome, generate a white-text variant and pick the right one based on mode
- **Favicons**: square monogram works best — crop the strongest icon-bearing region of your logo to a tight square

Don't rely on the shell to recolor your images — it can't. If you need color variants, ship multiple files.

---

## Common pitfalls

These are real issues that bit us during cross-client rollouts. Watch for them:

### 1. "I migrated the source but it still looks dark in light mode"
- Your `app.css` doesn't declare semantic tokens in `@theme reference`
- Tailwind isn't generating `.bg-card` / `.bg-muted` / etc. in your compiled CSS
- Verify: `grep -cE '\.bg-card|\.bg-muted|\.text-foreground' dist/index.css` should return a non-zero count
- **Fix**: copy the full `@theme reference` block from the template above into your `app.css`

### 2. "The schedule grid collapses to a single column in prod"
- Browser cached old `.eitapp` bundle from before your migration
- New bundle uploaded but Supabase Storage's edge cache hasn't propagated
- **Fix**: hard-refresh (Ctrl+Shift+R) or wait for signed-URL TTL to expire

### 3. "My calculator component is a dark island on the light content area"
- Your root `<div>` uses `bg-shell-800` or a hardcoded dark hex
- **Fix**: use `bg-card` so it flips with mode

### 4. "Status badges don't show up in light mode"
- You used `bg-amber-100 text-amber-800` (raw Tailwind palette — doesn't flip)
- **Fix**: use `bg-warning/15 text-warning` (semantic intent, flips correctly)

### 5. "The 'Run New Scan' button is invisible in light mode"
- Used `bg-primary-500 text-white` where `primary-500` doesn't exist in the shell's scale (the token is just `primary`, no shade)
- **Fix**: use `bg-primary text-primary-foreground`

### 6. "My chart's Y-axis labels are invisible when I toggle light mode"
- Recharts `tick={{ fill: '#e4e7ea' }}` — hardcoded hex that doesn't flip
- **Fix**: wrap chart in `<div className="text-foreground">` and use `tick={{ fill: 'currentColor' }}`

### 7. "App bundle 404s when user navigates to it"
- Vite config missing `inlineDynamicImports: true` — code-split chunks get requested without signed URLs, Supabase Storage returns 400
- **Fix**: add `inlineDynamicImports: true` in `rollupOptions.output`

### 8. "Wordmark logo shows dark text on my dark sidebar — invisible"
- Source JPEG has black text on white bg; chroma-keying makes bg transparent but keeps black text
- **Fix**: use a pixel classifier that recolors grayscale text pixels to solid white (alpha by original darkness)

### 9. "I have a JPEG logo with a pink halo around the red square on dark bg"
- JPEG compression bleeds red into adjacent white pixels (pinkish edge artifacts)
- Chroma-keying treats these as "not white and not red" and leaves them alone
- **Fix**: classify red-dominant bleed (`r > g + 40 and r > b + 40` but low saturation) as background, make transparent

### 10. "I use `@import 'tailwindcss'` and my app's colors replace the client's brand"
- Full `tailwindcss` import bundles a `@theme` block with default Tailwind colors
- When your app CSS loads, it overrides the shell's `--color-primary` with Tailwind's default blue
- **Fix**: use `@import 'tailwindcss/utilities'` instead

---

## Publish flow

### Runtime apps
```bash
# Edit source, bump version in package.json + app.manifest.json
npm run package              # builds + creates dist/<slug>-<version>.eitapp

# Upload to each client's feed:
#   Option A: Admin > App Management > Publish App in client portal
#   Option B: npx tsx scripts/publish-to-feed.ts --supabase-url <url> --service-role-key <key>
```

### Compile-time apps
```bash
npm version patch            # bump
git push origin main --tags  # push tag
# GitHub Actions publishes to npm.pkg.github.com
# Then: update each client shell's package.json to pin the new version
```

**Always bump version** — the publish tooling rejects re-publishing the same version, and browsers cache heavily on content-hashed URLs.

---

## Further reading

- [tokens.md](tokens.md) — full token reference
- [brand-json.md](brand-json.md) — how client shells configure their branding
- [migration-guide.md](migration-guide.md) — migrating apps from legacy to semantic tokens
- `scripts/migrate-app-tokens.mjs` (in this package) — the automated migration script, runnable from any installing app via `node node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs <app-src>`

---

## TL;DR

**Five commandments for your app to adapt cleanly:**

1. **Use semantic tokens** (`bg-card`, `text-foreground`, `bg-primary`) — never `bg-shell-800`, never `bg-[#hex]`, never `bg-gray-900`
2. **Declare tokens in `@theme reference`** in your `app.css` so Tailwind generates their utilities
3. **Use `tailwindcss/utilities`**, not `tailwindcss`, so you don't bundle a reset that overrides the shell
4. **Set `inlineDynamicImports: true`** in Vite rollup options for runtime apps
5. **Test both dark AND light mode** before shipping — toggle the mode in devtools, navigate every page, look for dark islands and invisible text
