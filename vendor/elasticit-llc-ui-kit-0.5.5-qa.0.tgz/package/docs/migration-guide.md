# Migration Guide — legacy tokens → semantic tokens

v0.5.0 introduces the three-layer token system (see [tokens.md](tokens.md)). Older apps and shells use a flat "shell-* / brand-* / raw Tailwind palette" convention that doesn't flip in light mode. This guide covers how to migrate.

## Why migrate

1. **Light mode stops breaking your app.** Apps using `bg-shell-800`/`bg-brand-600`/`bg-gray-900` render as dark islands against the shell's light content area when the user toggles light mode.
2. **Re-skin per client for free.** A bundle with `bg-card`/`text-primary` automatically inherits whatever client's `brand.json` defines. Bundles with `bg-shell-800` or `bg-[#hex]` lock you to one palette.
3. **Smaller mental model.** Semantic tokens say what an element IS ("this is a card surface," "this is muted text") rather than what color it happens to be today.

## The automated migration script

`scripts/migrate-app-tokens.mjs` (shipped with this package at `node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs`) handles the bulk of the work. It walks an app's `src/` and replaces:

- `bg-shell-*`, `text-shell-*`, `border-shell-*` → nearest content semantic
- `bg-brand-*`, `text-brand-*` → `primary` / `primary-foreground` / `brand-*` kept for chart tints
- Raw Tailwind palettes (`bg-amber-500`, `text-green-700`, `border-blue-300`, etc.) → intent-based semantic tokens, preserving opacity modifiers

Usage:

```bash
# Preview the changes without writing
node node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs src --dry-run -v

# Apply
node node_modules/@elasticit-llc/ui-kit/scripts/migrate-app-tokens.mjs src
```

Running clean regex on well-structured className attrs is reliable across real-world apps (single runs have processed thousands of replacements without manual fixup); edge cases are below.

## Manual cleanup after the script

Some patterns the script can't handle — scan for these:

### Inline hex or `bg-[#...]` arbitrary values

```tsx
// Before
<div style={{ background: '#3b82f6' }}>...</div>
<div className="bg-[#3b82f6]">...</div>

// After
<div className="bg-primary">...</div>
```

### Recharts / chart props

Chart libraries accept colors via props (not className). The script doesn't touch these. Use CSS custom properties directly:

```tsx
// Before
<XAxis tick={{ fill: '#e4e7ea' }} />
<Tooltip contentStyle={{ backgroundColor: '#2c3540', color: '#f4f5f7' }} />

// After — inherits from parent's text color, flips with mode
<div className="text-foreground">
  <XAxis tick={{ fill: 'currentColor' }} />
  <Tooltip contentStyle={{
    backgroundColor: 'var(--color-popover, var(--color-card))',
    border: '1px solid var(--color-border)',
    color: 'var(--color-popover-foreground, var(--color-foreground))',
  }} />
</div>
```

### Intentional categorical colors

Some apps have status indicators or categorical chart series that MUST stay visually distinct across modes — e.g., connection-status pills with one color per entity, or integration tiles with one color per third-party vendor. These look like raw Tailwind palette usage but are *intentional*.

Leave these alone. Only migrate when the palette is accidental (e.g., a developer reached for `bg-slate-800` because they wanted a dark card, not because "slate" is semantically the right color).

### Status pills with semantic intent

If a pill's color means something (success/warning/danger), migrate to the semantic token:

```tsx
// Before
<span className="bg-amber-100 text-amber-800">Pending</span>

// After
<span className="bg-warning/15 text-warning">Pending</span>
```

The `/15` opacity modifier creates a subtle tinted background.

## Mapping cheat sheet

### Surfaces

| Before | After |
|--------|-------|
| `bg-shell-900`, `bg-shell-950` | `bg-background` |
| `bg-shell-800`, `bg-shell-750` | `bg-card` |
| `bg-shell-700` | `bg-muted` or `bg-accent` |
| `bg-shell-600` | `bg-input` |

### Text

| Before | After |
|--------|-------|
| `text-shell-100`, `text-shell-50` | `text-foreground` |
| `text-shell-300`, `text-shell-400` | `text-muted-foreground` |
| `text-brand-300`, `text-brand-400` | `text-primary` |

### Borders

| Before | After |
|--------|-------|
| `border-shell-700`, `border-shell-800` | `border-border` |
| `border-shell-600` | `border-input` |
| `border-brand-500` | `border-primary` |

### Interactive / primary buttons

| Before | After |
|--------|-------|
| `bg-brand-600 hover:bg-brand-500` | `bg-primary hover:bg-primary-hover` |
| `bg-brand-500 text-white` | `bg-primary text-primary-foreground` |
| `ring-brand-500` | `ring-primary` |

### Status intents (raw palette → semantic)

| Before | After |
|--------|-------|
| `bg-green-*`, `bg-emerald-*`, `bg-lime-*` | `bg-success` (or `bg-success/15` for tints) |
| `bg-amber-*`, `bg-yellow-*`, `bg-orange-*` | `bg-warning` |
| `bg-red-*`, `bg-rose-*` | `bg-danger` |
| `bg-blue-*`, `bg-sky-*`, `bg-cyan-*` | `bg-info` |
| `bg-slate-*`, `bg-gray-*`, `bg-zinc-*`, `bg-neutral-*` | `bg-muted` |
| `text-slate-*`, `text-gray-*` | `text-muted-foreground` |

Chart series (bar/line with 6+ categorical colors) should stay raw — don't flatten `blue/green/amber/red/purple/cyan` to `info/success/warning/danger/info/info`.

## Post-migration verification

After running the script + manual cleanup:

1. **Grep for leftovers**

   ```bash
   grep -rE 'bg-shell-|text-shell-|border-shell-|bg-brand-[0-9]|bg-\[#' src/
   ```

   Legitimate matches:
   - Intentional categorical chart colors
   - Brand spectrum tints (`bg-brand-500/20`) used for subtle overlays
   - Comments / strings (won't be rendered)

2. **Test both modes**

   In the client shell, force light mode and verify:

   ```js
   localStorage.setItem('elasticit-color-mode', 'light')
   document.documentElement.classList.remove('dark')
   document.documentElement.classList.add('light')
   ```

   Reload and navigate every page. Look for dark islands (unmigrated surfaces), invisible text (wrong foreground token), or unreadable buttons.

3. **Play with the toggle**

   Click the sun/moon toggle repeatedly. Content should flip cleanly with no flash, no leftover dark areas. The sidebar and topbar should NOT change — those use chrome tokens.

## What about the shell itself?

The shell (v0.11.3+) already uses semantic tokens for admin pages and content areas, and chrome tokens for the sidebar/topbar. Older shells will still work because the compiler emits legacy `shell-*` aliases — but upgrading the shell's own components to semantic tokens is on the roadmap.
