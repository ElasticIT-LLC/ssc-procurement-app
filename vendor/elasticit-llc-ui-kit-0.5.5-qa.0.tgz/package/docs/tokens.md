# Design Tokens Reference

The ui-kit defines a three-layer token system that feeds Tailwind v4's `@theme` block at build time:

```
Layer 1: DEFAULTS (ui-kit)         → neutral palette, type, radii, shadows, motion, z
Layer 2: BRAND OVERRIDES (brand.json) → brand+secondary colors, fonts, chrome tokens
Layer 3: USER PREFERENCE (runtime) → .light / .dark class on <html> flips content tokens
```

The `brandCompiler` Vite plugin reads `brand.json` and emits `src/generated-brand.css` containing the full compiled `@theme` block plus a `:where(.light)` override block.

## Primitive tokens (always available)

### Brand spectrum

Generated from `brand.theme.colors.brand.primary` by HSL lightness steps. Override individual shades in `brand.json` if the generator's output doesn't match your brand guide.

| Token | Notes |
|-------|-------|
| `brand-50` … `brand-900` | Client accent spectrum |
| `secondary-50` … `secondary-900` | Optional second accent (when a client supplies a secondary hex) |

### Neutral palette (shared)

```
neutral-50  #f4f5f7      neutral-700  #36414d
neutral-100 #e4e7ea      neutral-750  #2f3944
neutral-200 #c9cfd5      neutral-800  #2c3540
neutral-300 #a3adb8      neutral-900  #1e252d
neutral-400 #7a8796      neutral-950  #141a20
neutral-500 #4c5b6a
neutral-600 #414e5b
```

### Semantic status colors

```
success  #22c55e
warning  #eab308
danger   #ef4444
info     #3b82f6
```

Used via `bg-success`, `text-danger`, `border-warning`, etc. Ui-kit components apply these for status indicators.

## Semantic tokens — split by zone

The key insight of the token system: **chrome** (sidebar/topbar) and **content** (main area) are independent. User light/dark toggle only flips content tokens. Chrome stays dark always.

### Chrome tokens — always dark

Apply to shell chrome components (`Sidebar`, `TopBar`, `LoginPage`).

| Token | Default |
|-------|---------|
| `chrome-bg` | `neutral-950` (or brand override) |
| `chrome-foreground` | `neutral-100` |
| `chrome-muted` | `neutral-400` |
| `chrome-active-bg` | `brand-900` |
| `chrome-active-foreground` | `brand-300` |
| `chrome-border` | `neutral-800` |

Override in `brand.json` when a brand guide needs specific chrome colors (for example, a client that wants a slate-tinted sidebar instead of the neutral-950 default):

```json
{
  "theme": {
    "colors": {
      "chrome": {
        "bg": "#1e293b",
        "border": "#334155",
        "activeBg": "#3b82f6",
        "activeForeground": "#ffffff"
      }
    }
  }
}
```

### Content tokens — flip between dark and light

Apply to main content area, admin pages, cards, tables — everything the user's toggle affects. Naming follows shadcn/ui conventions.

| Token | Dark default | Light default |
|-------|--------------|---------------|
| `background` | `neutral-900` | `#f5f6f7` |
| `foreground` | `neutral-100` | `#0f172a` |
| `card` | `neutral-800` | `#ffffff` |
| `card-foreground` | `neutral-100` | `#0f172a` |
| `popover` | `neutral-750` | `#ffffff` |
| `popover-foreground` | `neutral-100` | `#0f172a` |
| `muted` | `neutral-750` | `#fafbfc` |
| `muted-foreground` | `neutral-300` | `#64748b` |
| `accent` | `neutral-700` | `#f1f3f5` |
| `accent-foreground` | `neutral-100` | `#0f172a` |
| `border` | `neutral-700` | `#e5e7eb` |
| `input` | `neutral-600` | `#d1d5db` |
| `primary` | `brand-600` | `brand-500` |
| `primary-foreground` | `neutral-50` | `#ffffff` |
| `primary-hover` | `brand-500` | `brand-600` |
| `destructive` | `#ef4444` | `#dc2626` |
| `destructive-foreground` | `#ffffff` | `#ffffff` |

These are applied as CSS custom properties on `@theme` and again under `:where(.light) { ... }`. Tailwind's built-in light-mode mechanics aren't used — the plugin writes its own override block so dark is the default and light opts in.

## Typography tokens

| Family | Default | Brand override via |
|--------|---------|--------------------|
| `font-family-heading` | System sans-serif stack | `brand.theme.typography.fontFamily.heading` |
| `font-family-body` | System sans-serif stack | `brand.theme.typography.fontFamily.body` |
| `font-family-mono` | System mono stack | `brand.theme.typography.fontFamily.mono` |

Sizes / weights / line heights are fixed defaults (no brand override needed):

```
font-size-{xs sm base lg xl 2xl 3xl 4xl}
font-weight-{regular medium semibold bold}
line-height-{tight normal relaxed}
```

## Other tokens

```
radius-{none sm md lg xl full}
shadow-{sm md lg xl}
duration-{fast normal slow}
easing-{linear in out in-out}
z-{base dropdown sticky modal toast tooltip}
```

## Legacy compatibility

The compiler still emits aliases so older code keeps working during migration:

- `shell-50` … `shell-950` → `neutral-*` (same values)
- `surface-0` … `surface-4`, `surface-950` → `neutral-*` (used by older apps like msr-gul)

New code should not use these — see [migration-guide.md](migration-guide.md).

## Using tokens in components

Tailwind v4 auto-generates utilities from every `--color-*` declaration. So `bg-primary`, `text-muted-foreground`, `border-card`, `ring-warning`, `bg-brand-500/20`, etc. all work without config.

```tsx
// Content area (flips with user toggle)
<div className="bg-card text-card-foreground border-border p-4 rounded-md">
  <p className="text-muted-foreground">Secondary text</p>
  <button className="bg-primary text-primary-foreground hover:bg-primary-hover">
    Confirm
  </button>
</div>

// Chrome area (always dark — ignores user toggle)
<aside className="bg-chrome-bg text-chrome-foreground border-chrome-border">
  <a className="bg-chrome-active-bg text-chrome-active-foreground">Active</a>
</aside>

// Status indicators
<span className="bg-success/15 text-success">Connected</span>
<span className="bg-warning/15 text-warning">Pending</span>
```

## How the user toggle works

1. The shell's `useColorMode` hook reads `user_profiles.settings.colorMode` (`"light" | "dark" | "system"`)
2. On mount, it adds `.light` or `.dark` to `<html>`
3. CSS selector `:where(.light) { --color-background: ... }` overrides content tokens
4. Chrome tokens, primitives, fonts, radii etc. don't depend on the class — they never change

This means you can mark a region immune to user toggle by leaving it outside the `.light`/`.dark` scope — or more simply, by using chrome tokens.
