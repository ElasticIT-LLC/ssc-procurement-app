# @elasticit-llc/app-bridge

React hooks SDK for apps running inside the ElasticIT portal shell. Apps are libraries (not standalone SPAs) that export a React component consumed by the shell at runtime.

## Installation

```bash
npm install @elasticit-llc/app-bridge
```

Requires `.npmrc` with:
```
@elasticit-llc:registry=https://npm.pkg.github.com
```

**Important:** `@elasticit-llc/app-bridge` must be a **peer dependency** in your app's `package.json`, not a regular dependency. Bundling it would create duplicate React context and break all hooks silently.

## Hooks

| Hook | Returns | Purpose |
|------|---------|---------|
| `useShellContext()` | Full context object | Access user, theme, supabase, toast, permissions, config |
| `useAuth()` | `{ user, hasPermission }` | Current user and permission check |
| `useSupabase()` | Supabase client | Client's own Supabase instance |
| `useTheme()` | Theme colors | Brand colors from shell config |
| `useToast()` | `{ showToast }` | Show success/error/info toasts |
| `usePermissions()` | `{ hasPermission, hasRole, role, permissions }` | Permission and role checks |
| `useCredentials()` | `{ getCredentials(appId) }` | Fetch decrypted credentials from vault |
| `useProxyClient(fn)` | `ProxyClient` | Chainable client for any proxy edge function |

## How It Works

The shell's `ShellBridgeProvider` passes the user's JWT token and `supabaseUrl` to apps via React context. This is how `useProxyClient` authenticates edge function calls — it reads the token from `supabase.auth.getSession()` at request time. Apps don't need to manage auth tokens manually.

## Basic Usage

```tsx
import { useAuth, useToast, usePermissions } from '@elasticit-llc/app-bridge'

export default function MyApp() {
  const { user } = useAuth()
  const { showToast } = useToast()
  const { hasPermission } = usePermissions()

  return <div>Hello, {user?.name}</div>
}
```

## Credentials

Fetch decrypted credentials linked to your app from the Credential Vault:

```tsx
import { useCredentials } from '@elasticit-llc/app-bridge'

const { getCredentials } = useCredentials()
const creds = await getCredentials(appId)
// Returns: [{ id, label, credential_type, data: { client_id, client_secret, ... } }]
```

## Proxy Client

For apps that need external data (shared databases, third-party APIs), use `useProxyClient` to call a proxy edge function with a Supabase-like API:

```tsx
import { useProxyClient } from '@elasticit-llc/app-bridge'

const client = useProxyClient('my-proxy')

// Table queries
const { data } = await client.from('my_table').select('*').eq('status', 'active')

// RPC calls
const { data } = await client.rpc('my_function', { param: 'value' })

// Upserts
await client.from('configs').upsert({ id: '1', value: 'x' }, { onConflict: 'id' })

// API calls (proxied through edge function)
const { data } = await client.api('printers', { method: 'GET', params: { page: '0' } })
```

The proxy client supports: `.from()`, `.schema()`, `.select()`, `.eq()`, `.neq()`, `.not()`, `.order()`, `.limit()`, `.single()`, `.maybeSingle()`, `.rpc()`, `.upsert()`, `.api()`.

## App-Specific Patterns

Apps should wrap the generic hooks in app-specific hooks. Example from `@elasticit-llc/printix-app`:

```tsx
// hooks/usePrintix.ts (inside the app repo, NOT in app-bridge)
import { useProxyClient } from '@elasticit-llc/app-bridge'

export function usePrintixDB() {
  return useProxyClient('printix-proxy')
}

export function usePrintixApi() {
  const client = useProxyClient('printix-proxy')
  return {
    listPrinters: () => client.api('printers'),
    listGroups: () => client.api('groups'),
  }
}
```

## Development

```bash
npm install
npm run build
npm run test
```
