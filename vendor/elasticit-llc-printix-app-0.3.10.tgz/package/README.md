# @elasticit-llc/printix-app

Printix print management dashboard for the ElasticIT portal.

## Installation

```bash
npm install @elasticit-llc/printix-app
```

Requires GitHub Packages auth — see `.npmrc`.

## Usage in Client Shell

```tsx
import { lazy } from 'react'
import type { NativeAppRegistry } from '@elasticit-llc/shell'
import printixManifest from '@elasticit-llc/printix-app/permissions.json'

const appRegistry: NativeAppRegistry = {
  'printix': lazy(() => import('@elasticit-llc/printix-app').then(m => ({ default: m.App }))),
}

const permissionManifests = {
  printix: printixManifest,
}
```

## Prerequisites

- `printix-proxy` edge function deployed to the client's Supabase project
- Printix credentials stored in Supabase Vault
- App registered in the `apps` table (auto-synced on first admin login)

## Development

```bash
npm install
npm run dev      # Watch mode
npm run build    # Production build
npm run test     # Run tests
npm publish      # Publish to GitHub Packages
```
