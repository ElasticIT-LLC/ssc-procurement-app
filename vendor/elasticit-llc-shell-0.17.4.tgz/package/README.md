# @elasticit-llc/shell

React framework for ElasticIT client portals — provides auth, layout, admin pages, and native app hosting.

## Installation

```bash
npm install @elasticit-llc/shell
```

Requires `.npmrc` with:
```
@elasticit-llc:registry=https://npm.pkg.github.com
```

## Usage

```tsx
import { ShellProvider, ShellLayout, NativeAppHost, ProtectedRoute, LoginPage, AuthCallback } from '@elasticit-llc/shell'
import { AdminRoutes } from '@elasticit-llc/shell/admin'
```

See [elasticit-client-template](https://github.com/ElasticIT-LLC/elasticit-client-template) for a complete usage example.

## Role Impersonation (Preview)

Admins can preview the portal as any role would see it. Navigate to **Admin → Roles** and click the **Impersonate** button next to any non-system role. A sticky banner appears at the top of every page showing the active preview; click **Exit preview** in the banner — or **Stop** next to the role on the Roles page — to return to full admin. Switching to a different role's preview just clicks **Impersonate** on that other role.

**What preview catches:**
- Sidebar visibility (admin section hidden, app pages filtered)
- App-level `hasAppAccess` / `user.appPermissions` gating
- UI elements gated on `user.role`

**What preview does NOT catch:**
- Row-level security. Queries still run with your admin Supabase session, so data an admin can read but a real user cannot may still appear. Preview is a UI-gating check, not a full sandbox.
- Service-role edge functions (e.g. `app-proxy`) — they always run with full backend privilege.

Impersonation state persists across hard reloads within the same tab (via `sessionStorage`) and clears when the tab closes.

All actions taken during preview are logged as the admin performing them, with `metadata.impersonating = { role_ids, role_names }` so the audit trail remains accurate. Starting and stopping impersonation are themselves logged as `impersonation_start` / `impersonation_stop` events.

## Development

```bash
npm install
npm run build
npm run test
```

## Publishing

```bash
npm version patch
npm run build
npm publish
```
