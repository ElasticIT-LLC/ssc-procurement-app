// Supabase Edge Function — Deno runtime
// Proxies Microsoft Graph API group searches using a Vault credential.
// Used by the Roles admin page to search Azure AD groups for mapping.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const CREDENTIAL_ENCRYPTION_KEY = Deno.env.get('CREDENTIAL_ENCRYPTION_KEY')!

// ── Credential Vault decryption (AES-256-GCM) ──
async function getKey(): Promise<CryptoKey> {
  const keyBytes = new Uint8Array(
    CREDENTIAL_ENCRYPTION_KEY.match(/.{2}/g)!.map((b: string) => parseInt(b, 16))
  )
  return crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt'])
}

async function decrypt(encoded: string): Promise<string> {
  const key = await getKey()
  const combined = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0))
  const iv = combined.slice(0, 12)
  const ciphertext = combined.slice(12)
  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext)
  return new TextDecoder().decode(plaintext)
}

// ── CORS ──
function corsHeaders(req: Request) {
  return {
    'Access-Control-Allow-Origin': req.headers.get('Origin') ?? '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  }
}

function json(body: unknown, req: Request, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), 'Content-Type': 'application/json' },
  })
}

// ── Find the Microsoft Graph credential in the Vault ──
async function findGraphCredential(
  supabase: ReturnType<typeof createClient>
): Promise<{ client_id: string; client_secret: string; token_url: string } | null> {
  const { data: creds } = await supabase
    .from('credentials')
    .select('id, label, encrypted_data')
    .eq('credential_type', 'oauth2')
    .ilike('label', '%graph%')
    .limit(1)

  if (!creds || creds.length === 0) return null

  const decrypted = JSON.parse(await decrypt(creds[0].encrypted_data))
  return {
    client_id: decrypted.client_id,
    client_secret: decrypted.client_secret,
    token_url: decrypted.token_url,
  }
}

// ── Get an access token from Azure AD using client credentials ──
async function getGraphToken(cred: { client_id: string; client_secret: string; token_url: string }): Promise<string> {
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: cred.client_id,
    client_secret: cred.client_secret,
    scope: 'https://graph.microsoft.com/.default',
  })

  const res = await fetch(cred.token_url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(10000),
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Graph token request failed: ${res.status} ${text}`)
  }

  const data = await res.json()
  return data.access_token
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders(req) })
  }

  if (req.method !== 'GET') {
    return json({ error: 'Method not allowed' }, req, 405)
  }

  // Authenticate caller
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return json({ error: 'Unauthorized' }, req, 401)
  }

  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return json({ error: 'Unauthorized' }, req, 401)
  }

  // Verify admin
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'admin') {
    return json({ error: 'Forbidden' }, req, 403)
  }

  // Find Graph credential
  const cred = await findGraphCredential(supabase)
  if (!cred) {
    return json({
      error: 'No Microsoft Graph credential found. Add an OAuth2 (Client Credentials) credential with "Graph" in the label in the Credential Vault.',
    }, req, 400)
  }

  const url = new URL(req.url)
  const search = url.searchParams.get('search')
  const ids = url.searchParams.get('ids')

  if (search === null && !ids) {
    return json({ error: 'Provide ?search=term or ?ids=uuid1,uuid2' }, req, 400)
  }

  try {
    const graphToken = await getGraphToken(cred)

    let graphUrl: string
    if (search !== null) {
      if (search) {
        // Search groups by displayName prefix
        const filter = `startswith(displayName,'${search.replace(/'/g, "''")}')`
        graphUrl = `https://graph.microsoft.com/v1.0/groups?$filter=${encodeURIComponent(filter)}&$select=id,displayName,description&$top=50`
      } else {
        // Empty search — return all groups
        graphUrl = `https://graph.microsoft.com/v1.0/groups?$select=id,displayName,description&$top=50&$orderby=displayName`
      }
    } else {
      // Resolve specific group IDs
      const idList = ids!.split(',').map((id) => `'${id.trim()}'`).join(',')
      const filter = `id in (${idList})`
      graphUrl = `https://graph.microsoft.com/v1.0/groups?$filter=${encodeURIComponent(filter)}&$select=id,displayName,description`
    }

    const graphRes = await fetch(graphUrl, {
      headers: { Authorization: `Bearer ${graphToken}` },
      signal: AbortSignal.timeout(10000),
    })

    if (graphRes.status === 429) {
      const retryAfter = graphRes.headers.get('Retry-After') ?? '30'
      return new Response(JSON.stringify({ error: 'Rate limited by Microsoft Graph', retryAfter }), {
        status: 429,
        headers: { ...corsHeaders(req), 'Content-Type': 'application/json', 'Retry-After': retryAfter },
      })
    }

    if (!graphRes.ok) {
      const text = await graphRes.text()
      return json({ error: `Graph API error: ${graphRes.status} ${text}` }, req, 502)
    }

    const graphData = await graphRes.json()
    const groups = (graphData.value ?? []).map((g: Record<string, unknown>) => ({
      id: g.id,
      displayName: g.displayName,
      description: g.description ?? null,
    }))

    return json(groups, req)
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    if (message.includes('token request failed')) {
      return json({ error: `Graph authentication failed. Check client_id and client_secret in the Credential Vault. Details: ${message}` }, req, 401)
    }
    return json({ error: message }, req, 500)
  }
})
