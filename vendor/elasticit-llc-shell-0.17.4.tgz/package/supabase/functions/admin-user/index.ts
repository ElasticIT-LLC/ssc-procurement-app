// Supabase Edge Function — Deno runtime
//
// Admin-only user lifecycle endpoint. Currently exposes:
//   DELETE /admin-user?id=<uid>
//
// Uses the official auth.admin.deleteUser API so GoTrue cleans up
// auth.identities, auth.sessions, auth.refresh_tokens; the public
// schema cleans up via existing FK cascades on user_profiles +
// user_role_assignments. Migration 026 makes audit_log /
// credentials.created_by / az_group_role_mappings.created_by
// non-blocking via ON DELETE SET NULL.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

function getCorsOrigin(req: Request): string {
  return req.headers.get('Origin') ?? '*'
}

const baseCorsHeaders = {
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
}

function corsHeaders(req: Request) {
  return { ...baseCorsHeaders, 'Access-Control-Allow-Origin': getCorsOrigin(req) }
}

let _currentReq: Request | null = null

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(_currentReq!), 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  _currentReq = req

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders(req) })
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const url = new URL(req.url)
  const method = req.method

  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return json({ error: 'Unauthorized' }, 401)
  }

  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return json({ error: 'Unauthorized' }, 401)
  }

  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role, email')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'admin') {
    return json({ error: 'Forbidden' }, 403)
  }

  // DELETE /admin-user?id=<uuid>
  if (method === 'DELETE') {
    const targetId = url.searchParams.get('id')
    if (!targetId) return json({ error: 'Missing id' }, 400)

    if (targetId === user.id) {
      return json({ error: 'Cannot delete your own account' }, 400)
    }

    // Pull target email + display_name BEFORE the delete so the audit
    // entry has human-readable detail. user_profiles cascades away
    // when we delete auth.users below, so capture first.
    const { data: targetProfile } = await supabase
      .from('user_profiles')
      .select('email, display_name')
      .eq('id', targetId)
      .single()

    const { data: targetAuth } = await supabase.auth.admin.getUserById(targetId)
    if (!targetAuth?.user) {
      return json({ error: 'User not found' }, 404)
    }

    const targetEmail =
      targetProfile?.email
      ?? targetAuth.user.email
      ?? (targetAuth.user.user_metadata?.email as string | undefined)
      ?? null

    const { error: deleteErr } = await supabase.auth.admin.deleteUser(targetId)
    if (deleteErr) {
      return json({ error: deleteErr.message }, 500)
    }

    // Best-effort audit log entry. user_id on audit_log is now
    // ON DELETE SET NULL, so writing user.id (the admin actor) is safe.
    await supabase.from('audit_log').insert({
      user_id: user.id,
      user_email: profile?.email ?? user.email ?? null,
      action: 'user_delete',
      resource_type: 'user',
      resource_id: targetId,
      metadata: {
        target_email: targetEmail,
        target_display_name: targetProfile?.display_name ?? null,
      },
    })

    return json({ ok: true })
  }

  return json({ error: 'Method not allowed' }, 405)
})
