// Supabase Edge Function — Deno runtime
// Proxies Printix app queries to the shared Printix Supabase project
// Credentials stored in Supabase Vault (vault.secrets)
// Tenant isolation enforced server-side

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

// Allowlisted tables and RPCs
const ALLOWED_TABLES = new Set([
  'px_tenants', 'px_workstations', 'printer_configs', 'sync_log',
  'px_networks', 'px_printers', 'px_jobs', 'px_tracking_data',
  'px_groups', 'px_printer_status', 'px_print_queues', 'px_users',
])

const ALLOWED_RPCS = new Set([
  'dashboard_kpis', 'meter_readings', 'top_printers', 'fleet',
  'printer_duplex_stats', 'job_states', 'color_duplex', 'hourly_volume',
  'top_users', 'color_users',
])

// Allowlisted Cloud API endpoints (relative to base_url)
const ALLOWED_API_ENDPOINTS = new Set([
  'printers', 'users', 'groups', 'billing-info',
])

// Cached Printix Supabase client (persists across warm invocations)
let printixClient: ReturnType<typeof createClient> | null = null
let printixClientExpiry = 0

// Cached Printix Cloud API token
let apiToken: string | null = null
let apiTokenExpiry = 0

async function getPrintixClient(localSupabase: ReturnType<typeof createClient>) {
  const now = Date.now()
  if (printixClient && now < printixClientExpiry) return printixClient

  // Read vault secrets via RPC (PostgREST doesn't expose vault schema)
  const { data: urlData } = await localSupabase.rpc('get_vault_secret', { secret_name: 'printix_supabase_url' })
  const { data: keyData } = await localSupabase.rpc('get_vault_secret', { secret_name: 'printix_service_role_key' })

  const url = urlData as string | null
  const key = keyData as string | null

  if (!url || !key) {
    throw new Error('Printix vault secrets incomplete. Need printix_supabase_url and printix_service_role_key.')
  }

  printixClient = createClient(url, key)
  printixClientExpiry = now + 5 * 60 * 1000
  return printixClient
}

async function getTenantId(localSupabase: ReturnType<typeof createClient>): Promise<string> {
  // Try printix_tenant_id first (Printix-specific), fall back to tenant_id
  const { data: printixData } = await localSupabase
    .from('client_settings')
    .select('value')
    .eq('key', 'printix_tenant_id')
    .maybeSingle()

  if (printixData?.value) return printixData.value

  const { data, error } = await localSupabase
    .from('client_settings')
    .select('value')
    .eq('key', 'tenant_id')
    .single()

  if (error || !data?.value) {
    throw new Error('tenant_id not found in client_settings')
  }
  return data.value
}

// ---------------------------------------------------------------------------
// Printix Cloud API helpers
// ---------------------------------------------------------------------------

const PRINTIX_CLOUD_BASE = 'https://api.printix.net/cloudprint'

interface PrintixApiCreds {
  clientId: string
  clientSecret: string
  tokenUrl: string
}

async function getApiCredentials(localSupabase: ReturnType<typeof createClient>): Promise<PrintixApiCreds> {
  const keys = ['printix_api_client_id', 'printix_api_client_secret', 'printix_api_token_url']
  const results: Record<string, string> = {}

  for (const key of keys) {
    const { data } = await localSupabase.rpc('get_vault_secret', { secret_name: key })
    if (data) results[key] = data as string
  }

  if (!results.printix_api_client_id || !results.printix_api_client_secret || !results.printix_api_token_url) {
    throw new Error('Printix Cloud API credentials not found in vault. Need printix_api_client_id, printix_api_client_secret, printix_api_token_url.')
  }

  return {
    clientId: results.printix_api_client_id,
    clientSecret: results.printix_api_client_secret,
    tokenUrl: results.printix_api_token_url,
  }
}

/** Get the Printix Cloud API tenant ID for building API URLs */
async function getApiTenantId(localSupabase: ReturnType<typeof createClient>): Promise<string> {
  const { data } = await localSupabase
    .from('client_settings')
    .select('value')
    .eq('key', 'printix_api_tenant_id')
    .maybeSingle()

  if (data?.value) return data.value

  // Fall back to tenant_id if printix_api_tenant_id not set
  const { data: fallback } = await localSupabase
    .from('client_settings')
    .select('value')
    .eq('key', 'tenant_id')
    .single()

  if (!fallback?.value) throw new Error('printix_api_tenant_id not found in client_settings')
  return fallback.value
}

async function getApiToken(creds: PrintixApiCreds): Promise<string> {
  const now = Date.now()
  if (apiToken && now < apiTokenExpiry) return apiToken

  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
  })

  const res = await fetch(creds.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(10_000),
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Printix token request failed (${res.status}): ${text || res.statusText}`)
  }

  const data = await res.json()
  if (!data.access_token) throw new Error('Printix token response missing access_token')

  const expiresIn: number = typeof data.expires_in === 'number' ? data.expires_in : 3600
  apiToken = data.access_token
  apiTokenExpiry = now + (expiresIn - 60) * 1000 // Refresh 60s before expiry
  return apiToken!
}

/** Extract array payload from HAL+JSON or plain responses */
function normalizeApiList(data: unknown): unknown[] {
  if (Array.isArray(data)) return data
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>
    // Check common envelope keys
    for (const key of ['printers', 'users', 'groups', 'tenants', 'value', 'records']) {
      if (Array.isArray(obj[key])) return obj[key] as unknown[]
    }
    // HAL _embedded support
    if (obj._embedded && typeof obj._embedded === 'object') {
      for (const val of Object.values(obj._embedded as Record<string, unknown>)) {
        if (Array.isArray(val)) return val
      }
    }
    return [data]
  }
  return []
}

function applyFilters(query: any, filters: Array<{ op: string; column: string; value: unknown }>) {
  let q = query
  for (const f of filters) {
    switch (f.op) {
      case 'eq': q = q.eq(f.column, f.value); break
      case 'neq': q = q.neq(f.column, f.value); break
      case 'gt': q = q.gt(f.column, f.value); break
      case 'gte': q = q.gte(f.column, f.value); break
      case 'lt': q = q.lt(f.column, f.value); break
      case 'lte': q = q.lte(f.column, f.value); break
      case 'in': q = q.in(f.column, f.value as unknown[]); break
      case 'is': q = q.is(f.column, f.value); break
      case 'not': {
        const v = f.value as { op: string; value: unknown }
        q = q.not(f.column, v.op, v.value)
        break
      }
      default: break
    }
  }
  return q
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return json({ error: 'Method not allowed' }, 405)
  }

  // Auth check
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return json({ error: 'Unauthorized' }, 401)
  }

  const localSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await localSupabase.auth.getUser(token)
  if (authError || !user) {
    return json({ error: 'Unauthorized' }, 401)
  }

  try {
    const body = await req.json()
    const tenantId = await getTenantId(localSupabase)
    const printix = await getPrintixClient(localSupabase)

    // Handle RPC calls
    if (body.type === 'rpc') {
      const fn = body.function as string
      if (!ALLOWED_RPCS.has(fn)) {
        return json({ error: `RPC function not allowed: ${fn}` }, 403)
      }

      const params = { ...body.params, p_tenant_id: tenantId }
      const { data, error } = await printix.rpc(fn, params)
      if (error) return json({ data: null, error: { message: error.message } }, 400)
      return json({ data, error: null })
    }

    // Handle table queries
    if (body.type === 'query') {
      const table = body.table as string
      if (!ALLOWED_TABLES.has(table)) {
        return json({ error: `Table not allowed: ${table}` }, 403)
      }

      // Data lives in 'public' schema on the Printix project (not 'printix')
      let query = printix.from(table).select(body.select || '*')

      // Enforce tenant_id — special case for px_tenants where the column is 'id'
      if (table === 'px_tenants') {
        query = query.eq('id', tenantId)
      } else {
        query = query.eq('tenant_id', tenantId)
      }

      // Apply additional filters (skip any client-supplied tenant_id)
      const filters = (body.filters || []).filter(
        (f: { column: string }) => f.column !== 'tenant_id' && f.column !== 'id'
      )
      query = applyFilters(query, filters)

      if (body.order) {
        query = query.order(body.order.column, { ascending: body.order.ascending ?? true })
      }

      if (body.limit) {
        query = query.limit(body.limit)
      }

      if (body.single) {
        const { data, error } = await query.single()
        if (error) return json({ data: null, error: { message: error.message } }, 400)
        return json({ data, error: null })
      }

      if (body.maybeSingle) {
        const { data, error } = await query.maybeSingle()
        if (error) return json({ data: null, error: { message: error.message } }, 400)
        return json({ data, error: null })
      }

      const { data, error } = await query
      if (error) return json({ data: null, error: { message: error.message } }, 400)
      return json({ data, error: null })
    }

    // Handle upserts
    if (body.type === 'upsert') {
      const table = body.table as string
      if (!ALLOWED_TABLES.has(table)) {
        return json({ error: `Table not allowed: ${table}` }, 403)
      }

      const upsertData = { ...body.data, tenant_id: tenantId }

      const opts: Record<string, unknown> = {}
      if (body.onConflict) opts.onConflict = body.onConflict

      const { data, error } = await printix
        .from(table)
        .upsert(upsertData, opts)

      if (error) return json({ data: null, error: { message: error.message } }, 400)
      return json({ data, error: null })
    }

    // Handle Printix Cloud API calls
    if (body.type === 'api') {
      const endpoint = body.endpoint as string
      if (!endpoint || !ALLOWED_API_ENDPOINTS.has(endpoint)) {
        return json({ error: `API endpoint not allowed: ${endpoint}` }, 403)
      }

      const creds = await getApiCredentials(localSupabase)
      const apiToken = await getApiToken(creds)
      const apiTenantId = await getApiTenantId(localSupabase)

      // Build URL dynamically: base/tenants/{printix_api_tenant_id}/{endpoint}
      let url = `${PRINTIX_CLOUD_BASE}/tenants/${apiTenantId}/${endpoint}`

      // Append query params if provided
      if (body.params && typeof body.params === 'object') {
        const search = new URLSearchParams()
        for (const [k, v] of Object.entries(body.params as Record<string, string>)) {
          if (v != null) search.set(k, String(v))
        }
        const qs = search.toString()
        if (qs) url += `?${qs}`
      }

      const method = (body.method as string || 'GET').toUpperCase()
      const fetchOpts: RequestInit = {
        method,
        headers: {
          'Authorization': `Bearer ${apiToken}`,
          'Accept': 'application/json',
        },
        signal: AbortSignal.timeout(30_000),
      }

      // Include body for POST/PUT/PATCH
      if (body.body && ['POST', 'PUT', 'PATCH'].includes(method)) {
        fetchOpts.headers = { ...fetchOpts.headers as Record<string, string>, 'Content-Type': 'application/json' }
        fetchOpts.body = JSON.stringify(body.body)
      }

      const res = await fetch(url, fetchOpts)

      if (!res.ok) {
        const text = await res.text().catch(() => '')
        return json({ data: null, error: { message: `Printix API ${res.status}: ${text || res.statusText}` } }, res.status >= 500 ? 502 : 400)
      }

      const apiData = await res.json()

      // Normalize HAL responses to plain arrays
      if (body.normalize !== false) {
        const items = normalizeApiList(apiData)
        return json({ data: items, error: null, _meta: { page: (apiData as Record<string, unknown>)?.page } })
      }

      return json({ data: apiData, error: null })
    }

    return json({ error: 'Invalid request type. Must be query, rpc, upsert, or api.' }, 400)

  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return json({ error: message }, 500)
  }
})
