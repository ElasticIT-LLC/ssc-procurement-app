// Supabase Edge Function — Deno runtime
// Returns the list of runtime-loadable apps for the current client shell
// Called by the shell at startup after authentication

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

function getCorsOrigin(req: Request): string {
  return req.headers.get('Origin') ?? '*'
}

function makeCorsHeaders(req: Request) {
  return {
    'Access-Control-Allow-Origin': getCorsOrigin(req),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: makeCorsHeaders(req) })
  }

  if (req.method !== 'GET' && req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
    })
  }

  // Verify the caller is authenticated
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
    })
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)

  if (authError || !user) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
    })
  }

  try {
    // Check if caller wants preview apps (admins only)
    let includePreview = false
    if (req.method === 'POST') {
      try {
        const body = await req.clone().json()
        includePreview = body?.include_preview === true
      } catch { /* no body or invalid JSON */ }
    } else {
      const url = new URL(req.url)
      includePreview = url.searchParams.get('include_preview') === 'true'
    }

    // If requesting preview apps, verify user is admin
    if (includePreview) {
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('role')
        .eq('id', user.id)
        .single()
      if (profile?.role !== 'admin') {
        includePreview = false // silently downgrade to production-only
      }
    }

    // Fetch active remote apps (optionally including preview)
    const loadingModes = includePreview ? ['remote', 'preview'] : ['remote']
    const { data: apps, error } = await supabase
      .from('apps')
      .select('slug, name, icon, bundle_url, css_url, integrity_hash, permissions_manifest, version, metadata, loading_mode')
      .eq('status', 'active')
      .is('deleted_at', null)
      .in('loading_mode', loadingModes)
      .not('bundle_url', 'is', null)
      .order('sort_order', { ascending: true })

    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
      })
    }

    // Generate signed URLs for bundle and CSS files in Supabase Storage.
    //
    // In local Supabase, createSignedUrl returns URLs prefixed with the
    // INTERNAL Docker hostname (e.g., "http://kong:8000/...",
    // "http://supabase_edge_runtime_local-dev:8081/...") because the storage
    // container only sees other containers via the Docker network. The
    // browser can't resolve those names — we must rewrite to the public URL.
    //
    // The PUBLIC Supabase URL is what the browser uses to reach Storage.
    // Strategy: derive from the SUPABASE_URL env var. In local dev that env
    // var typically points at an internal Docker hostname (e.g., http://kong:8000),
    // so we rewrite it to the standard local public URL (127.0.0.1:54321).
    // In production, SUPABASE_URL already IS the public URL so no rewrite needed.
    let publicSupabaseUrl: string
    try {
      const u = new URL(SUPABASE_URL)
      const isInternalHost = !u.hostname.includes('.')
        || u.hostname === 'localhost'
        || u.hostname.startsWith('supabase_')
        || u.hostname === 'kong'
      publicSupabaseUrl = isInternalHost ? 'http://127.0.0.1:54321' : SUPABASE_URL
    } catch {
      publicSupabaseUrl = SUPABASE_URL
    }

    function rewriteSignedUrl(url: string): string {
      try {
        const parsed = new URL(url)
        // If the URL hostname looks like an internal Docker hostname,
        // swap the origin with publicSupabaseUrl.
        const isInternal = !parsed.hostname.includes('.')
          || parsed.hostname === 'localhost'
          || parsed.hostname.startsWith('supabase_')
          || parsed.hostname === 'kong'
        if (isInternal) {
          return publicSupabaseUrl + parsed.pathname + parsed.search
        }
        return url
      } catch {
        return url
      }
    }

    const feed = await Promise.all(
      (apps ?? []).map(async (app) => {
        let bundleUrl = app.bundle_url
        let cssUrl = app.css_url

        // If URLs are storage paths (not full URLs), generate signed download URLs
        if (bundleUrl && !bundleUrl.startsWith('http')) {
          const { data } = await supabase.storage
            .from('app-bundles')
            .createSignedUrl(bundleUrl, 3600) // 1 hour expiry
          if (data?.signedUrl) bundleUrl = rewriteSignedUrl(data.signedUrl)
        }

        if (cssUrl && !cssUrl.startsWith('http')) {
          const { data } = await supabase.storage
            .from('app-bundles')
            .createSignedUrl(cssUrl, 3600)
          if (data?.signedUrl) cssUrl = rewriteSignedUrl(data.signedUrl)
        }

        return {
          slug: app.slug,
          name: app.name,
          icon: app.icon,
          bundle_url: bundleUrl,
          css_url: cssUrl,
          integrity_hash: app.integrity_hash,
          permissions_manifest: app.permissions_manifest,
          version: app.version,
          metadata: app.metadata,
          channel: app.loading_mode === 'preview' ? 'preview' : 'production',
        }
      })
    )

    return new Response(JSON.stringify({ apps: feed }), {
      status: 200,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...makeCorsHeaders(req), 'Content-Type': 'application/json' },
    })
  }
})
