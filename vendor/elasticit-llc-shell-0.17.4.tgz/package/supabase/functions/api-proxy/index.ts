// Forwards external API calls with stored credentials
// Timeout: 30s, Retry: 3x on 5xx

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const ENCRYPTION_KEY = Deno.env.get('CREDENTIAL_ENCRYPTION_KEY')!
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const TIMEOUT_MS = 30_000
const MAX_RETRIES = 3

async function getKey(): Promise<CryptoKey> {
  const keyBytes = new Uint8Array(
    ENCRYPTION_KEY.match(/.{2}/g)!.map((b: string) => parseInt(b, 16))
  )
  return crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt'])
}

async function decrypt(encoded: string): Promise<string> {
  const key = await getKey()
  const combined = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0))
  const iv = combined.slice(0, 12)
  const ciphertext = combined.slice(12)
  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext)
  return new TextDecoder().decode(plaintext)
}

async function fetchWithRetry(url: string, init: RequestInit, retries = MAX_RETRIES): Promise<Response> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS)

  try {
    const res = await fetch(url, { ...init, signal: controller.signal })
    if (res.status >= 500 && retries > 0) {
      return fetchWithRetry(url, init, retries - 1)
    }
    return res
  } catch (err) {
    if (retries > 0 && (err as Error).name !== 'AbortError') {
      return fetchWithRetry(url, init, retries - 1)
    }
    throw err
  } finally {
    clearTimeout(timeout)
  }
}

Deno.serve(async (req) => {
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 })
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 })
  }

  const url = new URL(req.url)
  const provider = url.searchParams.get('provider')
  const targetPath = url.searchParams.get('path')
  if (!provider || !targetPath) {
    return new Response(JSON.stringify({ error: 'Missing provider or path' }), { status: 400 })
  }

  // Fetch credential for this provider
  const { data: cred, error: credError } = await supabase
    .from('credentials')
    .select('*')
    .eq('provider', provider)
    .single()

  if (credError || !cred) {
    return new Response(JSON.stringify({ error: `No credential found for provider: ${provider}` }), { status: 404 })
  }

  // Decrypt credential
  const decrypted = JSON.parse(await decrypt(cred.encrypted_data))
  const baseUrl = (cred.metadata as any)?.base_url ?? ''
  const targetUrl = `${baseUrl}${targetPath}`

  // Build forwarded headers
  const forwardHeaders = new Headers()
  forwardHeaders.set('Content-Type', req.headers.get('Content-Type') ?? 'application/json')

  // Apply credential
  if (cred.credential_type === 'bearer' || cred.credential_type === 'api_key') {
    forwardHeaders.set('Authorization', `Bearer ${decrypted.key ?? decrypted.token}`)
  } else if (cred.credential_type === 'basic') {
    const encoded = btoa(`${decrypted.username}:${decrypted.password}`)
    forwardHeaders.set('Authorization', `Basic ${encoded}`)
  }

  // Forward the request
  const body = ['GET', 'HEAD'].includes(req.method) ? undefined : await req.text()

  try {
    const res = await fetchWithRetry(targetUrl, {
      method: req.method,
      headers: forwardHeaders,
      body,
    })

    // Audit log the proxy call
    await supabase.from('audit_log').insert({
      user_id: user.id,
      user_email: user.email,
      action: 'proxy',
      resource_type: 'credential',
      resource_id: cred.id,
      metadata: { provider, path: targetPath, status: res.status },
    })

    const responseBody = await res.text()
    return new Response(responseBody, {
      status: res.status,
      headers: { 'Content-Type': res.headers.get('Content-Type') ?? 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Proxy request failed', detail: (err as Error).message }), { status: 502 })
  }
})
