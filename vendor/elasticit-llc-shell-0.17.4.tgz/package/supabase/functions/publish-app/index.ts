/**
 * publish-app — Publish an app bundle to the client portal.
 *
 * Accepts multipart/form-data with:
 *   - bundle (File, required): The built JS bundle
 *   - css (File, optional): The built CSS file
 *   - permissions (File, optional): permissions.json
 *   - manifest (File, optional): app.manifest.json (unified manifest — permissions + database config)
 *   - database (File, optional): database.json for schema-mode apps (legacy, prefer manifest)
 *   - migrations (File[], optional): SQL migration files referenced by database config
 *   - version (string, optional): Version string (defaults to package.json version)
 *   - channel (string, optional): "production" or "preview" (defaults to "production")
 *
 * Auth: Requires Bearer token from an admin user.
 * The service role key is used INTERNALLY — never exposed to the client.
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

// ---------------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------------

function getCorsOrigin(req: Request): string {
  return req.headers.get('Origin') ?? '*'
}

function corsHeaders(req: Request) {
  return {
    'Access-Control-Allow-Origin': getCorsOrigin(req),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  }
}

function jsonResponse(req: Request, body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), 'Content-Type': 'application/json' },
  })
}

// ---------------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------------

// ── Manifest validation ──
//
// Hard-rejects manifests with structural / security problems before any
// persistence happens. Mirror of the rules in validate.ts (template-side
// check) — the runtime check here is the backstop for clients who skip
// `npm run package` validation or whose Claude session ignored the
// CLAUDE.md guidance.
//
// Rules:
//  - PROXY_BLOCK_MISSING: database.mode='proxy' without database.proxy block.
//    publish-app would silently leave db_mode='none' and the app would fail
//    at runtime with "App not configured for proxy access".
//  - SERVICE_ROLE_KEY_FORBIDDEN: *_service_role_key entries in vault_secrets[]
//    for an external-API-only proxy app (allowed_tables=[], allowed_rpcs=[],
//    forward_to_functions=false). Service-role keys are admin-only and surface
//    as "Fill in" prompts on the client portal's Vault Secrets page when
//    declared — a security boundary violation.
//
// Returns an array of error objects; empty means valid.

interface ManifestValidationError {
  code: string
  message: string
  fix: string
}

function validateManifest(manifest: Record<string, unknown>): ManifestValidationError[] {
  const errors: ManifestValidationError[] = []
  const db = (manifest as any)?.database
  const slug = (manifest as any)?.slug ?? '<slug>'

  if (db?.mode === 'proxy' && !db.proxy) {
    errors.push({
      code: 'PROXY_BLOCK_MISSING',
      message: `database.mode is "proxy" but database.proxy block is missing — apps row would persist db_mode='none' and the app would fail at runtime.`,
      fix: `Add a database.proxy block with vault_prefix and either allowed_tables/allowed_rpcs (own remote Supabase) or api_config (external HTTP API).`,
    })
  }

  // Notifications array is required — apps must explicitly opt into "no
  // events" by declaring an empty array, not by omitting the field. The
  // empty-array case is reserved for apps that genuinely emit nothing
  // user-facing (e.g., a static dashboard). Most apps should declare
  // at least the error/alert events they fire.
  const notifications = (manifest as any)?.notifications
  if (notifications === undefined || notifications === null) {
    errors.push({
      code: 'NOTIFICATIONS_MISSING',
      message: `app.manifest.json is missing the required "notifications" field. Every app must declare which event types users can opt in to receive — even if the answer is "none" (declare an empty array).`,
      fix: `Add a "notifications" array to app.manifest.json. Example: "notifications": [{ "key": "sync_error", "label": "Sync error", "description": "When the sync fails" }]. To explicitly opt out, use "notifications": [].`,
    })
  } else if (!Array.isArray(notifications)) {
    errors.push({
      code: 'NOTIFICATIONS_BAD_SHAPE',
      message: `app.manifest.json "notifications" must be an array.`,
      fix: `Change "notifications" to an array of { key, label, description? } entries.`,
    })
  } else {
    const seen = new Set<string>()
    for (let i = 0; i < notifications.length; i++) {
      const n = notifications[i]
      if (!n || typeof n !== 'object') {
        errors.push({
          code: 'NOTIFICATION_BAD_ENTRY',
          message: `notifications[${i}] is not an object.`,
          fix: `Each entry must be { "key": "...", "label": "...", "description"?: "..." }.`,
        })
        continue
      }
      if (typeof n.key !== 'string' || !/^[a-z][a-z0-9_]*$/.test(n.key)) {
        errors.push({
          code: 'NOTIFICATION_BAD_KEY',
          message: `notifications[${i}].key "${n.key}" must match /^[a-z][a-z0-9_]*$/ (snake_case, starts with a letter).`,
          fix: `Rename the key. The full event_type sent to send-notification is "${slug}:${n.key}".`,
        })
      } else if (seen.has(n.key)) {
        errors.push({
          code: 'NOTIFICATION_DUPLICATE_KEY',
          message: `notifications[] has duplicate key "${n.key}".`,
          fix: `Each event key must be unique within this app.`,
        })
      } else {
        seen.add(n.key)
      }
      if (typeof n.label !== 'string' || n.label.trim().length === 0) {
        errors.push({
          code: 'NOTIFICATION_NO_LABEL',
          message: `notifications[${i}] missing required "label".`,
          fix: `Add a short user-facing label (this is what users see next to the opt-in checkbox).`,
        })
      }
      // Reject the template stub so a still-uncustomized scaffold can't ship.
      if (n.key === 'example_event') {
        errors.push({
          code: 'NOTIFICATION_TEMPLATE_STUB',
          message: `notifications[${i}].key is still "example_event" — this is the template default.`,
          fix: `Replace the example_event stub with the actual events your app emits (or remove it entirely and declare "notifications": []).`,
        })
      }
    }
  }

  const proxy = db?.mode === 'proxy' ? db.proxy : null
  if (proxy) {
    const usesRemoteSupabase =
      (proxy.allowed_tables?.length ?? 0) > 0 ||
      (proxy.allowed_rpcs?.length ?? 0) > 0 ||
      proxy.forward_to_functions === true

    const vaultKeys: string[] = ((manifest as any)?.vault_secrets ?? []).map((v: any) => v.key)
    const dangerousKeys = vaultKeys.filter(k => /_service_role_key$/.test(k))

    if (!usesRemoteSupabase && dangerousKeys.length > 0) {
      errors.push({
        code: 'SERVICE_ROLE_KEY_FORBIDDEN',
        message: `vault_secrets[] declares ${dangerousKeys.join(', ')} but this proxy app does not use a remote Supabase project (allowed_tables=[], allowed_rpcs=[], forward_to_functions=false). Service role keys are admin-only and must never be exposed to clients via the Vault Secrets admin page.`,
        fix: `Remove the *_service_role_key entries from vault_secrets[]. Vendor API credentials live in Credential Vault via credential_requirements[] (looked up by app_id at runtime), not vault_secrets[].`,
      })
    }
  }

  return errors
}

async function verifyAdmin(req: Request) {
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return { user: null, error: 'Missing or invalid Authorization header' }
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)

  if (authError || !user) {
    return { user: null, error: 'Invalid or expired token' }
  }

  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'admin') {
    return { user: null, error: 'Admin role required' }
  }

  return { user, error: null }
}

// ---------------------------------------------------------------------------
// Phase 2B self-service helpers
// ---------------------------------------------------------------------------
// Each helper is best-effort: logs to the `log[]` array passed in and swallows
// its own errors so one failed step doesn't abort the whole upload. publish-app
// tracks pending-admin-input counters for the response + webhook payload.

const MGMT_API = 'https://api.supabase.com/v1'

function getProjectRef(): string | null {
  const match = SUPABASE_URL.match(/https:\/\/([a-z]+)\.supabase\.co/)
  return match?.[1] ?? null
}

async function fetchServiceRoleKey(
  projectRef: string,
  mgmtToken: string,
): Promise<string | null> {
  try {
    const res = await fetch(`${MGMT_API}/projects/${projectRef}/api-keys`, {
      headers: { 'Authorization': `Bearer ${mgmtToken}` },
    })
    if (!res.ok) return null
    const keys = await res.json() as Array<{ name: string; api_key: string }>
    return keys.find((k) => k.name === 'service_role')?.api_key ?? null
  } catch {
    return null
  }
}

// ── Edge function deploy ───────────────────────────────────────────────────

interface EdgeFunctionDecl {
  name: string
  entrypoint: string
  verify_jwt?: boolean
}

async function deployEdgeFunctions(
  functions: EdgeFunctionDecl[],
  formData: FormData,
  projectRef: string,
  mgmtToken: string,
  log: string[],
  supabaseClient?: any,
  storagePath?: string,
): Promise<{ deployed: number; failed: number }> {
  let deployed = 0
  let failed = 0
  for (const fn of functions) {
    try {
      // AppRegistryPage uploads function source as multipart field
      // `edge_function_<name>` containing the raw index.ts source.
      // Multi-file support can be added later via edge_function_<name>_file_<path> fields.
      const srcFile = formData.get(`edge_function_${fn.name}`) as File | null
      if (!srcFile) {
        log.push(`Edge function ${fn.name}: source not found in upload — skipping`)
        failed++
        continue
      }

      const source = await srcFile.text()
      const deployBody = new FormData()
      const metadata = {
        name: fn.name,
        verify_jwt: fn.verify_jwt ?? false,
        entrypoint_path: 'index.ts',
      }
      deployBody.append(
        'metadata',
        new Blob([JSON.stringify(metadata)], { type: 'application/json' }),
      )
      deployBody.append(
        'file',
        new Blob([source], { type: 'application/typescript' }),
        'index.ts',
      )

      const res = await fetch(
        `${MGMT_API}/projects/${projectRef}/functions/deploy?slug=${encodeURIComponent(fn.name)}`,
        {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${mgmtToken}` },
          body: deployBody,
        },
      )
      if (!res.ok) {
        const text = await res.text().catch(() => '')
        log.push(`Edge function ${fn.name}: deploy failed (${res.status}) ${text.slice(0, 200)}`)
        failed++
        continue
      }
      const data = await res.json()
      log.push(`Edge function deployed: ${fn.name} (version ${data.version})`)
      deployed++

      // Store the source in Storage so future rollbacks can re-deploy it.
      // Path: app-bundles/{slug}/{version}/edge-functions/{fn.name}.ts
      if (supabaseClient && storagePath) {
        try {
          const storageFnPath = `${storagePath}/edge-functions/${fn.name}.ts`
          await supabaseClient.storage
            .from('app-bundles')
            .upload(storageFnPath, new TextEncoder().encode(source), {
              contentType: 'application/typescript',
              upsert: true,
            })
        } catch { /* non-critical — rollback for this version won't have source */ }
      }
    } catch (err) {
      log.push(`Edge function ${fn.name}: ${err instanceof Error ? err.message : String(err)}`)
      failed++
    }
  }
  return { deployed, failed }
}

// ── Vault secret provisioning ───────────────────────────────────────────────

interface VaultSecretDecl {
  name?: string
  key?: string // legacy alias
  source?: 'service_role' | 'project_url' | 'literal' | 'admin-input'
  value?: string
  description?: string
}

async function provisionVaultSecrets(
  secrets: VaultSecretDecl[],
  projectRef: string,
  mgmtToken: string,
  serviceRoleKey: string | null,
  log: string[],
): Promise<{ created: number; updated: number; pendingAdminInput: number }> {
  let created = 0
  let updated = 0
  let pendingAdminInput = 0

  for (const decl of secrets) {
    const name = decl.name ?? decl.key
    if (!name) {
      log.push(`Vault secret: entry missing name — skipping`)
      continue
    }
    const source = decl.source ?? 'admin-input'
    if (source === 'admin-input') {
      pendingAdminInput++
      log.push(`Vault secret pending admin input: ${name}`)
      continue
    }

    let value: string | null = null
    if (source === 'service_role') {
      value = serviceRoleKey
      if (!value) {
        log.push(`Vault secret ${name}: service_role key unavailable — skipped`)
        continue
      }
    } else if (source === 'project_url') {
      value = `https://${projectRef}.supabase.co`
    } else if (source === 'literal') {
      value = decl.value ?? null
      if (!value) {
        log.push(`Vault secret ${name}: literal source but no value provided — skipped`)
        continue
      }
    }

    try {
      // Check if secret exists, then create or update idempotently via SQL.
      const description = (decl.description ?? '').replace(/'/g, "''")
      const valueEscaped = value!.replace(/'/g, "''")
      const sql = `
        DO $do$
        DECLARE v_existing uuid;
        BEGIN
          SELECT id INTO v_existing FROM vault.secrets WHERE name = '${name.replace(/'/g, "''")}';
          IF v_existing IS NULL THEN
            PERFORM vault.create_secret('${valueEscaped}', '${name.replace(/'/g, "''")}', '${description}');
          ELSE
            PERFORM vault.update_secret(v_existing, '${valueEscaped}', '${name.replace(/'/g, "''")}', '${description}');
          END IF;
        END;
        $do$;
      `
      const res = await fetch(
        `${MGMT_API}/projects/${projectRef}/database/query`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${mgmtToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ query: sql }),
        },
      )
      if (!res.ok) {
        const text = await res.text().catch(() => '')
        log.push(`Vault secret ${name}: failed (${res.status}) ${text.slice(0, 200)}`)
        continue
      }
      created++
      log.push(`Vault secret provisioned: ${name} (${source})`)
    } catch (err) {
      log.push(`Vault secret ${name}: ${err instanceof Error ? err.message : String(err)}`)
    }
  }
  return { created, updated, pendingAdminInput }
}

// ── _config table seeding ───────────────────────────────────────────────────

interface ConfigDecl {
  key: string
  source: 'project_url' | 'literal' | 'admin-input'
  value?: string
}

async function seedConfigTable(
  supabase: ReturnType<typeof createClient>,
  schemaName: string,
  entries: ConfigDecl[],
  projectRef: string,
  log: string[],
): Promise<number> {
  let seeded = 0
  for (const entry of entries) {
    let value: string | null = null
    if (entry.source === 'project_url') {
      value = `https://${projectRef}.supabase.co`
    } else if (entry.source === 'literal') {
      value = entry.value ?? null
    } else if (entry.source === 'admin-input') {
      log.push(`Config ${entry.key}: admin-input source — admin seeds manually`)
      continue
    }
    if (value === null) continue

    const escapedVal = value.replace(/'/g, "''")
    const escapedKey = entry.key.replace(/'/g, "''")
    const sql = `
      INSERT INTO ${schemaName}._config (key, value) VALUES ('${escapedKey}', '${escapedVal}')
      ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;
    `
    const { error } = await supabase.rpc('exec_sql', { sql })
    if (error) {
      log.push(`Config ${entry.key}: ${error.message}`)
    } else {
      seeded++
      // Log the key + source only — never the resolved value. Even non-secret
      // values (project URLs, tenant IDs) can leak client identity when the
      // log is surfaced in UIs, webhook payloads, or support tickets.
      log.push(`Config seeded: ${entry.key} (source: ${entry.source})`)
    }
  }
  return seeded
}

// ── Credential placeholder creation ────────────────────────────────────────

interface CredentialReq {
  provider: string
  label: string
  credential_type: 'bearer' | 'api_key' | 'oauth2' | 'oauth2_auth_code' | 'database'
  description?: string
  metadata?: Record<string, unknown>
}

async function createCredentialPlaceholders(
  supabase: ReturnType<typeof createClient>,
  appId: string,
  userId: string,
  requirements: CredentialReq[],
  log: string[],
): Promise<number> {
  let placeholdersCreated = 0
  for (const req of requirements) {
    // Idempotency: skip if a credential with matching provider already exists for this app
    const { data: existing } = await supabase
      .from('credentials')
      .select('id, metadata')
      .eq('app_id', appId)
      .eq('provider', req.provider)
      .maybeSingle()

    if (existing) {
      log.push(`Credential ${req.provider}: already linked (id=${existing.id}) — skipped`)
      continue
    }

    const { error } = await supabase.from('credentials').insert({
      provider: req.provider,
      label: req.label,
      credential_type: req.credential_type,
      encrypted_data: '', // placeholder — admin fills via Credential Vault UI
      app_id: appId,
      created_by: userId,
      verified: false,
      metadata: {
        ...(req.metadata ?? {}),
        placeholder: true,
        provisioned_by: 'publish-app',
        description: req.description ?? null,
      },
    })
    if (error) {
      log.push(`Credential ${req.provider}: ${error.message}`)
    } else {
      placeholdersCreated++
      log.push(`Credential placeholder created: ${req.label} (${req.credential_type}) — admin must fill in Credential Vault`)
    }
  }
  return placeholdersCreated
}

// ── Post-deploy hooks ──────────────────────────────────────────────────────

interface PostDeployHook {
  type: 'invoke_function'
  function?: string
  body?: Record<string, unknown>
  async?: boolean
  require_all_credentials_set?: boolean
}

async function runPostDeployHooks(
  hooks: PostDeployHook[],
  appId: string,
  supabase: ReturnType<typeof createClient>,
  projectRef: string,
  serviceRoleKey: string | null,
  log: string[],
): Promise<{ ran: number; skipped: number }> {
  let ran = 0
  let skipped = 0

  // Check for placeholder credentials once — relevant for
  // require_all_credentials_set hooks.
  const { data: placeholderCreds } = await supabase
    .from('credentials')
    .select('id, provider')
    .eq('app_id', appId)
    .filter('metadata->>placeholder', 'eq', 'true')
  const hasPlaceholders = (placeholderCreds ?? []).length > 0

  for (const hook of hooks) {
    if (hook.type !== 'invoke_function') {
      log.push(`Post-deploy hook: unsupported type ${hook.type} — skipped`)
      skipped++
      continue
    }
    if (!hook.function) {
      log.push(`Post-deploy hook: missing function name — skipped`)
      skipped++
      continue
    }
    if (hook.require_all_credentials_set && hasPlaceholders) {
      log.push(
        `Post-deploy hook ${hook.function}: deferred until placeholder credentials are filled`,
      )
      skipped++
      continue
    }

    const fnUrl = `https://${projectRef}.supabase.co/functions/v1/${hook.function}`
    const hookBody = { ...(hook.body ?? {}), app_id: appId }
    const invokeKey = serviceRoleKey ?? SUPABASE_SERVICE_ROLE_KEY

    const promise = fetch(fnUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${invokeKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(hookBody),
      signal: AbortSignal.timeout(30_000),
    })
      .then(async (res) => {
        if (!res.ok) {
          const text = await res.text().catch(() => '')
          console.warn(`[publish-app] Post-deploy hook ${hook.function} returned ${res.status}: ${text.slice(0, 200)}`)
        }
      })
      .catch((err) => {
        console.warn(`[publish-app] Post-deploy hook ${hook.function} error: ${err?.message ?? err}`)
      })

    if (hook.async !== false) {
      // Fire-and-forget via EdgeRuntime.waitUntil so publish-app returns fast
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const edge = (globalThis as any).EdgeRuntime
      if (edge?.waitUntil) edge.waitUntil(promise)
      log.push(`Post-deploy hook queued (async): ${hook.function}`)
    } else {
      await promise
      log.push(`Post-deploy hook invoked (sync): ${hook.function}`)
    }
    ran++
  }

  return { ran, skipped }
}

// ── ElasticIT upload webhook ───────────────────────────────────────────────

interface WebhookPayload {
  title: string
  trigger: 'app.publish'
  client_ref: string
  app_slug: string
  app_name: string
  app_version: string
  channel: string
  uploaded_by: { id: string; email: string }
  timestamp: string
  success: boolean
  summary: string
  log: string[]
  needs_admin_attention: boolean
  credential_placeholders_pending: number
  vault_secrets_pending_admin_input: number
  error: string | null
}

async function notifyUploadWebhook(payload: WebhookPayload): Promise<void> {
  const url = Deno.env.get('ELASTICIT_UPLOAD_WEBHOOK_URL')
  if (!url) return // silently skip if not configured

  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(5_000),
    })
  } catch (err) {
    // Don't fail the upload because the webhook failed
    console.warn(
      `[publish-app] Upload webhook failed: ${err instanceof Error ? err.message : String(err)}`,
    )
  }
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders(req) })
  }

  if (req.method !== 'POST') {
    return jsonResponse(req, { error: 'Method not allowed' }, 405)
  }

  // 1. Auth check
  const { user, error: authErr } = await verifyAdmin(req)
  if (authErr || !user) {
    const status = authErr === 'Admin role required' ? 403 : 401
    return jsonResponse(req, { error: authErr }, status)
  }

  // 1b. Action routing — non-upload endpoints (admin-only, same bearer token).
  // Used by the Admin UI to re-trigger post-deploy hooks after an admin fills
  // in placeholder credentials without re-uploading the whole .eitapp.
  const url = new URL(req.url)
  const action = url.searchParams.get('action')
  if (action === 'run-deferred-hooks') {
    const body = await req.json().catch(() => ({}))
    const appId = (body as Record<string, unknown>)?.app_id
    if (!appId || typeof appId !== 'string') {
      return jsonResponse(req, { error: 'Missing app_id in body' }, 400)
    }

    const supabaseClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    const { data: app, error: appErr } = await supabaseClient
      .from('apps')
      .select('id, slug, schema_config')
      .eq('id', appId)
      .single()
    if (appErr || !app) {
      return jsonResponse(req, { error: 'App not found' }, 404)
    }

    const storedHooks = (app.schema_config as any)?.post_deploy_hooks as
      | PostDeployHook[]
      | undefined
    if (!storedHooks || storedHooks.length === 0) {
      return jsonResponse(req, {
        ok: true,
        ran: 0,
        skipped: 0,
        message: 'No post_deploy_hooks persisted for this app — nothing to re-trigger.',
      })
    }

    const projectRef = getProjectRef()
    const mgmtToken =
      Deno.env.get('SB_MANAGEMENT_TOKEN') || Deno.env.get('SUPABASE_ACCESS_TOKEN') || ''
    const serviceRoleKey =
      projectRef && mgmtToken ? await fetchServiceRoleKey(projectRef, mgmtToken) : null

    const log: string[] = []
    const result = await runPostDeployHooks(
      storedHooks,
      app.id as string,
      supabaseClient,
      projectRef ?? '',
      serviceRoleKey,
      log,
    )

    await supabaseClient.from('audit_log').insert({
      user_id: user.id,
      action: 'app_deferred_hooks_run',
      details: { app_id: app.id, slug: app.slug, ...result, log },
    })

    return jsonResponse(req, { ok: true, ...result, log })
  }

  // 1c. Server-side rollback — swaps bundle, re-deploys old edge functions,
  // and re-triggers post-deploy hooks. Called by AppFeedManager "Deploy" button.
  if (action === 'rollback') {
    const body = await req.json().catch(() => ({}))
    const { app_id: appId, version: targetVersion } = body as Record<string, unknown>
    if (!appId || typeof appId !== 'string' || !targetVersion || typeof targetVersion !== 'string') {
      return jsonResponse(req, { error: 'Missing app_id or version in body' }, 400)
    }

    const supabaseClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    const log: string[] = []

    // Look up the target version from app_versions
    const { data: ver, error: verErr } = await (supabaseClient as any)
      .from('app_versions')
      .select('*')
      .eq('app_id', appId)
      .eq('version', targetVersion)
      .single()
    if (verErr || !ver) {
      return jsonResponse(req, { error: `Version ${targetVersion} not found` }, 404)
    }

    // Look up the current app row for slug and schema_config
    const { data: app, error: appErr } = await supabaseClient
      .from('apps')
      .select('id, slug, version, schema_config')
      .eq('id', appId)
      .single()
    if (appErr || !app) {
      return jsonResponse(req, { error: 'App not found' }, 404)
    }
    const fromVersion = app.version

    // Step 1: Swap bundle pointers on apps row
    const { error: updateErr } = await (supabaseClient as any)
      .from('apps')
      .update({
        bundle_url: ver.bundle_url,
        css_url: ver.css_url,
        integrity_hash: ver.integrity_hash,
        version: ver.version,
        loading_mode: ver.channel === 'preview' ? 'preview' : 'remote',
        metadata: { rolled_back_at: new Date().toISOString(), rolled_back_to: ver.version, rolled_back_from: fromVersion },
      })
      .eq('id', appId)
    if (updateErr) {
      return jsonResponse(req, { error: `Bundle swap failed: ${updateErr.message}` }, 500)
    }
    log.push(`Bundle rolled back: v${fromVersion} → v${targetVersion}`)

    const projectRef = getProjectRef()
    const mgmtToken = Deno.env.get('SB_MANAGEMENT_TOKEN') || Deno.env.get('SUPABASE_ACCESS_TOKEN') || ''

    // Step 2: Re-deploy edge functions from stored sources
    const edgeFunctions = (ver.metadata as any)?.edge_functions as EdgeFunctionDecl[] | undefined
    if (edgeFunctions && edgeFunctions.length > 0 && projectRef && mgmtToken) {
      const slug = app.slug as string
      const versionPath = `${slug}/${targetVersion}`
      let fnDeployed = 0
      let fnFailed = 0

      for (const fn of edgeFunctions) {
        try {
          // Read stored source from Storage
          const fnPath = `${versionPath}/edge-functions/${fn.name}.ts`
          const { data: srcData, error: dlErr } = await supabaseClient.storage
            .from('app-bundles')
            .download(fnPath)

          if (dlErr || !srcData) {
            log.push(`Edge function ${fn.name}: source not found in storage (${fnPath}) — skipping. This version was published before rollback support was added.`)
            fnFailed++
            continue
          }

          const source = await srcData.text()
          const deployBody = new FormData()
          deployBody.append('metadata', new Blob([JSON.stringify({ name: fn.name, verify_jwt: fn.verify_jwt ?? false, entrypoint_path: 'index.ts' })], { type: 'application/json' }))
          deployBody.append('file', new Blob([source], { type: 'application/typescript' }), 'index.ts')

          const res = await fetch(`${MGMT_API}/projects/${projectRef}/functions/deploy?slug=${encodeURIComponent(fn.name)}`, { method: 'POST', headers: { 'Authorization': `Bearer ${mgmtToken}` }, body: deployBody })
          if (!res.ok) {
            const text = await res.text().catch(() => '')
            log.push(`Edge function ${fn.name}: re-deploy failed (${res.status}) ${text.slice(0, 200)}`)
            fnFailed++
            continue
          }
          log.push(`Edge function re-deployed: ${fn.name}`)
          fnDeployed++
        } catch (err: any) {
          log.push(`Edge function ${fn.name}: error — ${err?.message ?? err}`)
          fnFailed++
        }
      }
      log.push(`Edge functions: ${fnDeployed} re-deployed, ${fnFailed} failed/skipped`)
    } else if (edgeFunctions && edgeFunctions.length > 0) {
      log.push(`Warning: ${edgeFunctions.length} edge functions declared but SB_MANAGEMENT_TOKEN not set — skipping re-deploy`)
    } else {
      log.push('No edge functions to re-deploy')
    }

    // Step 3: Re-trigger post-deploy hooks
    const hooks = (ver.metadata as any)?.post_deploy_hooks as PostDeployHook[] | undefined
    const storedHooks = hooks ?? ((app.schema_config as any)?.post_deploy_hooks as PostDeployHook[] | undefined)
    if (storedHooks && storedHooks.length > 0 && projectRef) {
      const serviceRoleKey = mgmtToken ? await fetchServiceRoleKey(projectRef, mgmtToken) : null
      await runPostDeployHooks(storedHooks, appId, supabaseClient, projectRef, serviceRoleKey, log)
    } else {
      log.push('No post-deploy hooks to re-trigger')
    }

    // Audit log
    await supabaseClient.from('audit_log').insert({
      user_id: user.id,
      action: 'app_rollback',
      details: { app_id: appId, slug: app.slug, from_version: fromVersion, to_version: targetVersion, log },
    })

    return jsonResponse(req, { ok: true, from_version: fromVersion, to_version: targetVersion, log })
  }

  // 2. Parse multipart form data
  let formData: FormData
  try {
    formData = await req.formData()
  } catch {
    return jsonResponse(req, { error: 'Invalid form data. Send multipart/form-data.' }, 400)
  }

  const bundleFile = formData.get('bundle') as File | null
  const cssFile = formData.get('css') as File | null
  const permissionsFile = formData.get('permissions') as File | null
  const manifestFile = formData.get('manifest') as File | null
  const databaseFile = formData.get('database') as File | null
  const version = (formData.get('version') as string) || '0.1.0'
  const channel = ((formData.get('channel') as string) || 'production') as 'production' | 'preview'
  const slugOverride = (formData.get('slug') as string) || ''

  if (!bundleFile) {
    return jsonResponse(req, { error: 'Missing required field: bundle (JS file)' }, 400)
  }

  // 3. Parse app.manifest.json (unified manifest) and/or permissions.json
  let appManifest: Record<string, unknown> | null = null
  let permissionsManifest: Record<string, unknown> | null = null
  // Priority: explicit slug field > manifest/permissions slug > derived from filename
  let slug = slugOverride
  let appName = ''
  let appIcon = ''

  // Parse app.manifest.json first (source of truth)
  if (manifestFile) {
    try {
      appManifest = JSON.parse(await manifestFile.text())
    } catch {
      return jsonResponse(req, { error: 'Invalid app.manifest.json' }, 400)
    }

    // Manifest validation — fail fast on hard structural / security violations.
    // Same rules as scripts/validate.ts (template-side); this is the backstop.
    const validationErrors = validateManifest(appManifest!)
    if (validationErrors.length > 0) {
      return jsonResponse(req, {
        error: 'Manifest validation failed',
        details: validationErrors,
      }, 400)
    }
  }

  // Parse permissions.json (backward compat / may override manifest for permissions)
  if (permissionsFile) {
    try {
      permissionsManifest = JSON.parse(await permissionsFile.text())
    } catch {
      return jsonResponse(req, { error: 'Invalid permissions.json' }, 400)
    }
  }

  // Resolve permissions: prefer permissions.json, fall back to app.manifest.json
  const effectivePerms = permissionsManifest ?? appManifest
  if (effectivePerms) {
    const permSlug = (effectivePerms as any)?.slug ?? ''
    appName = (effectivePerms as any)?.name ?? ''
    appIcon = (effectivePerms as any)?.icon ?? ''

    // Validate: slug mismatch check
    if (slugOverride && permSlug && slugOverride !== permSlug) {
      return jsonResponse(req, {
        error: `Slug mismatch: selected app is "${slugOverride}" but manifest has slug "${permSlug}". Upload the correct manifest or select the right app.`,
      }, 400)
    }
    if (!slug) slug = permSlug
  }
  // Use permissions.json structure for permissions_manifest column (what sync_app_permissions reads)
  if (!permissionsManifest && appManifest) {
    permissionsManifest = {
      slug: (appManifest as any)?.slug,
      name: (appManifest as any)?.name,
      icon: (appManifest as any)?.icon,
      permissions: (appManifest as any)?.permissions,
      pages: (appManifest as any)?.pages,
    }
  }

  if (!slug) {
    // Try to derive slug from bundle filename: index.js → use slug override or 'unknown'
    const name = bundleFile.name.replace(/\.js$/, '').replace(/-app$/, '').replace(/^index$/, '')
    slug = name || 'unknown'
  }
  if (!appName) {
    appName = slug.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(' ')
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const storagePath = `${slug}/${version}`
  const log: string[] = []

  // Precheck: refuse upload if the slug matches a soft-deleted app.
  // Without this guard, the upsert below would silently restore a deleted app
  // by overwriting its row — the operator must explicitly restore via the UI first.
  const { data: existing } = await supabase
    .from('apps')
    .select('id, slug, deleted_at, version')
    .eq('slug', slug)
    .maybeSingle()

  if (existing?.deleted_at) {
    return jsonResponse(
      req,
      {
        error: `App "${slug}" was deleted; restore via Admin > App Management before re-uploading.`,
      },
      409,
    )
  }

  const wasNewApp = !existing
  const previousVersion = (existing as { version?: string } | null)?.version ?? null

  try {
    // 4. Upload JS bundle to storage
    const bundleBuffer = new Uint8Array(await bundleFile.arrayBuffer())
    const hashBuffer = await crypto.subtle.digest('SHA-256', bundleBuffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const integrityHash = 'sha256-' + btoa(String.fromCharCode(...hashArray))

    const bundlePath = `${storagePath}/${bundleFile.name}`
    const { error: jsUploadErr } = await supabase.storage
      .from('app-bundles')
      .upload(bundlePath, bundleBuffer, {
        contentType: 'application/javascript',
        upsert: true,
      })
    if (jsUploadErr) throw new Error(`JS upload failed: ${jsUploadErr.message}`)
    log.push(`Uploaded bundle: app-bundles/${bundlePath}`)

    // 5. Upload CSS (optional)
    let cssPath: string | null = null
    if (cssFile) {
      const cssBuffer = new Uint8Array(await cssFile.arrayBuffer())
      cssPath = `${storagePath}/${cssFile.name}`
      const { error: cssUploadErr } = await supabase.storage
        .from('app-bundles')
        .upload(cssPath, cssBuffer, {
          contentType: 'text/css',
          upsert: true,
        })
      if (cssUploadErr) throw new Error(`CSS upload failed: ${cssUploadErr.message}`)
      log.push(`Uploaded CSS: app-bundles/${cssPath}`)
    }

    // 6. Upsert apps table
    const loadingMode = channel === 'preview' ? 'preview' : 'remote'
    const publishedAt = new Date().toISOString()
    // Infer app authorship from uploader email domain. Auth is Entra ID-backed,
    // so @elasticit.com implies an ElasticIT staff upload. Caveat: an ElasticIT
    // engineer re-publishing a client-authored app would flip managed_by to
    // 'elasticit' — rare enough to accept; backfill covers any miscategorisation.
    const isElasticIT = (user.email ?? '').toLowerCase().endsWith('@elasticit.com')

    const { data: upsertedApp, error: upsertErr } = await supabase
      .from('apps')
      .upsert({
        slug,
        name: appName,
        icon: appIcon || null,
        status: 'active',
        loading_mode: loadingMode,
        bundle_url: bundlePath,
        css_url: cssPath,
        integrity_hash: integrityHash,
        permissions_manifest: permissionsManifest,
        version,
        managed_by: isElasticIT ? 'elasticit' : 'client',
        metadata: {
          published_at: publishedAt,
          published_by: user.email,
          channel,
        },
      }, { onConflict: 'slug' })
      .select('id')
      .single()

    if (upsertErr) throw new Error(`Apps upsert failed: ${upsertErr.message}`)
    log.push(`Registered app: ${slug} v${version} (${loadingMode})`)

    // 7. Version history
    if (upsertedApp?.id) {
      const { error: versionErr } = await supabase
        .from('app_versions')
        .upsert({
          app_id: upsertedApp.id,
          version,
          channel,
          bundle_url: bundlePath,
          css_url: cssPath,
          integrity_hash: integrityHash,
          metadata: {
            published_at: publishedAt,
            published_by: user.email,
            edge_functions: (appManifest as any)?.edge_functions ?? [],
            post_deploy_hooks: (appManifest as any)?.post_deploy_hooks ?? [],
          },
          published_by: user.email,
        }, { onConflict: 'app_id,version' })

      if (versionErr) {
        log.push(`Version history warning: ${versionErr.message}`)
      } else {
        log.push(`Version history: ${version} (${channel})`)
      }
    }

    // 8. Sync permissions
    if (permissionsManifest) {
      const manifests: Record<string, unknown> = { [slug]: permissionsManifest }
      const { error: syncErr } = await supabase.rpc('sync_app_permissions', {
        manifests,
      })
      if (syncErr) {
        log.push(`Permission sync warning: ${syncErr.message}`)
      } else {
        log.push(`Permissions synced: ${(permissionsManifest as any)?.permissions?.length ?? 0} permissions`)
      }
    }

    // 8b. Sync notifications catalog — declares the event types this app
    // emits that users can opt in to receive. The Notifications admin page
    // reads from app_notifications and renders one accordion section per
    // app with at least one row here.
    const manifestNotifications = (appManifest as any)?.notifications
    if (Array.isArray(manifestNotifications)) {
      // Truthy-array → upsert each row keyed by (app_slug, key). Items
      // removed from the manifest stay in the catalog (orphan cleanup
      // would require a delete-by-set-difference; deferred for now since
      // the cost of stale rows is small — they just show as opt-in options
      // that never fire).
      const rows = manifestNotifications
        .filter((n: any) => typeof n?.key === 'string' && typeof n?.label === 'string')
        .map((n: any, idx: number) => ({
          app_slug: slug,
          key: n.key,
          label: n.label,
          description: typeof n.description === 'string' ? n.description : null,
          sort_order: typeof n.sort_order === 'number' ? n.sort_order : idx,
        }))
      if (rows.length > 0) {
        const { error: notifErr } = await (supabase.from('app_notifications') as any)
          .upsert(rows, { onConflict: 'app_slug,key' })
        if (notifErr) {
          log.push(`Notification catalog sync warning: ${notifErr.message}`)
        } else {
          log.push(`Notifications synced: ${rows.length} event type${rows.length === 1 ? '' : 's'}`)
        }
      }
    }

    // 9. Handle database config (app.manifest.json database field → fallback database.json)
    let dbConfig: any = null

    // Priority: app.manifest.json database section (schema mode)
    if (appManifest && (appManifest as any)?.database?.mode === 'schema') {
      dbConfig = (appManifest as any).database
    }
    // Proxy mode: write db_mode + proxy_config straight to apps row from
    // manifest.database.proxy. The manifest's `proxy` block is the source
    // of truth for what app-proxy/index.ts:getProxyConfig() reads at runtime.
    // Without this branch, manifest-declared proxy mode silently leaves the
    // apps row at db_mode='none' and proxy_config=null, producing the
    // "App not found or not configured for proxy access" runtime error.
    else if (appManifest && (appManifest as any)?.database?.mode === 'proxy') {
      const proxyBlock = (appManifest as any).database.proxy
      if (proxyBlock) {
        log.push(`Database config: proxy mode (vault_prefix=${proxyBlock.vault_prefix ?? '<none>'})`)
        const { error: proxyErr } = await supabase
          .from('apps')
          .update({
            db_mode: 'proxy',
            proxy_config: proxyBlock,
            db_status: 'active',
          } as any)
          .eq('slug', slug)
        if (proxyErr) {
          log.push(`Warning: could not write proxy_config for ${slug}: ${proxyErr.message}`)
        }
      } else {
        log.push('Warning: database.mode is "proxy" but database.proxy block is missing — apps row will keep db_mode=none')
      }
    }
    // Fallback: separate database.json file
    if (!dbConfig && databaseFile) {
      try {
        dbConfig = JSON.parse(await databaseFile.text())
      } catch {
        log.push('Warning: Invalid database.json — skipping schema setup')
      }
    }

    if (dbConfig?.schema) {
      log.push(`Database config: schema=${dbConfig.schema}`)

      // Create schema (also sets up default RLS via event trigger)
      const { error: schemaErr } = await supabase.rpc('create_app_schema', {
        p_schema_name: dbConfig.schema,
      })
      if (schemaErr) {
        log.push(`Schema creation warning: ${schemaErr.message}`)
      } else {
        log.push(`Schema created: ${dbConfig.schema}`)
      }

      // Get current migration version
      const { data: appRow } = await supabase
        .from('apps')
        .select('schema_config')
        .eq('slug', slug)
        .single()
      let currentVersion = (appRow?.schema_config as any)?.migration_version ?? 0

      // Verify the schema actually has the expected tables. If it was dropped
      // externally (e.g., manual DROP SCHEMA, or remove_app_schema without
      // resetting schema_config), migration_version is stale — reset to 0 so
      // all migrations re-run against the freshly re-created schema.
      if (currentVersion > 0) {
        const { data: actualTableCount } = await supabase.rpc('get_schema_table_count', {
          p_schema_name: dbConfig.schema,
        })
        const expectedTables = (dbConfig.tables ?? []).length
        if (expectedTables > 0 && (actualTableCount ?? 0) < expectedTables) {
          log.push(
            `Schema ${dbConfig.schema} has ${actualTableCount ?? 0} tables but manifest expects ${expectedTables}. ` +
            `Resetting migration_version to 0 and re-applying all migrations.`
          )
          currentVersion = 0
        }
      }

      // Apply pending migrations. Track SUCCESSFULLY-applied versions
      // separately so we don't advance schema_config for a migration that
      // failed mid-way (which would make the next publish-app run skip the
      // failing migration and leave the schema in an inconsistent state).
      const pending = (dbConfig.migrations ?? []).filter(
        (m: any) => m.version > currentVersion
      )
      const successfullyApplied: number[] = []
      let migrationFailed = false

      for (const migration of pending) {
        // Look for migration file in the form data
        const migFile = formData.get(`migration_${migration.version}`) as File | null
        if (!migFile) {
          log.push(`Warning: Migration v${migration.version} file not found in upload — skipping`)
          continue
        }

        const sql = await migFile.text()
        const fullSql = `SET search_path TO ${dbConfig.schema}, public;\n${sql}`

        const { error: migErr } = await supabase.rpc('exec_sql', { sql: fullSql })
        if (migErr) {
          log.push(`Migration v${migration.version} FAILED: ${migErr.message}`)
          await supabase
            .from('apps')
            .update({ db_status: 'error', db_status_detail: migErr.message } as any)
            .eq('slug', slug)
          migrationFailed = true
          break
        }
        log.push(`Applied migration v${migration.version}: ${migration.description}`)
        successfullyApplied.push(migration.version)
      }

      // Apply RLS per-table overrides (if declared — default RLS is already set by create_app_schema)
      for (const table of dbConfig.tables ?? []) {
        if (table.rls?.read === 'admin' || table.rls?.write === 'admin') {
          const { error: rlsErr } = await supabase.rpc('apply_app_rls', {
            p_schema_name: dbConfig.schema,
            p_table_name: table.name,
            p_read_policy: table.rls?.read ?? 'authenticated',
            p_write_policy: table.rls?.write ?? 'authenticated',
          })
          if (rlsErr) {
            log.push(`RLS warning for ${table.name}: ${rlsErr.message}`)
          }
        }
      }

      // Update schema_config based ONLY on successfully-applied migrations.
      // If a migration failed, migration_version stays at the last successful
      // version — next publish-app run will retry the failed migration.
      const latestVersion = successfullyApplied.length > 0
        ? successfullyApplied[successfullyApplied.length - 1]
        : currentVersion

      // If we reset currentVersion to 0 (schema was missing), start
      // migrations_applied fresh — don't keep stale history.
      const priorApplied = currentVersion === 0
        ? []
        : ((appRow?.schema_config as any)?.migrations_applied ?? [])

      const schemaConfig = {
        schema_name: dbConfig.schema,
        migration_version: latestVersion,
        migrations_applied: [
          ...priorApplied,
          ...successfullyApplied,
        ],
        last_migrated_at: new Date().toISOString(),
        tables: (dbConfig.tables ?? []).map((t: any) => t.name),
      }

      // When a migration failed mid-loop, keep db_status='error' (set inside
      // the loop). Only set 'active' when everything applied cleanly.
      const updatePayload: Record<string, unknown> = {
        db_mode: 'schema',
        schema_config: schemaConfig,
      }
      if (!migrationFailed) {
        updatePayload.db_status = 'active'
      }

      await supabase
        .from('apps')
        .update(updatePayload as any)
        .eq('slug', slug)

      log.push(`Schema config saved: ${dbConfig.schema} (v${latestVersion})`)
      if (migrationFailed) {
        log.push(
          `NOTE: one or more migrations failed — migration_version left at v${latestVersion}. ` +
          `Fix the failing migration and re-upload; publish-app will retry from that version.`
        )
      }

      // Auto-expose the schema via PostgREST. On managed Supabase,
      // create_app_schema can't ALTER ROLE (insufficient_privilege). Use the
      // Management API which runs as supabase_admin. Requires SUPABASE_ACCESS_TOKEN
      // stored as an edge function secret.
      const accessToken = Deno.env.get('SB_MANAGEMENT_TOKEN')
      if (accessToken) {
        try {
          const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? ''
          const projectRef = new URL(supabaseUrl).hostname.split('.')[0]

          // Get current schemas, add the new one if missing
          const queryRes = await fetch(
            `https://api.supabase.com/v1/projects/${projectRef}/database/query`,
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                query: `SELECT string_agg(unnest, ', ') AS schemas FROM unnest((SELECT setconfig FROM pg_db_role_setting JOIN pg_roles ON pg_roles.oid = setrole WHERE rolname = 'authenticator')) WHERE unnest LIKE 'pgrst.db_schemas=%'`,
              }),
            }
          )
          const queryData = await queryRes.json()
          let currentSchemas = 'public, storage, graphql_public'
          if (Array.isArray(queryData) && queryData[0]?.schemas) {
            currentSchemas = queryData[0].schemas.replace('pgrst.db_schemas=', '')
          }

          if (!currentSchemas.includes(dbConfig.schema)) {
            const newSchemas = `${currentSchemas}, ${dbConfig.schema}`
            await fetch(
              `https://api.supabase.com/v1/projects/${projectRef}/database/query`,
              {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${accessToken}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  query: `ALTER ROLE authenticator SET pgrst.db_schemas TO '${newSchemas}'; NOTIFY pgrst, 'reload schema';`,
                }),
              }
            )
            log.push(`Auto-exposed schema ${dbConfig.schema} via Management API`)
          } else {
            log.push(`Schema ${dbConfig.schema} already exposed in pgrst.db_schemas`)
          }
        } catch (err) {
          log.push(`Warning: Could not auto-expose schema (${err.message}). Add ${dbConfig.schema} manually via Supabase Dashboard > Settings > API > Exposed schemas.`)
        }
      } else {
        log.push(`Warning: SUPABASE_ACCESS_TOKEN not set. Add ${dbConfig.schema} to exposed schemas manually via Supabase Dashboard > Settings > API > Exposed schemas.`)
      }
    }

    // ------------------------------------------------------------------
    // Phase 2B — self-service provisioning steps. Each is best-effort and
    // logs its outcome to the `log` array. Counters feed the response and
    // the ElasticIT upload webhook so admins know if anything is pending.
    // ------------------------------------------------------------------
    const projectRef = getProjectRef()
    const mgmtToken = Deno.env.get('SB_MANAGEMENT_TOKEN') || Deno.env.get('SUPABASE_ACCESS_TOKEN') || ''

    let edgeFnsDeployed = 0
    let edgeFnsFailed = 0
    let secretsPendingAdminInput = 0
    let placeholdersCreated = 0

    // Service role key is needed by vault provisioning (to stash for pg_cron)
    // and by post-deploy hooks (to invoke other functions).
    const serviceRoleKey = projectRef && mgmtToken
      ? await fetchServiceRoleKey(projectRef, mgmtToken)
      : null

    // 10. Edge function auto-deploy
    const edgeFunctions = (appManifest as any)?.edge_functions as EdgeFunctionDecl[] | undefined
    if (edgeFunctions && edgeFunctions.length > 0) {
      if (!projectRef || !mgmtToken) {
        log.push(
          `Warning: ${edgeFunctions.length} edge functions declared but SB_MANAGEMENT_TOKEN not set — skipping deploy`,
        )
      } else {
        const result = await deployEdgeFunctions(edgeFunctions, formData, projectRef, mgmtToken, log, supabase, storagePath)
        edgeFnsDeployed = result.deployed
        edgeFnsFailed = result.failed
      }
    }

    // 11. Vault secret auto-provisioning
    const vaultSecrets = (appManifest as any)?.vault_secrets as VaultSecretDecl[] | undefined
    if (vaultSecrets && vaultSecrets.length > 0) {
      if (!projectRef || !mgmtToken) {
        log.push(`Warning: ${vaultSecrets.length} vault secrets declared but SB_MANAGEMENT_TOKEN not set — skipping`)
      } else {
        const result = await provisionVaultSecrets(vaultSecrets, projectRef, mgmtToken, serviceRoleKey, log)
        secretsPendingAdminInput = result.pendingAdminInput
      }
    }

    // 12. _config table seeding (schema mode only)
    const configEntries = (appManifest as any)?.config as ConfigDecl[] | undefined
    if (configEntries && configEntries.length > 0 && dbConfig?.schema) {
      if (!projectRef) {
        log.push(`Warning: config entries declared but cannot resolve project ref — skipping`)
      } else {
        await seedConfigTable(supabase, dbConfig.schema, configEntries, projectRef, log)
      }
    }

    // 13. Credential placeholder creation
    const credReqs = (appManifest as any)?.credential_requirements as CredentialReq[] | undefined
    if (credReqs && credReqs.length > 0 && upsertedApp?.id) {
      placeholdersCreated = await createCredentialPlaceholders(
        supabase,
        upsertedApp.id as string,
        user.id,
        credReqs,
        log,
      )
    }

    // 14. Post-deploy hooks (fire-and-forget via EdgeRuntime.waitUntil)
    const hooks = (appManifest as any)?.post_deploy_hooks as PostDeployHook[] | undefined
    if (hooks && hooks.length > 0 && upsertedApp?.id && projectRef) {
      await runPostDeployHooks(hooks, upsertedApp.id as string, supabase, projectRef, serviceRoleKey, log)
    }

    // 14b. Persist manifest-declared requirements on apps.schema_config so the
    // Admin UI can render pending-input badges and re-trigger deferred hooks
    // without re-reading the .eitapp from storage. Merged (not overwritten) so
    // schema-mode fields written earlier in this handler are preserved.
    if (upsertedApp?.id) {
      try {
        const { data: currentRow } = await supabase
          .from('apps')
          .select('schema_config')
          .eq('id', upsertedApp.id)
          .single()
        const mergedConfig = {
          ...((currentRow?.schema_config as Record<string, unknown>) ?? {}),
          vault_secret_requirements: vaultSecrets ?? [],
          credential_requirements: credReqs ?? [],
          post_deploy_hooks: hooks ?? [],
        }
        await supabase
          .from('apps')
          .update({ schema_config: mergedConfig } as any)
          .eq('id', upsertedApp.id)
      } catch (err) {
        log.push(`Warning: could not persist manifest requirements: ${err instanceof Error ? err.message : String(err)}`)
      }
    }

    // 15. Audit log (includes the full Phase 2B log)
    await supabase.from('audit_log').insert({
      user_id: user.id,
      action: 'app_published',
      details: { slug, version, channel, log },
    })

    // 16. ElasticIT upload webhook notification (fire-and-forget)
    const needsAdminAttention = placeholdersCreated > 0 || secretsPendingAdminInput > 0 || edgeFnsFailed > 0
    const summaryParts: string[] = []
    if (edgeFnsDeployed > 0) summaryParts.push(`${edgeFnsDeployed} edge function${edgeFnsDeployed === 1 ? '' : 's'} deployed`)
    if (edgeFnsFailed > 0) summaryParts.push(`${edgeFnsFailed} edge function${edgeFnsFailed === 1 ? '' : 's'} FAILED`)
    if (placeholdersCreated > 0) summaryParts.push(`${placeholdersCreated} credential placeholder${placeholdersCreated === 1 ? '' : 's'} created`)
    if (secretsPendingAdminInput > 0) summaryParts.push(`${secretsPendingAdminInput} vault secret${secretsPendingAdminInput === 1 ? '' : 's'} need admin input`)
    const summary = summaryParts.length > 0 ? summaryParts.join(', ') : 'app uploaded'

    const webhookPayload: WebhookPayload = {
      title: `App Upload — ${projectRef ?? '<unknown-ref>'} · ${slug} v${version}`,
      trigger: 'app.publish',
      client_ref: projectRef ?? '',
      app_slug: slug,
      app_name: appName ?? slug,
      app_version: version,
      channel,
      uploaded_by: { id: user.id, email: user.email ?? '' },
      timestamp: new Date().toISOString(),
      success: true,
      summary,
      log: log.slice(-50), // last 50 lines to keep payload small
      needs_admin_attention: needsAdminAttention,
      credential_placeholders_pending: placeholdersCreated,
      vault_secrets_pending_admin_input: secretsPendingAdminInput,
      error: null,
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const edge = (globalThis as any).EdgeRuntime
    if (edge?.waitUntil) edge.waitUntil(notifyUploadWebhook(webhookPayload))
    else await notifyUploadWebhook(webhookPayload)

    // Step 17: Fire app notification (fire-and-forget; doesn't gate the response).
    const notificationEvent = {
      event_type: wasNewApp ? 'app_published' : 'app_updated',
      app_slug: slug,
      app_name: appName ?? slug,
      app_version: version,
      previous_version: previousVersion,
      acted_by: user.email ?? undefined,
    }
    const notifyPromise = fetch(`${SUPABASE_URL}/functions/v1/send-notification`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(notificationEvent),
    }).catch((err) => console.error('[publish-app] send-notification failed:', err))
    if (edge?.waitUntil) edge.waitUntil(notifyPromise)

    return jsonResponse(req, {
      success: true,
      slug,
      version,
      channel,
      bundle_url: `app-bundles/${bundlePath}`,
      css_url: cssPath ? `app-bundles/${cssPath}` : null,
      integrity_hash: integrityHash,
      needs_admin_attention: needsAdminAttention,
      credential_placeholders_pending: placeholdersCreated,
      vault_secrets_pending_admin_input: secretsPendingAdminInput,
      log,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    // Best-effort failure webhook
    try {
      const projectRef = getProjectRef()
      await notifyUploadWebhook({
        title: `App Upload FAILED — ${projectRef ?? '<unknown-ref>'}`,
        trigger: 'app.publish',
        client_ref: projectRef ?? '',
        app_slug: '',
        app_name: '',
        app_version: '',
        channel: '',
        uploaded_by: { id: '', email: '' },
        timestamp: new Date().toISOString(),
        success: false,
        summary: `Upload failed: ${message}`,
        log: log.slice(-50),
        needs_admin_attention: true,
        credential_placeholders_pending: 0,
        vault_secrets_pending_admin_input: 0,
        error: message,
      })
    } catch { /* swallow */ }
    return jsonResponse(req, { error: message, log }, 500)
  }
})
