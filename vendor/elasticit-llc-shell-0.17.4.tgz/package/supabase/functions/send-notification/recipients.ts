// This module is shared between the Deno edge function and the vitest
// suite. It does NOT import from any Deno-specific globals — the Supabase
// client is passed in. The actual recipient query lives in a Postgres
// function so we benefit from one round-trip and proper RLS context.
// resolveRecipients just calls it.
//
// Recipients are derived from per-user preferences on
// user_profiles.settings.notifications. The Postgres function returns
// only users who explicitly opted in for the given event_type — opt-in
// is required, no defaults, no role inheritance.

export interface SupabaseLike {
  rpc(fn: string, args: Record<string, unknown>): Promise<{ data: unknown; error: unknown }>
}

export interface Recipient {
  user_id: string | null
  email: string
}

export async function resolveRecipients(
  supabase: SupabaseLike,
  eventType: string,
): Promise<Recipient[]> {
  const { data, error } = await supabase.rpc('resolve_notification_recipients', {
    p_event_type: eventType,
  })
  if (error) {
    console.error('[send-notification] resolveRecipients failed:', error)
    return []
  }
  if (!Array.isArray(data)) return []
  // PostgREST renders `RETURNS TABLE(user_id uuid, email text)` as
  // Array<{user_id, email}>. Some test mocks return Array<string>; tolerate
  // both for backwards compat with existing tests.
  const seen = new Set<string>()
  const out: Recipient[] = []
  for (const v of data) {
    let email: string | null = null
    let userId: string | null = null
    if (typeof v === 'string') {
      email = v
    } else if (v && typeof v === 'object') {
      const row = v as { email?: unknown; user_id?: unknown }
      if (typeof row.email === 'string') email = row.email
      if (typeof row.user_id === 'string') userId = row.user_id
    }
    if (!email) continue
    const k = email.toLowerCase()
    if (!k) continue
    if (seen.has(k)) continue
    seen.add(k)
    out.push({ user_id: userId, email: k })
  }
  return out
}
