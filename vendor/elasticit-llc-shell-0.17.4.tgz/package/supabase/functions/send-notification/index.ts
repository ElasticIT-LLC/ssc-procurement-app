// deno-lint-ignore-file no-explicit-any
//
// send-notification — sends app-event email notifications via M365 HVE.
//
// Authentication: AUTH LOGIN against smtp-hve.office365.com:587 with the
// shared HVE account (asp@elasticit.com) — same credentials across every
// portal. The password lives in this function's Supabase env var
// NOTIFICATION_HVE_PASSWORD; portal admins cannot read it (only the
// Supabase project owner can set it via `supabase secrets set`).
//
// Endpoint:
//   POST /
//     body: { event_type, app_slug?, app_name?, app_version?, acted_by? }
//
//     event_type takes either:
//     - 'test'                            (delivery test → sends only to acted_by)
//     - 'app_published' / 'app_updated'  (legacy — auto-prefixed to 'system:app_*' for resolution)
//     - 'app_deleted'
//     - 'system:<key>'                    (account/access etc. — hardcoded in shell)
//     - '<app-slug>:<key>'                (per-app — declared via app manifest, synced into app_notifications)
//
//   Auth: admin user JWT, or service-role JWT for the publish-app trigger.
//
// Recipient resolution: opt-in only. resolve_notification_recipients(event_type)
// returns users whose user_profiles.settings.notifications[event_type] = true.
// There is no master enable/disable — recipients alone decide.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { resolveRecipients, type Recipient } from './recipients.ts'
import { sendSmtp } from './smtp.ts'
import { buildEmail, buildInAppNotification, type AppEventMeta, type NotificationEvent } from './template.ts'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const HVE_PASSWORD = Deno.env.get('NOTIFICATION_HVE_PASSWORD') ?? ''

// HVE transport config — same across every portal, baked into code.
// The non-sensitive bits can change here in one place; the password
// rotates via `supabase secrets set NOTIFICATION_HVE_PASSWORD=... --project-ref <ref>`.
const HVE_HOST = 'smtp-hve.office365.com'
const HVE_PORT = 587
const HVE_USERNAME = 'asp@elasticit.com'
const HVE_FROM = 'asp@elasticit.com'
const HVE_USE_TLS = true

const MAX_RETRIES = 2
const BACKOFF_MS = [2000, 5000]

const corsHeaders = (origin: string) => ({
  'Access-Control-Allow-Origin': origin || '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
})

function jsonResponse(body: unknown, status: number, origin: string) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
  })
}

function isTransientSmtpError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err)
  return /ECONNRESET|ETIMEDOUT|ECONNREFUSED|TLS handshake timeout|EHOSTUNREACH|ENETUNREACH|connection closed/i.test(msg)
}

/** Translate the legacy unprefixed event_type strings (still emitted by
 *  publish-app and any current callers) into the prefixed catalog form
 *  the resolver expects. Already-prefixed inputs pass through untouched. */
function normalizeEventType(raw: string): string {
  if (raw.includes(':')) return raw
  if (raw === 'app_published' || raw === 'app_updated' || raw === 'app_deleted') {
    return `system:${raw}`
  }
  return raw
}

/** For per-app events ('<slug>:<key>'), fetch the human-readable app name
 *  from public.apps and the event label from public.app_notifications so
 *  email subject and bell title render as "{App}: {Event label}" instead
 *  of the raw slug/key. Returns null for system:* / access:* / lifecycle
 *  events, where there's no per-app catalog entry. */
async function fetchAppEventMeta(
  supabase: ReturnType<typeof createClient>,
  eventType: string,
): Promise<AppEventMeta | null> {
  if (!eventType.includes(':')) return null
  const [slug, ...rest] = eventType.split(':')
  if (!slug || slug === 'system' || slug === 'access') return null
  const key = rest.join(':')
  if (!key) return null

  const [appRow, catalogRow] = await Promise.all([
    supabase.from('apps').select('name').eq('slug', slug).maybeSingle(),
    supabase.from('app_notifications').select('label').eq('app_slug', slug).eq('key', key).maybeSingle(),
  ])
  return {
    appSlug: slug,
    appDisplayName: (appRow.data as { name?: string } | null)?.name ?? slug,
    eventLabel: (catalogRow.data as { label?: string } | null)?.label ?? key,
  }
}

Deno.serve(async (req) => {
  const origin = req.headers.get('origin') ?? ''
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders(origin) })
  }
  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405, origin)
  }

  // 1. Auth (admin user JWT or service-role JWT)
  const authHeader = req.headers.get('Authorization') ?? ''
  const token = authHeader.replace(/^Bearer\s+/i, '')
  if (!token) return jsonResponse({ error: 'Unauthorized' }, 401, origin)

  const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY)
  const isServiceRole = token === SERVICE_ROLE_KEY
  if (!isServiceRole) {
    const { data: { user }, error: authErr } = await supabaseAdmin.auth.getUser(token)
    if (authErr || !user) return jsonResponse({ error: 'Unauthorized' }, 401, origin)
    const { data: prof } = await supabaseAdmin
      .from('user_profiles').select('role').eq('id', user.id).single()
    if (prof?.role !== 'admin') return jsonResponse({ error: 'Admin only' }, 403, origin)
  }

  // 2. Parse event payload
  let event: NotificationEvent
  try {
    event = await req.json()
  } catch {
    return jsonResponse({ error: 'Invalid JSON' }, 400, origin)
  }

  const whenISO = new Date().toISOString()

  // 3. Client settings for the From: display name + body links
  const { data: settings } = await supabaseAdmin
    .from('client_settings').select('key, value').in('key', ['client_name', 'portal_url'])
  const settingsMap = new Map((settings ?? []).map((s: any) => [s.key, s.value]))
  const clientName = settingsMap.get('client_name') ?? ''
  const portalUrl = settingsMap.get('portal_url') ?? ''

  // 4. Resolve recipients
  let recipientList: Recipient[]
  if (event.event_type === 'test') {
    if (!event.acted_by) {
      return jsonResponse({ error: 'test event missing acted_by' }, 400, origin)
    }
    // Test sends go only to the admin who clicked the button — no in-app row.
    recipientList = [{ user_id: null, email: event.acted_by }]
  } else {
    const resolvedEventType = normalizeEventType(event.event_type)
    recipientList = await resolveRecipients(supabaseAdmin, resolvedEventType)
    if (recipientList.length === 0) {
      await supabaseAdmin.from('audit_log').insert({
        action: 'notification_skipped_no_recipients',
        resource_type: 'notification',
        metadata: {
          event_type: resolvedEventType,
          app_slug: (event as any).app_slug ?? null,
          acted_by: (event as any).acted_by ?? null,
        },
      })
      return new Response(null, { status: 204, headers: corsHeaders(origin) })
    }
  }

  const recipients = recipientList.map((r) => r.email)

  // 4b. For per-app event_types ('<slug>:<key>'), look up the app's display
  // name and the event label so subject/title read like "Calculator:
  // Calculation deleted" rather than the raw slug/key.
  let appEventMeta = null
  if (event.event_type !== 'test') {
    const resolvedEventType = normalizeEventType(event.event_type)
    appEventMeta = await fetchAppEventMeta(supabaseAdmin, resolvedEventType)
  }

  // 5. Build email body
  const { subject, htmlBody } = buildEmail({ event, clientName, portalUrl, whenISO, appEventMeta })

  // 6. Send via HVE SMTP with retry on transient errors
  try {
    if (!HVE_PASSWORD) {
      throw new Error('NOTIFICATION_HVE_PASSWORD env var is not set on this Supabase project — run `supabase secrets set NOTIFICATION_HVE_PASSWORD=... --project-ref <ref>`')
    }

    // Friendly From: display name derived from the portal's clientName.
    // Each portal renders as e.g. "ElasticIT Portal Notifications", "Mainspring
    // Recovery Portal Notifications" without per-portal HVE config.
    const fromDisplayName = clientName
      ? `${clientName} Portal Notifications`
      : 'ElasticIT Portal Notifications'

    let lastErr: unknown = null
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        await sendSmtp(
          {
            host: HVE_HOST,
            port: HVE_PORT,
            fromAddress: HVE_FROM,
            useTls: HVE_USE_TLS,
            auth: { type: 'login', username: HVE_USERNAME, password: HVE_PASSWORD },
          },
          { recipients, subject, htmlBody, fromDisplayName },
        )
        lastErr = null
        break
      } catch (err) {
        lastErr = err
        if (!isTransientSmtpError(err) || attempt === MAX_RETRIES) break
        await new Promise((r) => setTimeout(r, BACKOFF_MS[attempt]))
      }
    }
    if (lastErr) throw lastErr
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err)
    await supabaseAdmin.from('audit_log').insert({
      action: 'notification_failed',
      resource_type: 'notification',
      metadata: {
        event_type: event.event_type,
        app_slug: event.event_type === 'test' ? null : (event as any).app_slug,
        acted_by: (event as any).acted_by ?? null,
        error: errMsg,
      },
    })
    return jsonResponse({ error: errMsg }, 500, origin)
  }

  // 7. Write in-app notification rows (skip for test events). One row per
  // user_id we resolved — same opt-in catalog drives both email + bell.
  if (event.event_type !== 'test') {
    const resolvedEventType = normalizeEventType(event.event_type)
    const inApp = buildInAppNotification({ event, clientName, portalUrl, appEventMeta })
    const rows = recipientList
      .filter((r) => r.user_id)
      .map((r) => ({
        user_id: r.user_id,
        event_type: resolvedEventType,
        title: inApp.title,
        body: inApp.body,
        link: inApp.link,
        app_slug: inApp.app_slug,
      }))
    if (rows.length > 0) {
      const { error: insertErr } = await supabaseAdmin.from('notifications').insert(rows)
      if (insertErr) {
        console.error('[send-notification] in-app insert failed:', insertErr)
        await supabaseAdmin.from('audit_log').insert({
          action: 'notification_inapp_insert_failed',
          resource_type: 'notification',
          metadata: {
            event_type: resolvedEventType,
            app_slug: (event as any).app_slug ?? null,
            acted_by: (event as any).acted_by ?? null,
            error: insertErr.message,
          },
        })
      }
    }
  }

  // 8. Audit (skip for test sends)
  if (event.event_type !== 'test') {
    await supabaseAdmin.from('audit_log').insert({
      action: 'notification_sent',
      resource_type: 'notification',
      metadata: {
        event_type: normalizeEventType(event.event_type),
        app_slug: (event as any).app_slug ?? null,
        acted_by: (event as any).acted_by ?? null,
        recipient_count: recipients.length,
      },
    })
  }

  return jsonResponse({ ok: true, recipient_count: recipients.length }, 200, origin)
})
