// Event payload shapes. event_type takes three forms at runtime:
//   - 'test'                                    — delivery test, no real event
//   - 'app_published' | 'app_updated' | 'app_deleted'  — system app-lifecycle
//   - '<slug>:<key>'                            — per-app, declared by the app's manifest.notifications[]
//
// The TypeScript union is intentionally loose: per-app event_types vary per
// installed app, so we let the string be free and dispatch on shape inside
// buildEmail / buildInAppNotification.

export interface RealEvent {
  event_type: string
  app_slug?: string
  app_name?: string
  app_version?: string
  previous_version?: string
  acted_by?: string
}

export interface TestEvent {
  event_type: 'test'
  acted_by: string
}

export type NotificationEvent = RealEvent | TestEvent

/** Catalog-derived metadata for per-app events. The edge function looks
 *  this up in public.app_notifications (label) + public.apps (display name)
 *  by parsing the '<slug>:<key>' event_type. Falls back to the raw slug/key
 *  if the catalog row is missing. */
export interface AppEventMeta {
  appDisplayName: string
  eventLabel: string
  appSlug: string
}

export interface BuildEmailInput {
  event: NotificationEvent
  clientName: string
  portalUrl: string
  whenISO: string
  appEventMeta?: AppEventMeta | null
}

export interface BuiltEmail {
  subject: string
  htmlBody: string
}

const SYSTEM_LIFECYCLE_EVENTS = new Set(['app_published', 'app_updated', 'app_deleted'])

// Friendly labels for system + access events. Mirrors the labels rendered
// on NotificationsPage.tsx (SYSTEM_EVENTS / ACCESS_EVENTS). Keep these two
// lists in sync — both are about the same prefixed event_type catalog.
const SYSTEM_EVENT_LABELS: Record<string, string> = {
  'system:app_published': 'App published',
  'system:app_updated': 'App updated',
  'system:app_deleted': 'App removed',
}

const ACCESS_EVENT_LABELS: Record<string, string> = {
  'access:permissions_changed': 'Permissions changed',
  'access:user_added': 'New user added',
}

function isSystemLifecycleEvent(eventType: string): boolean {
  return SYSTEM_LIFECYCLE_EVENTS.has(eventType)
}

function isPerAppEvent(eventType: string): boolean {
  if (!eventType.includes(':')) return false
  const prefix = eventType.split(':')[0]
  return prefix !== 'system' && prefix !== 'access'
}

/** Look up a friendly category + action label for system:* / access:*
 *  events. Falls back to "Event" + raw key if the event_type isn't in
 *  the hardcoded registry. */
function describeGlobalEvent(eventType: string): { category: string; label: string } {
  if (eventType.startsWith('system:')) {
    return {
      category: 'System',
      label: SYSTEM_EVENT_LABELS[eventType] ?? eventType.split(':').slice(1).join(':') ?? eventType,
    }
  }
  if (eventType.startsWith('access:')) {
    return {
      category: 'Access',
      label: ACCESS_EVENT_LABELS[eventType] ?? eventType.split(':').slice(1).join(':') ?? eventType,
    }
  }
  return { category: 'Event', label: eventType }
}

export function buildEmail(input: BuildEmailInput): BuiltEmail {
  const { event, clientName, portalUrl, whenISO, appEventMeta } = input
  const portalLabel = clientName || 'ElasticIT Portal'

  if (event.event_type === 'test') {
    const tEvent = event as TestEvent
    return {
      subject: `[${portalLabel}] Notification test — configuration verified`,
      htmlBody: `<div style="font-family:-apple-system,sans-serif;max-width:600px;padding:24px;">
  <h2 style="color:#111;">Notification test</h2>
  <p>This is a test email from your ElasticIT portal's notification configuration.</p>
  <p>If you received this, Microsoft Graph credentials, sender mailbox, and Vault Secret access are all working.</p>
  <table style="border-collapse:collapse;margin-top:16px;">
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Triggered by:</td><td>${escapeHtml(tEvent.acted_by)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Portal:</td><td>${escapeHtml(clientName)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">When:</td><td>${escapeHtml(whenISO)}</td></tr>
  </table>
  <hr style="margin:32px 0;border:none;border-top:1px solid #ddd;">
  <p style="color:#999;font-size:12px;">This is a test email; no real event occurred. Subscribers were not notified.</p>
</div>`,
    }
  }

  const realEvent = event as RealEvent

  // Per-app events: '<slug>:<key>'. Format as "<App>: <Event label>".
  if (isPerAppEvent(realEvent.event_type)) {
    const meta = appEventMeta
    const appName = meta?.appDisplayName ?? realEvent.app_name ?? realEvent.app_slug ?? 'App'
    const eventLabel = meta?.eventLabel ?? realEvent.event_type.split(':').slice(1).join(':')
    const subject = `[${portalLabel}] ${appName}: ${eventLabel}`
    const portalLink = portalUrl
      ? `<p style="margin-top:24px;"><a href="${escapeHtml(portalUrl)}" style="color:#06f;">Open Portal →</a></p>`
      : ''
    const htmlBody = `<div style="font-family:-apple-system,sans-serif;max-width:600px;padding:24px;">
  <h2 style="color:#111;">${escapeHtml(appName)}: ${escapeHtml(eventLabel)}</h2>
  <table style="border-collapse:collapse;margin-top:16px;">
    <tr><td style="padding:4px 12px 4px 0;color:#666;">App:</td><td>${escapeHtml(appName)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Triggered by:</td><td>${escapeHtml(realEvent.acted_by ?? '(unknown)')}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Portal:</td><td>${escapeHtml(clientName)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">When:</td><td>${escapeHtml(whenISO)}</td></tr>
  </table>
  ${portalLink}
  <hr style="margin:32px 0;border:none;border-top:1px solid #ddd;">
  <p style="color:#999;font-size:12px;">You're receiving this because you're subscribed to <em>${escapeHtml(appName)} — ${escapeHtml(eventLabel)}</em> on the portal. Manage notifications under <em>Notifications</em> in the sidebar.</p>
</div>`
    return { subject, htmlBody }
  }

  // System app-lifecycle events: app_published / app_updated / app_deleted.
  if (isSystemLifecycleEvent(realEvent.event_type)) {
    const verb = realEvent.event_type === 'app_published'
      ? 'Published'
      : realEvent.event_type === 'app_updated'
        ? 'Updated'
        : 'Deleted'

    const subjectVersion = realEvent.event_type === 'app_deleted'
      ? ''
      : ` v${realEvent.app_version ?? '?'}`
    const subjectPrev = realEvent.event_type === 'app_updated' && realEvent.previous_version
      ? ` (was ${realEvent.previous_version})`
      : ''

    const subject = `[${portalLabel}] App ${verb.toLowerCase()}: ${realEvent.app_name ?? realEvent.app_slug ?? ''}${subjectVersion}${subjectPrev}`

    const versionRow = realEvent.event_type === 'app_deleted'
      ? ''
      : `<tr><td style="padding:4px 12px 4px 0;color:#666;">Version:</td><td>${escapeHtml(realEvent.app_version ?? '')}</td></tr>`
    const previousRow = realEvent.event_type === 'app_updated' && realEvent.previous_version
      ? `<tr><td style="padding:4px 12px 4px 0;color:#666;">Previous:</td><td>${escapeHtml(realEvent.previous_version)}</td></tr>`
      : ''
    const portalLink = portalUrl
      ? `<p style="margin-top:24px;"><a href="${escapeHtml(portalUrl)}/admin/apps" style="color:#06f;">Open App Management →</a></p>`
      : ''

    const htmlBody = `<div style="font-family:-apple-system,sans-serif;max-width:600px;padding:24px;">
  <h2 style="color:#111;">App ${verb}</h2>
  <table style="border-collapse:collapse;margin-top:16px;">
    <tr><td style="padding:4px 12px 4px 0;color:#666;">App:</td><td>${escapeHtml(realEvent.app_name ?? '')} (slug: ${escapeHtml(realEvent.app_slug ?? '')})</td></tr>
    ${versionRow}
    ${previousRow}
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Triggered by:</td><td>${escapeHtml(realEvent.acted_by ?? '(unknown)')}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Portal:</td><td>${escapeHtml(clientName)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">When:</td><td>${escapeHtml(whenISO)}</td></tr>
  </table>
  ${portalLink}
  <hr style="margin:32px 0;border:none;border-top:1px solid #ddd;">
  <p style="color:#999;font-size:12px;">You're receiving this because you're subscribed to app notifications. Manage subscriptions in <em>Notifications</em> on the portal.</p>
</div>`
    return { subject, htmlBody }
  }

  // Fallback for any other event_type (system:* / access:* etc.). Render
  // consistently as "[Portal] {Category}: {Friendly label}" with the actor
  // surfaced in the body — every email reads as app + action + actor.
  const { category, label } = describeGlobalEvent(realEvent.event_type)
  return {
    subject: `[${portalLabel}] ${category}: ${label}`,
    htmlBody: `<div style="font-family:-apple-system,sans-serif;max-width:600px;padding:24px;">
  <h2 style="color:#111;">${escapeHtml(category)}: ${escapeHtml(label)}</h2>
  <table style="border-collapse:collapse;margin-top:16px;">
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Triggered by:</td><td>${escapeHtml(realEvent.acted_by ?? '(unknown)')}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">Portal:</td><td>${escapeHtml(clientName)}</td></tr>
    <tr><td style="padding:4px 12px 4px 0;color:#666;">When:</td><td>${escapeHtml(whenISO)}</td></tr>
  </table>
</div>`,
  }
}

export interface InAppNotification {
  title: string
  body: string | null
  link: string | null
  app_slug: string | null
}

export interface BuildInAppInput {
  event: NotificationEvent
  clientName: string
  portalUrl: string
  appEventMeta?: AppEventMeta | null
}

/** Build the bell-notification copy. Body stays short (one line) because
 *  it shows in the bell dropdown. Per-app events render as
 *  "{App display name}: {event label}" with the actor in the body. */
export function buildInAppNotification(input: BuildInAppInput): InAppNotification {
  const { event, appEventMeta } = input
  if (event.event_type === 'test') {
    return { title: 'Notification test', body: null, link: null, app_slug: null }
  }
  const realEvent = event as RealEvent

  if (isPerAppEvent(realEvent.event_type)) {
    const slug = appEventMeta?.appSlug ?? realEvent.event_type.split(':')[0] ?? null
    const appName = appEventMeta?.appDisplayName ?? realEvent.app_name ?? slug ?? 'App'
    const eventLabel = appEventMeta?.eventLabel ?? realEvent.event_type.split(':').slice(1).join(':')
    return {
      title: `${appName}: ${eventLabel}`,
      body: realEvent.acted_by ? `By ${realEvent.acted_by}` : null,
      link: slug ? `/apps/${slug}` : null,
      app_slug: slug,
    }
  }

  if (isSystemLifecycleEvent(realEvent.event_type)) {
    const verb = realEvent.event_type === 'app_published'
      ? 'Published'
      : realEvent.event_type === 'app_updated'
        ? 'Updated'
        : 'Deleted'
    const versionPart = realEvent.event_type === 'app_deleted'
      ? ''
      : ` v${realEvent.app_version ?? '?'}`
    const previousPart = realEvent.event_type === 'app_updated' && realEvent.previous_version
      ? ` (was ${realEvent.previous_version})`
      : ''
    return {
      title: `App ${verb.toLowerCase()}: ${realEvent.app_name ?? realEvent.app_slug ?? ''}${versionPart}${previousPart}`,
      body: realEvent.acted_by ? `By ${realEvent.acted_by}` : null,
      link: '/admin/apps',
      app_slug: realEvent.app_slug ?? null,
    }
  }

  // Fallback (system:* / access:* / unknown shapes). Render as
  // "{Category}: {Friendly label}" with the actor in the body so every
  // bell entry reads consistently — app + action + actor.
  const { category, label } = describeGlobalEvent(realEvent.event_type)
  return {
    title: `${category}: ${label}`,
    body: realEvent.acted_by ? `By ${realEvent.acted_by}` : null,
    link: null,
    app_slug: null,
  }
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}
