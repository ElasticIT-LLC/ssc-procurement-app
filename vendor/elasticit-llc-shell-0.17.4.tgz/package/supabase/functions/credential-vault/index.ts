// Supabase Edge Function — Deno runtime
// Handles encrypt/decrypt of API credentials using AES-256-GCM
// Encryption key stored as Edge Function secret: CREDENTIAL_ENCRYPTION_KEY

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const ENCRYPTION_KEY = Deno.env.get('CREDENTIAL_ENCRYPTION_KEY')!
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

async function getKey(): Promise<CryptoKey> {
  const keyBytes = new Uint8Array(
    ENCRYPTION_KEY.match(/.{2}/g)!.map((b: string) => parseInt(b, 16))
  )
  return crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['encrypt', 'decrypt'])
}

async function encrypt(plaintext: string): Promise<string> {
  const key = await getKey()
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const encoded = new TextEncoder().encode(plaintext)
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded)

  // Combine iv + ciphertext (tag is appended by WebCrypto)
  const combined = new Uint8Array(iv.length + ciphertext.byteLength)
  combined.set(iv)
  combined.set(new Uint8Array(ciphertext), iv.length)

  return btoa(String.fromCharCode(...combined))
}

async function decrypt(encoded: string): Promise<string> {
  const key = await getKey()
  const combined = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0))

  const iv = combined.slice(0, 12)
  const ciphertext = combined.slice(12)

  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext)
  return new TextDecoder().decode(plaintext)
}

// Normalize credential field values before storing or testing.
//
// Three classes of input bugs that will silently break vendor calls if not
// caught here:
//   1. Trailing/leading whitespace from copy-paste (especially client_secret).
//   2. Scope case mismatch — many vendors require exact lowercase tokens
//      ('all', 'read'); paste-from-docs often arrives as 'All' / 'Read'.
//   3. Trailing slashes on token / base URLs — fetch() handles them, but a
//      few vendors (and our own URL building elsewhere) trip on them.
//
// Scope lowercasing is selective: we only lowercase tokens that match a
// known list of single-word scopes. Microsoft Graph-style dotted scopes
// (User.Read, Files.ReadWrite) are case-sensitive AND CamelCase, so we
// must not touch them.

const KNOWN_LOWERCASE_SCOPES = new Set([
  'all', 'read', 'write', 'admin',
  'openid', 'profile', 'email', 'offline_access',
])

const URL_FIELDS = new Set([
  'base_url', 'token_url', 'auth_url', 'redirect_uri', 'server',
])

function normalizeScope(raw: string): string {
  return raw
    .trim()
    .split(/\s+/)
    .map((tok) => {
      const lower = tok.toLowerCase()
      return KNOWN_LOWERCASE_SCOPES.has(lower) ? lower : tok
    })
    .filter(Boolean)
    .join(' ')
}

function normalizeUrl(raw: string): string {
  const trimmed = raw.trim()
  if (!trimmed) return trimmed
  // Strip trailing slashes — fetch() doesn't care, but vendor exact-match does.
  return trimmed.replace(/\/+$/, '')
}

function normalizeCredentialData(
  _credentialType: string,
  data: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...data }
  for (const [key, value] of Object.entries(out)) {
    if (typeof value !== 'string') continue
    if (key === 'scope') {
      out[key] = normalizeScope(value)
    } else if (URL_FIELDS.has(key)) {
      out[key] = normalizeUrl(value)
    } else {
      out[key] = value.trim()
    }
  }
  return out
}

// SSRF protection: block requests to internal/private networks
function validateExternalUrl(urlStr: string): { ok: boolean; error?: string } {
  try {
    const url = new URL(urlStr)
    const hostname = url.hostname.toLowerCase()

    // Block non-HTTP(S) protocols
    if (!['http:', 'https:'].includes(url.protocol)) {
      return { ok: false, error: `Protocol not allowed: ${url.protocol}` }
    }

    // Block localhost and loopback
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1' || hostname === '0.0.0.0') {
      return { ok: false, error: 'Localhost URLs are not allowed' }
    }

    // Block RFC 1918 private ranges
    const parts = hostname.split('.')
    if (parts.length === 4 && parts.every(p => /^\d+$/.test(p))) {
      const [a, b] = parts.map(Number)
      if (a === 10) return { ok: false, error: 'Private network addresses are not allowed' }
      if (a === 172 && b! >= 16 && b! <= 31) return { ok: false, error: 'Private network addresses are not allowed' }
      if (a === 192 && b === 168) return { ok: false, error: 'Private network addresses are not allowed' }
      if (a === 169 && b === 254) return { ok: false, error: 'Link-local addresses are not allowed' }
    }

    // Block internal Supabase domains
    if (hostname.endsWith('.supabase.internal') || hostname.endsWith('.supabase.co') && hostname.startsWith('db.')) {
      return { ok: false, error: 'Internal Supabase URLs are not allowed' }
    }

    return { ok: true }
  } catch {
    return { ok: false, error: `Invalid URL: ${urlStr}` }
  }
}

// Test connection logic per credential type
async function testConnection(credentialType: string, rawData: Record<string, unknown>): Promise<{ ok: boolean; error?: string }> {
  // Normalize before the switch so each branch reads cleaned values
  // (trimmed, scope-lowercased, no trailing slash on URLs).
  const data = normalizeCredentialData(credentialType, rawData)
  try {
    switch (credentialType) {
      case 'database': {
        // TCP connection check to server:port
        const port = data.port ? Number(data.port) : 5432
        const server = data.server as string
        if (!server) return { ok: false, error: 'Server is required' }
        const dbUrlCheck = validateExternalUrl(`https://${server}`)
        if (!dbUrlCheck.ok) return dbUrlCheck
        try {
          const conn = await Deno.connect({ hostname: server, port })
          conn.close()
          return { ok: true }
        } catch (e) {
          return { ok: false, error: `Cannot reach ${server}:${port} — ${e instanceof Error ? e.message : String(e)}` }
        }
      }

      case 'api_key': {
        const baseUrl = data.base_url as string
        const apiKey = data.key as string
        const apiValue = data.value as string
        const addTo = (data.add_to as string) ?? 'header'
        if (!apiKey || !apiValue) {
          return { ok: false, error: 'Key and Value are required' }
        }
        if (!baseUrl) {
          return { ok: true }
        }
        const urlCheck = validateExternalUrl(baseUrl)
        if (!urlCheck.ok) return urlCheck
        const fetchOptions: RequestInit & { signal: AbortSignal } = {
          method: 'GET',
          headers: addTo === 'header' ? { [apiKey]: apiValue } : {},
          signal: AbortSignal.timeout(10000),
        }
        const testUrl = addTo === 'query' ? `${baseUrl}${baseUrl.includes('?') ? '&' : '?'}${encodeURIComponent(apiKey)}=${encodeURIComponent(apiValue)}` : baseUrl
        const res = await fetch(testUrl, fetchOptions)
        // Any response means the endpoint is reachable
        return { ok: true }
      }

      case 'oauth2': {
        const tokenUrl = data.token_url as string
        if (!tokenUrl) return { ok: false, error: 'Token URL is required' }
        const oauth2UrlCheck = validateExternalUrl(tokenUrl)
        if (!oauth2UrlCheck.ok) return oauth2UrlCheck
        const body = new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: data.client_id as string,
          client_secret: data.client_secret as string,
          ...(data.scope ? { scope: data.scope as string } : {}),
        })
        const res = await fetch(tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body,
          signal: AbortSignal.timeout(10000),
        })
        if (!res.ok) {
          const text = await res.text()
          return { ok: false, error: `OAuth2 token request failed: ${res.status} ${text}` }
        }
        return { ok: true }
      }

      case 'bearer': {
        const baseUrl = data.base_url as string
        if (!baseUrl) {
          if (!data.token) return { ok: false, error: 'Token is required' }
          return { ok: true }
        }
        const bearerUrlCheck = validateExternalUrl(baseUrl)
        if (!bearerUrlCheck.ok) return bearerUrlCheck
        const res = await fetch(baseUrl, {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${data.token}` },
          signal: AbortSignal.timeout(10000),
        })
        // Any response means the endpoint is reachable
        return { ok: true }
      }

      case 'oauth2_auth_code': {
        if (!data.access_token) {
          return { ok: false, error: 'Not connected. Click Connect to authorize with the provider.' }
        }
        const expiresAt = data.expires_at as string | undefined
        if (expiresAt && new Date(expiresAt) < new Date()) {
          return { ok: false, error: 'Access token has expired. Click Refresh Token to renew.' }
        }
        return { ok: true }
      }

      default:
        return { ok: false, error: `Unknown credential type: ${credentialType}` }
    }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}

function getCorsOrigin(req: Request): string {
  const origin = req.headers.get('Origin') ?? '*'
  // In production, restrict to known portal domains
  // For now, echo the requesting origin (Supabase edge functions are already auth-gated)
  return origin
}

const baseCorsHeaders = {
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
}

function corsHeaders(req: Request) {
  return { ...baseCorsHeaders, 'Access-Control-Allow-Origin': getCorsOrigin(req) }
}

let _currentReq: Request | null = null

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(_currentReq!), 'Content-Type': 'application/json' },
  })
}

function html(body: string, status = 200) {
  return new Response(body, {
    status,
    headers: { ...corsHeaders(_currentReq!), 'Content-Type': 'text/html; charset=utf-8' },
  })
}

Deno.serve(async (req) => {
  _currentReq = req

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders(req) })
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const url = new URL(req.url)
  const method = req.method
  const action = url.searchParams.get('action')

  // OAuth callback is unauthenticated (provider redirects browser here)
  // Security is via the cryptographic state parameter
  if (method === 'GET' && action === 'oauth-callback') {
    try {
      const code = url.searchParams.get('code')
      const state = url.searchParams.get('state')
      if (!code || !state) {
        return html('<html><body><p>Missing code or state parameter.</p></body></html>', 400)
      }

      // Look up credential by OAuth state
      const { data: cred, error: lookupErr } = await supabase
        .from('credentials')
        .select('*')
        .eq('credential_type', 'oauth2_auth_code')
        .filter('metadata->>oauth_state', 'eq', state)
        .single()

      if (lookupErr || !cred) {
        return html('<html><body><p>Invalid or expired OAuth state.</p></body></html>', 400)
      }

      // Validate state hasn't expired
      const expiresAt = cred.metadata?.oauth_state_expires_at
      if (!expiresAt || new Date(expiresAt as string) < new Date()) {
        return html('<html><body><p>OAuth state has expired. Please try connecting again.</p></body></html>', 400)
      }

      // Decrypt config to get token_url, client_id, client_secret, redirect_uri
      const config = JSON.parse(await decrypt(cred.encrypted_data))

      // Exchange authorization code for tokens
      const tokenBody = new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: config.redirect_uri,
        client_id: config.client_id,
        client_secret: config.client_secret,
      })

      const tokenRes = await fetch(config.token_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Basic ${btoa(`${config.client_id}:${config.client_secret}`)}`,
        },
        body: tokenBody,
        signal: AbortSignal.timeout(15000),
      })

      if (!tokenRes.ok) {
        const errText = await tokenRes.text()
        return html(`<html><body><p>Token exchange failed: ${tokenRes.status}</p><pre>${errText}</pre></body></html>`, 400)
      }

      const tokenData = await tokenRes.json()
      const accessToken = tokenData.access_token
      const refreshToken = tokenData.refresh_token
      const expiresIn = tokenData.expires_in
      const tokenType = tokenData.token_type ?? 'bearer'

      const expiresAtDate = expiresIn
        ? new Date(Date.now() + expiresIn * 1000).toISOString()
        : null

      // Capture extra query params (e.g., QBO's realmId)
      const extraParams: Record<string, string> = {}
      for (const [key, val] of url.searchParams.entries()) {
        if (!['code', 'state', 'action'].includes(key)) {
          extraParams[key] = val
        }
      }

      // Store tokens + config together encrypted
      const updatedData = {
        ...config,
        access_token: accessToken,
        refresh_token: refreshToken,
        token_type: tokenType,
        expires_at: expiresAtDate,
        ...extraParams,
      }

      const encryptedData = await encrypt(JSON.stringify(updatedData))

      // Update credential row
      const newMetadata = { ...cred.metadata }
      delete newMetadata.oauth_state
      delete newMetadata.oauth_state_expires_at
      newMetadata.oauth_connected = true
      if (extraParams.realmId) newMetadata.oauth_realm_id = extraParams.realmId

      await supabase
        .from('credentials')
        .update({
          encrypted_data: encryptedData,
          token_expiry: expiresAtDate,
          verified: true,
          verified_at: new Date().toISOString(),
          metadata: newMetadata,
          updated_at: new Date().toISOString(),
        })
        .eq('id', cred.id)

      const successPayload = JSON.stringify({ type: 'oauth-callback-success', credentialId: cred.id })
      return html(`<!DOCTYPE html><html><body>
        <p>Authorization successful. This window will close automatically.</p>
        <script>
          if (window.opener) {
            window.opener.postMessage(${successPayload}, window.location.origin);
          }
          setTimeout(function() { window.close(); }, 1500);
        </script>
      </body></html>`)
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err)
      const errorPayload = JSON.stringify({ type: 'oauth-callback-error', error: errorMsg })
      return html(`<!DOCTYPE html><html><body>
        <p>Authorization failed. This window will close automatically.</p>
        <script>
          if (window.opener) {
            window.opener.postMessage(${errorPayload}, window.location.origin);
          }
          setTimeout(function() { window.close(); }, 3000);
        </script>
      </body></html>`, 400)
    }
  }

  // All other endpoints require authentication
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return json({ error: 'Unauthorized' }, 401)
  }

  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return json({ error: 'Unauthorized' }, 401)
  }

  // Get user profile
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  const isAdmin = profile?.role === 'admin'

  // ---- OAuth2 Auth Code: Initiate ----
  if (method === 'POST' && action === 'oauth-initiate') {
    if (!isAdmin) return json({ error: 'Forbidden' }, 403)

    const id = url.searchParams.get('id')
    if (!id) return json({ error: 'Missing id' }, 400)

    const { data: cred, error } = await supabase.from('credentials').select('*').eq('id', id).single()
    if (error || !cred) return json({ error: 'Not found' }, 404)
    if (cred.credential_type !== 'oauth2_auth_code') return json({ error: 'Not an OAuth2 auth code credential' }, 400)

    const config = JSON.parse(await decrypt(cred.encrypted_data))
    const state = crypto.randomUUID()
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString()

    // Store state in metadata
    await supabase
      .from('credentials')
      .update({
        metadata: { ...cred.metadata, oauth_state: state, oauth_state_expires_at: expiresAt },
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)

    // Build authorization URL
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: config.client_id,
      redirect_uri: config.redirect_uri,
      state,
    })
    if (config.scope) params.set('scope', config.scope)

    return json({ auth_url: `${config.auth_url}?${params.toString()}` })
  }

  // ---- OAuth2 Auth Code: Refresh ----
  if (method === 'POST' && action === 'oauth-refresh') {
    if (!isAdmin) return json({ error: 'Forbidden' }, 403)

    const id = url.searchParams.get('id')
    if (!id) return json({ error: 'Missing id' }, 400)

    const { data: cred, error } = await supabase.from('credentials').select('*').eq('id', id).single()
    if (error || !cred) return json({ error: 'Not found' }, 404)

    const config = JSON.parse(await decrypt(cred.encrypted_data))
    if (!config.refresh_token) return json({ error: 'No refresh token available' }, 400)

    const body = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: config.refresh_token,
      client_id: config.client_id,
      client_secret: config.client_secret,
    })

    const res = await fetch(config.token_url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${btoa(`${config.client_id}:${config.client_secret}`)}`,
      },
      body,
      signal: AbortSignal.timeout(15000),
    })

    if (!res.ok) {
      const errText = await res.text()
      return json({ ok: false, error: `Token refresh failed: ${res.status} ${errText}` }, 422)
    }

    const tokenData = await res.json()
    const expiresAt = tokenData.expires_in
      ? new Date(Date.now() + tokenData.expires_in * 1000).toISOString()
      : null

    const updatedData = {
      ...config,
      access_token: tokenData.access_token,
      refresh_token: tokenData.refresh_token ?? config.refresh_token,
      expires_at: expiresAt,
    }

    const encryptedData = await encrypt(JSON.stringify(updatedData))
    await supabase
      .from('credentials')
      .update({
        encrypted_data: encryptedData,
        token_expiry: expiresAt,
        verified: true,
        verified_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)

    return json({ ok: true, expires_at: expiresAt })
  }

  // ---- OAuth2 Auth Code: Disconnect ----
  if (method === 'POST' && action === 'oauth-disconnect') {
    if (!isAdmin) return json({ error: 'Forbidden' }, 403)

    const id = url.searchParams.get('id')
    if (!id) return json({ error: 'Missing id' }, 400)

    const { data: cred, error } = await supabase.from('credentials').select('*').eq('id', id).single()
    if (error || !cred) return json({ error: 'Not found' }, 404)

    // Decrypt, remove tokens, re-encrypt config only
    const config = JSON.parse(await decrypt(cred.encrypted_data))
    delete config.access_token
    delete config.refresh_token
    delete config.expires_at
    delete config.token_type
    delete config.realmId

    const encryptedData = await encrypt(JSON.stringify(config))
    const newMetadata = { ...cred.metadata, oauth_connected: false }
    delete newMetadata.oauth_realm_id

    await supabase
      .from('credentials')
      .update({
        encrypted_data: encryptedData,
        token_expiry: null,
        verified: false,
        verified_at: null,
        metadata: newMetadata,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)

    return json({ ok: true })
  }

  // POST ?action=test — test connection (admin only)
  if (method === 'POST' && action === 'test') {
    if (!isAdmin) {
      return json({ error: 'Forbidden' }, 403)
    }

    const id = url.searchParams.get('id')

    if (id) {
      // Test an existing saved credential
      const { data: cred, error } = await supabase
        .from('credentials')
        .select('*')
        .eq('id', id)
        .single()

      if (error || !cred) return json({ error: 'Not found' }, 404)

      const decrypted = JSON.parse(await decrypt(cred.encrypted_data))
      const result = await testConnection(cred.credential_type, decrypted)

      // Update verification status
      await supabase
        .from('credentials')
        .update({
          verified: result.ok,
          verified_at: result.ok ? new Date().toISOString() : cred.verified_at,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)

      if (result.ok) {
        return json({ ok: true, message: 'Connection successful' })
      }
      return json({ ok: false, error: result.error }, 422)
    } else {
      // Test before saving — credential_type and data in body
      const body = await req.json()
      const { credential_type, data: credData } = body
      const result = await testConnection(credential_type, credData)

      if (result.ok) {
        return json({ ok: true, message: 'Connection successful' })
      }
      return json({ ok: false, error: result.error }, 422)
    }
  }

  // POST /credential-vault — encrypt and store (admin only)
  if (method === 'POST') {
    if (!isAdmin) {
      return json({ error: 'Forbidden' }, 403)
    }

    const body = await req.json()
    const { provider, label, credential_type, data: credentialData, metadata, app_id } = body

    // Normalize on save so what we encrypt matches what testConnection sees.
    const normalizedData = normalizeCredentialData(credential_type, credentialData ?? {})
    const encryptedData = await encrypt(JSON.stringify(normalizedData))

    const { data, error } = await supabase
      .from('credentials')
      .insert({
        provider,
        label,
        credential_type,
        encrypted_data: encryptedData,
        metadata: metadata ?? {},
        created_by: user.id,
        app_id: app_id ?? null,
      })
      .select('id, app_id, provider, label, credential_type, verified, verified_at, metadata, created_at')
      .single()

    if (error) return json({ error: error.message }, 500)
    return json(data, 201)
  }

  // GET /credential-vault?app_id=<uuid> — credentials for an app (admin or app user)
  // GET /credential-vault?app_id=<uuid>&decrypt=true — with decrypted data
  // GET /credential-vault?id=<uuid> — single credential (admin only)
  if (method === 'GET') {
    const id = url.searchParams.get('id')
    const appId = url.searchParams.get('app_id')
    const shouldDecrypt = url.searchParams.get('decrypt') === 'true'

    if (appId) {
      // Non-admin access: check user has the app's required_permission
      if (!isAdmin) {
        const { data: app } = await supabase
          .from('apps')
          .select('required_permission')
          .eq('id', appId)
          .single()

        if (!app) return json({ error: 'App not found' }, 404)

        const userPermissions: string[] = profile?.permissions ?? []
        const requiredPerm = app.required_permission
        if (requiredPerm) {
          const hasPerm = userPermissions.some((p: string) => {
            if (p === '*:*:*') return true
            const [pr, ps, pa] = p.split(':')
            const [rr, rs, ra] = requiredPerm.split(':')
            return (pr === '*' || pr === rr) && (ps === '*' || ps === rs) && (pa === '*' || pa === ra)
          })
          if (!hasPerm) {
            return json({ error: 'Forbidden' }, 403)
          }
        }
      }

      const { data: creds, error } = await supabase
        .from('credentials')
        .select('id, app_id, provider, label, credential_type, verified, verified_at, metadata, created_at')
        .eq('app_id', appId)
        .order('created_at', { ascending: false })

      if (error) return json({ error: error.message }, 500)

      if (shouldDecrypt) {
        const results = await Promise.all(
          (creds ?? []).map(async (cred: Record<string, unknown>) => {
            const { data: full } = await supabase.from('credentials').select('encrypted_data').eq('id', cred.id).single()
            if (!full) return cred
            const decrypted = JSON.parse(await decrypt(full.encrypted_data))
            return { ...cred, data: decrypted }
          })
        )
        return json(results)
      }

      return json(creds ?? [])
    }

    if (id) {
      if (!isAdmin) {
        return json({ error: 'Forbidden' }, 403)
      }

      const { data: cred, error } = await supabase
        .from('credentials')
        .select('*')
        .eq('id', id)
        .single()

      if (error || !cred) return json({ error: 'Not found' }, 404)

      const decrypted = JSON.parse(await decrypt(cred.encrypted_data))
      return json({ ...cred, data: decrypted, encrypted_data: undefined })
    }

    return json({ error: 'Missing id or app_id' }, 400)
  }

  // PUT /credential-vault?id=<uuid> — update credential (admin only)
  if (method === 'PUT') {
    if (!isAdmin) {
      return json({ error: 'Forbidden' }, 403)
    }

    const id = url.searchParams.get('id')
    if (!id) return json({ error: 'Missing id' }, 400)

    const body = await req.json()
    const { provider, label, credential_type, data: credentialData, metadata, app_id } = body

    const updates: Record<string, unknown> = {}
    if (provider !== undefined) updates.provider = provider
    if (label !== undefined) updates.label = label
    if (credential_type !== undefined) updates.credential_type = credential_type
    if (metadata !== undefined) updates.metadata = metadata
    if (app_id !== undefined) updates.app_id = app_id
    if (credentialData !== undefined) {
      // Normalize on save so what we encrypt matches what testConnection sees.
      const normalizedData = normalizeCredentialData(credential_type ?? '', credentialData)
      updates.encrypted_data = await encrypt(JSON.stringify(normalizedData))
      // Reset verification when data changes
      updates.verified = false
      updates.verified_at = null
    }
    updates.updated_at = new Date().toISOString()

    const { data, error } = await supabase
      .from('credentials')
      .update(updates)
      .eq('id', id)
      .select('id, app_id, provider, label, credential_type, verified, verified_at, metadata, created_at, updated_at')
      .single()

    if (error) return json({ error: error.message }, 500)
    return json(data)
  }

  // DELETE /credential-vault?id=<uuid> (admin only)
  if (method === 'DELETE') {
    if (!isAdmin) {
      return json({ error: 'Forbidden' }, 403)
    }

    const id = url.searchParams.get('id')
    if (!id) return json({ error: 'Missing id' }, 400)

    const { error } = await supabase.from('credentials').delete().eq('id', id)
    if (error) return json({ error: error.message }, 500)
    return json({ ok: true })
  }

  return json({ error: 'Method not allowed' }, 405)
})
