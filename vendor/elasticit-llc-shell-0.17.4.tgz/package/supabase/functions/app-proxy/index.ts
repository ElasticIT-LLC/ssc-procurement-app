// Supabase Edge Function — Deno runtime
// Generic proxy for all apps that talk to external HTTP APIs or remote Supabase
// projects. Replaces the older per-app proxy pattern.
// Reads proxy_config from the apps table to determine allowlists and credentials.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const CREDENTIAL_ENCRYPTION_KEY = Deno.env.get('CREDENTIAL_ENCRYPTION_KEY') ?? ''

// ── Credential Vault decryption (AES-256-GCM) ──
// Matches the encryption scheme used by `credential-vault` edge function:
// encrypted_data = base64(iv[12] || ciphertext || auth_tag)
async function getCredentialKey(): Promise<CryptoKey> {
  if (!CREDENTIAL_ENCRYPTION_KEY) {
    throw new Error('CREDENTIAL_ENCRYPTION_KEY env var not set on app-proxy function')
  }
  const keyBytes = new Uint8Array(
    CREDENTIAL_ENCRYPTION_KEY.match(/.{2}/g)!.map((b: string) => parseInt(b, 16)),
  )
  return crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt'])
}

async function decryptCredential(encoded: string): Promise<string> {
  const key = await getCredentialKey()
  const combined = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0))
  const iv = combined.slice(0, 12)
  const ciphertext = combined.slice(12)
  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext)
  return new TextDecoder().decode(plaintext)
}

// ── CORS ──
function getCorsOrigin(req: Request): string {
  return req.headers.get('Origin') ?? '*'
}
function corsHeaders(req: Request) {
  return {
    'Access-Control-Allow-Origin': getCorsOrigin(req),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  }
}
function json(body: unknown, req: Request, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), 'Content-Type': 'application/json' },
  })
}

// ── Types ──
interface ProxyConfig {
  vault_prefix: string
  allowed_tables: string[]
  allowed_rpcs: string[]
  allowed_api_endpoints: string[]
  write_requires_admin?: boolean
  api_requires_admin?: boolean
  tenant_isolation?: {
    enabled: boolean
    setting_key: string
    fallback_key?: string
    column: string
    table_overrides?: Record<string, string>
  }
  api_config?: {
    type: string
    base_url: string
    vault_keys?: Record<string, string>
    url_template: string
    tenant_setting_key?: string
  }
  forward_to_functions?: boolean
}

interface CachedEntry<T> {
  value: T
  expiry: number
}

// ── Caches (persist across warm invocations) ──
const configCache = new Map<string, CachedEntry<ProxyConfig>>()
const clientCache = new Map<string, CachedEntry<ReturnType<typeof createClient>>>()
const clientUrlCache = new Map<string, string>()
const apiTokenCache = new Map<string, CachedEntry<string>>()
const tenantIdCache = new Map<string, CachedEntry<string>>()

const CACHE_TTL = 5 * 60 * 1000 // 5 minutes

function getCached<T>(cache: Map<string, CachedEntry<T>>, key: string): T | null {
  const entry = cache.get(key)
  if (entry && Date.now() < entry.expiry) return entry.value
  cache.delete(key)
  return null
}
function setCache<T>(cache: Map<string, CachedEntry<T>>, key: string, value: T) {
  cache.set(key, { value, expiry: Date.now() + CACHE_TTL })
}

// ── Get proxy config from apps table ──
async function getProxyConfig(localSupabase: ReturnType<typeof createClient>, appSlug: string): Promise<ProxyConfig | null> {
  const cached = getCached(configCache, appSlug)
  if (cached) return cached

  const { data, error } = await localSupabase
    .from('apps')
    .select('proxy_config, db_mode')
    .eq('slug', appSlug)
    .eq('status', 'active')
    .single()

  if (error || !data || data.db_mode !== 'proxy' || !data.proxy_config) return null

  const config = data.proxy_config as ProxyConfig
  setCache(configCache, appSlug, config)
  return config
}

// ── Get remote Supabase client via vault secrets ──
async function getRemoteClient(localSupabase: ReturnType<typeof createClient>, vaultPrefix: string) {
  const cached = getCached(clientCache, vaultPrefix)
  if (cached) return { client: cached, url: clientUrlCache.get(vaultPrefix)! }

  const { data: urlData } = await localSupabase.rpc('get_vault_secret', { secret_name: `${vaultPrefix}_supabase_url` })
  const { data: keyData } = await localSupabase.rpc('get_vault_secret', { secret_name: `${vaultPrefix}_service_role_key` })

  const url = urlData as string | null
  const key = keyData as string | null

  if (!url || !key) {
    throw new Error(`Vault secrets missing: ${vaultPrefix}_supabase_url and ${vaultPrefix}_service_role_key`)
  }

  const client = createClient(url, key)
  setCache(clientCache, vaultPrefix, client)
  clientUrlCache.set(vaultPrefix, url)
  return { client, url }
}

// ── Get tenant ID from client_settings ──
async function getTenantId(localSupabase: ReturnType<typeof createClient>, settingKey: string, fallbackKey?: string): Promise<string> {
  const cacheKey = settingKey + (fallbackKey ?? '')
  const cached = getCached(tenantIdCache, cacheKey)
  if (cached) return cached

  const { data } = await localSupabase.from('client_settings').select('value').eq('key', settingKey).maybeSingle()
  if (data?.value) { setCache(tenantIdCache, cacheKey, data.value); return data.value }

  if (fallbackKey) {
    const { data: fb } = await localSupabase.from('client_settings').select('value').eq('key', fallbackKey).single()
    if (fb?.value) { setCache(tenantIdCache, cacheKey, fb.value); return fb.value }
  }

  throw new Error(`Tenant ID not found in client_settings (key: ${settingKey})`)
}

// ── Get API token ──
// Branches on api_config.type:
//   - 'bearer_token' → static Bearer token from Credential Vault (credentials table, type='bearer')
//   - default (OAuth2 client credentials) → exchange client_id+secret at token_url, client_id+secret stored in PostgreSQL Vault
async function getApiToken(
  localSupabase: ReturnType<typeof createClient>,
  apiConfig: ProxyConfig['api_config'],
  appSlug?: string,
): Promise<string> {
  if (!apiConfig) throw new Error('No api_config')

  // ── Static bearer token (read from Credential Vault, looked up by app_id) ──
  // Accepts both 'bearer' (token field) and 'api_key' (value field) credential
  // types from the Credential Vault UI — either works for Bearer-style auth.
  if (apiConfig.type === 'bearer_token') {
    if (!appSlug) throw new Error('bearer_token flow requires appSlug to look up linked credential')

    const cacheKey = `bearer:${appSlug}`
    const cached = getCached(apiTokenCache, cacheKey)
    if (cached) return cached

    // Look up any Bearer-style credential linked to this app.
    const { data: cred, error: credErr } = await localSupabase
      .from('credentials')
      .select('credential_type, encrypted_data, apps!inner(slug)')
      .in('credential_type', ['bearer', 'api_key'])
      .eq('apps.slug', appSlug)
      .limit(1)
      .maybeSingle()

    if (credErr) throw new Error(`Failed to look up credential for app "${appSlug}": ${credErr.message}`)
    if (!cred) {
      throw new Error(
        `No Bearer Token or API Key credential linked to app "${appSlug}". ` +
        `In Admin > Credential Vault, create a credential and use the "Link to App" selector to link it.`,
      )
    }

    const plaintext = await decryptCredential(cred.encrypted_data as string)
    let parsed: Record<string, unknown>
    try {
      parsed = JSON.parse(plaintext)
    } catch {
      throw new Error(`Decrypted credential for app "${appSlug}" is not valid JSON`)
    }

    // Extract raw token (handle both credential shapes):
    //   bearer:  { token: "ory_pat_xxx", base_url?: "..." }
    //   api_key: { key: "Authorization", value: "ory_pat_xxx" (or "Bearer ory_pat_xxx"), add_to: "header" }
    let token = (parsed.token ?? parsed.value ?? parsed.access_token) as string | undefined
    if (!token) {
      throw new Error(`Decrypted credential for app "${appSlug}" has no token/value field`)
    }
    // If api_key stored the full "Bearer xxx" header value, strip the prefix so
    // the caller can cleanly add its own `Bearer ` prefix.
    if (token.toLowerCase().startsWith('bearer ')) {
      token = token.slice(7).trim()
    }

    setCache(apiTokenCache, cacheKey, token)
    return token
  }

  // ── OAuth2 client credentials (default — from PostgreSQL Vault) ──
  if (!apiConfig.vault_keys) throw new Error('OAuth2 api_config requires vault_keys.client_id, client_secret, token_url')
  const cacheKey = apiConfig.vault_keys.client_id
  const cached = getCached(apiTokenCache, cacheKey)
  if (cached) return cached

  const clientId = (await localSupabase.rpc('get_vault_secret', { secret_name: apiConfig.vault_keys.client_id })).data as string
  const clientSecret = (await localSupabase.rpc('get_vault_secret', { secret_name: apiConfig.vault_keys.client_secret })).data as string
  const tokenUrl = (await localSupabase.rpc('get_vault_secret', { secret_name: apiConfig.vault_keys.token_url })).data as string

  if (!clientId || !clientSecret || !tokenUrl) throw new Error('API vault secrets missing')

  const res = await fetch(tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'client_credentials', client_id: clientId, client_secret: clientSecret }),
    signal: AbortSignal.timeout(10_000),
  })

  if (!res.ok) throw new Error(`Token request failed: ${res.status}`)
  const data = await res.json()
  if (!data.access_token) throw new Error('Token response missing access_token')

  const expiresIn = typeof data.expires_in === 'number' ? data.expires_in : 3600
  apiTokenCache.set(cacheKey, { value: data.access_token, expiry: Date.now() + (expiresIn - 60) * 1000 })
  return data.access_token
}

// ── Apply filters to query ──
function applyFilters(query: any, filters: Array<{ op: string; column: string; value: unknown }>) {
  let q = query
  for (const f of filters) {
    switch (f.op) {
      case 'eq': q = q.eq(f.column, f.value); break
      case 'neq': q = q.neq(f.column, f.value); break
      case 'gt': q = q.gt(f.column, f.value); break
      case 'gte': q = q.gte(f.column, f.value); break
      case 'lt': q = q.lt(f.column, f.value); break
      case 'lte': q = q.lte(f.column, f.value); break
      case 'in': q = q.in(f.column, f.value as unknown[]); break
      case 'like': q = q.like(f.column, f.value as string); break
      case 'ilike': q = q.ilike(f.column, f.value as string); break
      case 'is': q = q.is(f.column, f.value); break
      case 'not': { const v = f.value as { op: string; value: unknown }; q = q.not(f.column, v.op, v.value); break }
      case 'or': q = q.or(f.value as string); break
      default: break
    }
  }
  return q
}

// ── Normalize HAL+JSON API responses ──
function normalizeApiList(data: unknown): unknown[] {
  if (Array.isArray(data)) return data
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>
    for (const key of ['printers', 'users', 'groups', 'tenants', 'value', 'records']) {
      if (Array.isArray(obj[key])) return obj[key] as unknown[]
    }
    if (obj._embedded && typeof obj._embedded === 'object') {
      for (const val of Object.values(obj._embedded as Record<string, unknown>)) {
        if (Array.isArray(val)) return val
      }
    }
    return [data]
  }
  return []
}

// ── Main handler ──
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders(req) })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, req, 405)

  // Auth check
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Unauthorized' }, req, 401)

  const localSupabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: authError } = await localSupabase.auth.getUser(token)
  if (authError || !user) return json({ error: 'Unauthorized' }, req, 401)

  try {
    const body = await req.json()
    const appSlug = body.app as string
    if (!appSlug) return json({ error: 'Missing "app" field in request body' }, req, 400)

    // Load proxy config
    const config = await getProxyConfig(localSupabase, appSlug)
    if (!config) return json({ error: `App "${appSlug}" not found or not configured for proxy access` }, req, 404)

    // Check admin for write operations
    if (config.write_requires_admin) {
      const writeTypes = ['insert', 'update', 'delete', 'upsert', 'rpc']
      if (writeTypes.includes(body.type)) {
        const { data: profile } = await localSupabase.from('user_profiles').select('role').eq('id', user.id).single()
        if (profile?.role !== 'admin') return json({ error: 'Forbidden: write operations require admin role' }, req, 403)
      }
    }

    // Check admin for API calls when the app requires it. Apps that forward
    // to remote edge functions (forward_to_functions: true) authenticate to
    // the remote project with a service-role key, so the remote function
    // cannot check the caller's identity. When api_requires_admin is set,
    // the proxy enforces the admin gate here before forwarding.
    if (config.api_requires_admin && body.type === 'api') {
      const { data: profile } = await localSupabase.from('user_profiles').select('role').eq('id', user.id).single()
      if (profile?.role !== 'admin') return json({ error: 'Forbidden: API calls require admin role' }, req, 403)
    }

    // Get remote Supabase client (lazy — pure external-API proxy mode like
    // Rippling doesn't have a remote Supabase project at all, so we skip the
    // vault lookup unless an actual DB op or function-forwarding API call needs it).
    const needsRemoteClient =
      ['rpc', 'query', 'insert', 'update', 'delete', 'upsert'].includes(body.type) ||
      (body.type === 'api' && config.forward_to_functions === true)

    let remote!: ReturnType<typeof createClient>
    let remoteUrl = ''
    if (needsRemoteClient) {
      const r = await getRemoteClient(localSupabase, config.vault_prefix)
      remote = r.client
      remoteUrl = r.url
    }

    // Resolve tenant ID if isolation is enabled
    let tenantId: string | null = null
    if (config.tenant_isolation?.enabled) {
      tenantId = await getTenantId(localSupabase, config.tenant_isolation.setting_key, config.tenant_isolation.fallback_key)
    }

    // Helper: apply tenant filter to query
    function applyTenantFilter(query: any, table: string) {
      if (!tenantId || !config.tenant_isolation?.enabled) return query
      // If table_overrides has an explicit null for this table, skip tenant filtering (shared data)
      if (config.tenant_isolation.table_overrides && table in config.tenant_isolation.table_overrides) {
        const override = config.tenant_isolation.table_overrides[table]
        if (override === null || override === undefined) return query // skip — shared table
        return query.eq(override, tenantId) // use custom column name
      }
      return query.eq(config.tenant_isolation.column, tenantId)
    }

    // ── RPC ──
    if (body.type === 'rpc') {
      const fn = body.function as string
      if (!config.allowed_rpcs.includes(fn)) return json({ error: `RPC not allowed: ${fn}` }, req, 403)
      // Only inject p_tenant_id if the RPC is not in the unscoped_rpcs list
      const unscopedRpcs = (config as any).unscoped_rpcs ?? []
      const params = (tenantId && !unscopedRpcs.includes(fn)) ? { ...body.params, p_tenant_id: tenantId } : (body.params || {})
      const { data, error } = await remote.rpc(fn, params)
      if (error) return json({ data: null, error: { message: error.message } }, req, 400)
      return json({ data, error: null }, req)
    }

    // ── Query ──
    if (body.type === 'query') {
      const table = body.table as string
      if (!config.allowed_tables.includes(table)) return json({ error: `Table not allowed: ${table}` }, req, 403)

      const selectOpts: any = {}
      if (body.count) selectOpts.count = body.count
      if (body.head) selectOpts.head = body.head
      let query = remote.from(table).select(body.select || '*', Object.keys(selectOpts).length > 0 ? selectOpts : undefined)
      query = applyTenantFilter(query, table)

      // Apply additional filters (skip tenant_id from client)
      const filters = (body.filters || []).filter((f: { column: string }) =>
        f.column !== 'tenant_id'
      )
      query = applyFilters(query, filters)
      // Support both single order object and array of orders
      if (body.order) {
        const orders = Array.isArray(body.order) ? body.order : [body.order]
        for (const o of orders) {
          query = query.order(o.column, { ascending: o.ascending ?? true })
        }
      }
      if (body.limit) query = query.limit(body.limit)
      if (body.range) query = query.range(body.range[0], body.range[1])

      if (body.single) { const r = await query.single(); return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null, count: r.count }, req) }
      if (body.maybeSingle) { const r = await query.maybeSingle(); return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null, count: r.count }, req) }
      const r = await query
      return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null, count: r.count }, req)
    }

    // ── Upsert ──
    if (body.type === 'upsert') {
      const table = body.table as string
      if (!config.allowed_tables.includes(table)) return json({ error: `Table not allowed: ${table}` }, req, 403)
      const upsertData = tenantId ? { ...body.data, tenant_id: tenantId } : body.data
      const opts: any = {}; if (body.onConflict) opts.onConflict = body.onConflict
      let query = remote.from(table).upsert(upsertData, opts)
      if (body.select) query = query.select(body.select)
      if (body.single) { const r = await query.single(); return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req) }
      const r = await query
      return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req)
    }

    // ── Insert ──
    if (body.type === 'insert') {
      const table = body.table as string
      if (!config.allowed_tables.includes(table)) return json({ error: `Table not allowed: ${table}` }, req, 403)
      const insertData = tenantId ? { ...body.data, tenant_id: tenantId } : body.data
      let query = remote.from(table).insert(insertData)
      if (body.select) query = query.select(body.select)
      if (body.single) { const r = await query.single(); return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req) }
      const r = await query
      return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req)
    }

    // ── Update ──
    if (body.type === 'update') {
      const table = body.table as string
      if (!config.allowed_tables.includes(table)) return json({ error: `Table not allowed: ${table}` }, req, 403)
      let query = remote.from(table).update(body.data)
      query = applyTenantFilter(query, table)
      query = applyFilters(query, body.filters || [])
      if (body.select) query = query.select(body.select)
      if (body.single) { const r = await query.single(); return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req) }
      const r = await query
      return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req)
    }

    // ── Delete ──
    if (body.type === 'delete') {
      const table = body.table as string
      if (!config.allowed_tables.includes(table)) return json({ error: `Table not allowed: ${table}` }, req, 403)
      let query = remote.from(table).delete()
      query = applyTenantFilter(query, table)
      query = applyFilters(query, body.filters || [])
      const r = await query
      return r.error ? json({ data: null, error: { message: r.error.message } }, req, 400) : json({ data: r.data, error: null }, req)
    }

    // ── API (external HTTP or remote edge functions) ──
    if (body.type === 'api') {
      const endpoint = body.endpoint as string
      if (!endpoint || !config.allowed_api_endpoints.includes(endpoint)) {
        return json({ error: `API endpoint not allowed: ${endpoint}` }, req, 403)
      }

      let url: string
      const method = (body.method as string || 'GET').toUpperCase()
      const fetchHeaders: Record<string, string> = { 'Content-Type': 'application/json' }

      if (config.forward_to_functions) {
        // Forward to remote Supabase edge functions (GUL pattern)
        const { url: remUrl } = await getRemoteClient(localSupabase, config.vault_prefix)
        const remKey = (await localSupabase.rpc('get_vault_secret', { secret_name: `${config.vault_prefix}_service_role_key` })).data as string
        url = `${remUrl}/functions/v1/${endpoint}`
        fetchHeaders['Authorization'] = `Bearer ${remKey}`
        fetchHeaders['apikey'] = remKey
      } else if (config.api_config) {
        // External HTTP API (OAuth2 client-credentials, bearer-token, or api-key auth)
        const apiToken = await getApiToken(localSupabase, config.api_config, appSlug)
        let apiTenantId = ''
        if (config.api_config.tenant_setting_key) {
          apiTenantId = await getTenantId(localSupabase, config.api_config.tenant_setting_key)
        }
        url = config.api_config.base_url + config.api_config.url_template
          .replace('{tenant_id}', apiTenantId)
          .replace('{endpoint}', endpoint)
        fetchHeaders['Authorization'] = `Bearer ${apiToken}`
        fetchHeaders['Accept'] = 'application/json'
      } else {
        return json({ error: 'No API config for this app' }, req, 400)
      }

      // Append query params
      if (body.params && typeof body.params === 'object') {
        const search = new URLSearchParams()
        for (const [k, v] of Object.entries(body.params as Record<string, string>)) {
          if (v != null) search.set(k, String(v))
        }
        const qs = search.toString()
        if (qs) url += `?${qs}`
      }

      const timeout = body.timeout ?? 30_000
      const fetchOpts: RequestInit = { method, headers: fetchHeaders, signal: AbortSignal.timeout(Math.min(timeout, 600_000)) }
      if (['POST', 'PUT', 'PATCH'].includes(method)) {
        // Inject tenant organization_id into the request body for edge function calls
        const funcBody = { ...(body.body || {}) }
        if (tenantId && config.forward_to_functions) {
          funcBody.organization_id = tenantId
        }
        fetchOpts.body = JSON.stringify(funcBody)
      }

      const res = await fetch(url, fetchOpts)
      if (!res.ok) {
        const text = await res.text().catch(() => '')
        return json({ data: null, error: { message: `API ${res.status}: ${text || res.statusText}` } }, req, res.status >= 500 ? 502 : 400)
      }

      const apiData = await res.json()

      // Normalize HAL+JSON if not forwarding to functions
      if (!config.forward_to_functions && body.normalize !== false) {
        // Preserve paginated envelopes (e.g. Rippling's {results, next_link})
        // so frontends can read .results and .next_link from data directly to
        // walk pages. Detection: has a results array AND any pagination key
        // (next_link / next_cursor / has_more) — by KEY presence, not value,
        // because next_link being explicitly null means "this is the last page"
        // not "no pagination support."
        if (apiData && typeof apiData === 'object' && !Array.isArray(apiData)) {
          const obj = apiData as Record<string, unknown>
          const isEnvelope = Array.isArray(obj.results) &&
            ('next_link' in obj || 'next_cursor' in obj || 'has_more' in obj)
          if (isEnvelope) {
            return json({ data: apiData, error: null }, req)
          }
        }
        const items = normalizeApiList(apiData)
        return json({ data: items, error: null, _meta: { page: (apiData as Record<string, unknown>)?.page } }, req)
      }

      return json({ data: apiData, error: null }, req)
    }

    return json({ error: 'Invalid type. Must be query, rpc, upsert, insert, update, delete, or api.' }, req, 400)

  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return json({ error: message }, req, 500)
  }
})
