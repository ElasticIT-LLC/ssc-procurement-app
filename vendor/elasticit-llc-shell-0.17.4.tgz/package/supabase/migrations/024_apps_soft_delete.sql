-- Migration: 024_apps_soft_delete
--
-- Adds soft-delete support to public.apps. The Admin > App Management page
-- now performs UPDATE apps SET deleted_at = NOW() instead of DELETE; all UI
-- and feed queries filter on deleted_at IS NULL by default; a "Show deleted
-- apps" toggle plus Restore button surfaces and recovers soft-deleted rows
-- with no data loss.
--
-- Also adds foreign keys from app_permissions.app_slug and app_pages.app_slug
-- to apps.slug. These were previously plain TEXT columns; the FK lets
-- PostgREST recognize the relationship so joined queries (e.g.
-- from('app_permissions').select('*, apps!inner(deleted_at)')) can filter
-- catalog rows by their parent app's deleted_at state.

ALTER TABLE public.apps
  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ DEFAULT NULL;

COMMENT ON COLUMN public.apps.deleted_at IS
  'Soft-delete timestamp. NULL = active. NOT NULL = hidden from all UI/feed queries; row and all related data preserved for restore via Admin > App Management.';

-- Idempotent FK adds. apps.slug is UNIQUE (per migration 001), so the FK is
-- valid as long as no orphan rows exist in app_permissions/app_pages.
-- Migration 022's prune step ensures this at the boundary.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'app_permissions_app_slug_fkey'
  ) THEN
    ALTER TABLE public.app_permissions
      ADD CONSTRAINT app_permissions_app_slug_fkey
      FOREIGN KEY (app_slug) REFERENCES public.apps(slug) ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'app_pages_app_slug_fkey'
  ) THEN
    ALTER TABLE public.app_pages
      ADD CONSTRAINT app_pages_app_slug_fkey
      FOREIGN KEY (app_slug) REFERENCES public.apps(slug) ON DELETE CASCADE;
  END IF;
END $$;
