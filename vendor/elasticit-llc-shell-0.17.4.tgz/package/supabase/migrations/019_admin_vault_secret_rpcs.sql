-- 019_admin_vault_secret_rpcs.sql
-- ==========================================================================
-- WHY THIS MIGRATION EXISTS
--
-- Phase 2 added manifest-declared vault secrets (`vault_secrets[]` with
-- source=admin-input). publish-app cannot auto-fill those — they need the
-- human admin to provide the value. Today the only way to do that is via
-- Supabase Dashboard > Project Settings > Vault, which means an admin
-- leaves the portal to fill in a value and has no visibility from the
-- shell side about what's required.
--
-- This migration adds three SECURITY DEFINER RPC functions so the shell
-- admin UI can CRUD vault secrets against the project's `vault.secrets`
-- table without requiring service_role credentials on the client. Each
-- function checks `public.is_admin()` before touching vault, so the RPC
-- surface is effectively admin-only even though the function runs as the
-- owner (postgres / supabase_admin).
--
-- The function bodies reference vault.secrets but plpgsql does LATE
-- binding, so creation succeeds even on local dev where the vault schema
-- is absent. In that case, calling the RPC just raises a runtime error
-- (which the Admin UI renders gracefully as "Vault unavailable").
-- ==========================================================================

-- admin_list_vault_secrets — returns name, description, timestamps.
-- Values are NEVER returned (they're encrypted at rest; decryption is
-- only meaningful inside the target edge functions).
CREATE OR REPLACE FUNCTION public.admin_list_vault_secrets() RETURNS TABLE(name text, description text, created_at timestamptz, updated_at timestamptz) LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public, vault' AS $fn$ BEGIN IF NOT public.is_admin() THEN RAISE EXCEPTION 'Admin role required'; END IF; RETURN QUERY SELECT s.name, s.description, s.created_at, s.updated_at FROM vault.secrets s ORDER BY s.name; END; $fn$;

-- admin_upsert_vault_secret — creates a new secret if name doesn't exist,
-- otherwise updates the value/description. Returns the uuid.
CREATE OR REPLACE FUNCTION public.admin_upsert_vault_secret(p_name text, p_value text, p_description text DEFAULT '') RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public, vault' AS $fn$ DECLARE v_existing uuid; v_new uuid; BEGIN IF NOT public.is_admin() THEN RAISE EXCEPTION 'Admin role required'; END IF; SELECT id INTO v_existing FROM vault.secrets WHERE name = p_name; IF v_existing IS NULL THEN SELECT vault.create_secret(p_value, p_name, COALESCE(p_description, '')) INTO v_new; RETURN v_new; ELSE PERFORM vault.update_secret(v_existing, p_value, p_name, COALESCE(p_description, '')); RETURN v_existing; END IF; END; $fn$;

-- admin_delete_vault_secret — by name. Hard-delete.
CREATE OR REPLACE FUNCTION public.admin_delete_vault_secret(p_name text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public, vault' AS $fn$ DECLARE v_existing uuid; BEGIN IF NOT public.is_admin() THEN RAISE EXCEPTION 'Admin role required'; END IF; SELECT id INTO v_existing FROM vault.secrets WHERE name = p_name; IF v_existing IS NULL THEN RETURN false; END IF; DELETE FROM vault.secrets WHERE id = v_existing; RETURN true; END; $fn$;

-- Grant EXECUTE to authenticated — the is_admin() check inside each
-- function gates access; PostgREST needs EXECUTE to route the RPC.
GRANT EXECUTE ON FUNCTION public.admin_list_vault_secrets() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_upsert_vault_secret(text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_delete_vault_secret(text) TO authenticated;
