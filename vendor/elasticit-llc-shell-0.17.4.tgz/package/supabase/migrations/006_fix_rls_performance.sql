-- Fix RLS performance warnings on app_permissions and app_pages tables
-- 1. Wrap auth.role() in (select ...) to avoid per-row re-evaluation
-- 2. Restrict admin policies to INSERT/UPDATE/DELETE only (avoid overlap with read policy)

-- Drop existing policies
DROP POLICY IF EXISTS "app_permissions_read" ON public.app_permissions;
DROP POLICY IF EXISTS "app_permissions_admin" ON public.app_permissions;
DROP POLICY IF EXISTS "app_pages_read" ON public.app_pages;
DROP POLICY IF EXISTS "app_pages_admin" ON public.app_pages;

-- Recreate with (select ...) wrapper and separated actions
CREATE POLICY "app_permissions_read" ON public.app_permissions
  FOR SELECT USING ((select auth.role()) = 'authenticated');

CREATE POLICY "app_permissions_admin_insert" ON public.app_permissions
  FOR INSERT WITH CHECK (public.is_admin());

CREATE POLICY "app_permissions_admin_update" ON public.app_permissions
  FOR UPDATE USING (public.is_admin());

CREATE POLICY "app_permissions_admin_delete" ON public.app_permissions
  FOR DELETE USING (public.is_admin());

CREATE POLICY "app_pages_read" ON public.app_pages
  FOR SELECT USING ((select auth.role()) = 'authenticated');

CREATE POLICY "app_pages_admin_insert" ON public.app_pages
  FOR INSERT WITH CHECK (public.is_admin());

CREATE POLICY "app_pages_admin_update" ON public.app_pages
  FOR UPDATE USING (public.is_admin());

CREATE POLICY "app_pages_admin_delete" ON public.app_pages
  FOR DELETE USING (public.is_admin());
