-- Migration: 037_resolver_app_access_gate
--
-- Tighten resolve_notification_recipients so per-app event_types are also
-- gated on the user actually having access to that app at delivery time.
-- Previously a user could opt in to e.g. 'calculator:calculation_created',
-- then have their access revoked, and continue receiving emails + in-portal
-- bell entries forever (stale opt-ins were honored unconditionally).
--
-- Rules:
--   - 'system:*' and 'access:*' event_types are global; no app slug check.
--   - Any other prefixed event_type ('<slug>:<key>') requires the user to
--     have access to <slug> via at least one of:
--       * up.role = 'admin'                    (global access)
--       * role_app_permissions for that slug   (role-based)
--       * a 'grants' entry in permission_overrides matching apps/<slug>/*
--   - Unprefixed event_types (legacy) are treated as global and pass.

DROP FUNCTION IF EXISTS public.resolve_notification_recipients(text);

CREATE OR REPLACE FUNCTION public.resolve_notification_recipients(p_event_type text)
RETURNS TABLE(user_id uuid, email text)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $func$
  WITH event_app AS (
    SELECT
      CASE
        WHEN position(':' IN p_event_type) > 0
          AND split_part(p_event_type, ':', 1) NOT IN ('system', 'access')
        THEN split_part(p_event_type, ':', 1)
        ELSE NULL
      END AS app_slug
  )
  SELECT DISTINCT up.id AS user_id, lower(up.email) AS email
  FROM public.user_profiles up
  CROSS JOIN event_app ea
  WHERE up.email IS NOT NULL
    AND up.email <> ''
    AND (up.settings->'notifications'->>p_event_type)::boolean = true
    AND (
      ea.app_slug IS NULL
      OR up.role = 'admin'
      OR EXISTS (
        SELECT 1
        FROM public.user_role_assignments ura
        JOIN public.role_app_permissions rap ON rap.role_id = ura.role_id
        WHERE ura.user_id = up.id
          AND rap.app_slug = ea.app_slug
      )
      OR EXISTS (
        SELECT 1
        FROM jsonb_array_elements_text(
          COALESCE(up.permission_overrides->'grants', '[]'::jsonb)
        ) AS grant_key
        WHERE grant_key LIKE 'apps/' || ea.app_slug || '/%'
      )
    );
$func$;

REVOKE ALL ON FUNCTION public.resolve_notification_recipients(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.resolve_notification_recipients(text) TO authenticated, service_role;
