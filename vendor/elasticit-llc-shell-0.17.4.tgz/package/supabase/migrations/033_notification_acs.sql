-- Migration: 033_notification_acs
--
-- Pivots notification delivery from direct SMTP submission to the Azure
-- Communication Services Email REST API. Rationale: Mailpit (the SMTP target
-- we briefly aimed at) is a developer capture tool, not a production relay.
-- ACS gives us proper deliverability (verified sender domain, SPF/DKIM,
-- retry semantics, message-id tracking) and matches the pattern other
-- ElasticIT-LLC projects already use for production email.
--
-- New columns on notification_config:
--   acs_endpoint        — full ACS resource endpoint URL,
--                         e.g. https://<resource>.<region>.communication.azure.com
--   acs_sender_address  — verified sender address, e.g. donotreply@<verified-domain>
--
-- The SMTP-era columns (smtp_host / smtp_port / smtp_username /
-- smtp_from_address) and the older M365 columns (tenant_id, client_id, etc.)
-- are NOT dropped. They remain nullable so portals that haven't switched yet
-- don't break and historical config rows stay legible. The new edge function
-- reads only the acs_* columns.
--
-- Vault secrets:
--   notification_acs_access_key — ACS access key (HMAC-SHA256 signing key).
--                                 Required whenever acs_endpoint is set.

ALTER TABLE public.notification_config
  ADD COLUMN IF NOT EXISTS acs_endpoint TEXT,
  ADD COLUMN IF NOT EXISTS acs_sender_address TEXT;

COMMENT ON COLUMN public.notification_config.acs_endpoint IS
  'ACS resource endpoint URL (https://<resource>.<region>.communication.azure.com). Replaces the SMTP path.';
COMMENT ON COLUMN public.notification_config.acs_sender_address IS
  'From address; MUST be from a domain verified on the ACS Email Communication resource.';
