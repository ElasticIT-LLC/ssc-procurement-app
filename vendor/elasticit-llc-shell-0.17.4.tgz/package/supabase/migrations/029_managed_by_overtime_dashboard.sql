-- 024_managed_by_overtime_dashboard.sql
-- Migration 012 only marked the original three ElasticIT-managed apps
-- (printix, screening, msr-gul). 'overtime-dashboard' and 'pto-conversion'
-- were added later and default to managed_by='client'. Backfill them so the
-- Vault Secrets default-deny filter (shell v0.13.7) correctly hides their
-- associated infrastructure secrets from client admins.

UPDATE apps SET managed_by = 'elasticit'
WHERE slug IN ('overtime-dashboard', 'pto-conversion');
