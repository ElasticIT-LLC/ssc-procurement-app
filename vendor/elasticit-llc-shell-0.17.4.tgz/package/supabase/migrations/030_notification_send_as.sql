-- Migration: 030_notification_send_as
--
-- Adds notification_config.send_as_mailbox so the OAuth-connected user can
-- send "as" a different mailbox (e.g. an unlicensed shared mailbox like
-- do-not-reply@example.com). Microsoft Graph honors this when the OAuth
-- user has SendAs permission on the target — same pattern HaloPSA uses.
--
-- If null, the edge function falls back to connected_user_email (i.e. the
-- mail's From line matches the user who signed in).

ALTER TABLE public.notification_config
  ADD COLUMN IF NOT EXISTS send_as_mailbox TEXT;

COMMENT ON COLUMN public.notification_config.send_as_mailbox IS
  'Optional From-address override. The OAuth-connected user must have SendAs permission on this mailbox in Exchange. If null, mail sends as connected_user_email.';
