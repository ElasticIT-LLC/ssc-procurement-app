-- Migration: 032_notification_smtp
--
-- Switches notifications from Microsoft Graph (delegated OAuth) to plain
-- SMTP. The M365 path proved unworkable for unlicensed shared mailboxes /
-- alias-as-From, and Microsoft Graph fundamentally won't honor `from` for
-- arbitrary aliases via API. SMTP via a relay (Mailpit, Resend, ACS, etc.)
-- has none of those constraints — you set host/port/user/pass and the From
-- line is whatever you tell the relay it is.
--
-- New columns on notification_config:
--   smtp_host         — relay hostname, e.g. mailpit.elasticit.com
--   smtp_port         — port, typically 1025 (Mailpit), 587 (most relays), or 465 (TLS)
--   smtp_username     — auth user; null/empty if relay accepts anonymous (e.g., default Mailpit)
--   smtp_from_address — From header on outgoing mail (no Microsoft restrictions)
--
-- The M365-era columns (tenant_id, client_id, connected_user_email, etc.)
-- are NOT dropped. They remain nullable for now so portals that haven't
-- migrated yet don't break, and so we can keep historical data. The new
-- edge function ignores them.
--
-- Vault secrets:
--   notification_smtp_password — SMTP auth password; nullable for anonymous relays

ALTER TABLE public.notification_config
  ADD COLUMN IF NOT EXISTS smtp_host TEXT,
  ADD COLUMN IF NOT EXISTS smtp_port INTEGER,
  ADD COLUMN IF NOT EXISTS smtp_username TEXT,
  ADD COLUMN IF NOT EXISTS smtp_from_address TEXT;

COMMENT ON COLUMN public.notification_config.smtp_host IS
  'SMTP relay hostname (e.g. mailpit.example.com). Replaces the Microsoft Graph path.';
COMMENT ON COLUMN public.notification_config.smtp_port IS
  'SMTP relay port. Typically 1025 (Mailpit), 587 (submission with STARTTLS), or 465 (implicit TLS).';
COMMENT ON COLUMN public.notification_config.smtp_username IS
  'SMTP auth username. Null/empty when the relay accepts anonymous submission (e.g., default Mailpit).';
COMMENT ON COLUMN public.notification_config.smtp_from_address IS
  'From header for outgoing notification mail. Fully controllable — no Microsoft alias/license constraints.';
