-- Migration: 025_fix_sync_az_group_roles_variable_conflict
--
-- Fixes a long-standing bug in `internal.sync_az_group_roles(p_group_ids text[])`
-- where the function would always raise:
--
--   ERROR  42702: column reference "role_id" is ambiguous
--   DETAIL It could refer to either a PL/pgSQL variable or a table column.
--   QUERY  INSERT INTO public.user_role_assignments (user_id, role_id, assigned_by) ...
--
-- Root cause: the function declares `RETURNS TABLE(role_id uuid, role_name
-- text, assigned_by text)`, which creates an implicit OUT parameter named
-- `role_id`. When the body INSERTs into `public.user_role_assignments`,
-- the column list `(user_id, role_id, assigned_by)` ambiguously matches
-- both the OUT parameter and the table column. PL/pgSQL's default
-- conflict resolution (`error`) raises rather than picking one.
--
-- Net effect: AZ-group → role auto-assignment never worked end-to-end.
-- The function was called on every login, returned 400, and admins had
-- to manually assign roles via the UI for every new user.
--
-- Fix: add `#variable_conflict use_column` directive to the function body.
-- This tells PL/pgSQL: when ambiguous between a variable and a column,
-- prefer the column. Resolves the INSERT and ON CONFLICT clauses cleanly.
--
-- Idempotent: CREATE OR REPLACE FUNCTION reuses the existing OID, so
-- the public wrapper from migration 023 (which calls
-- internal.sync_az_group_roles) keeps working without modification.

CREATE OR REPLACE FUNCTION internal.sync_az_group_roles(p_group_ids text[])
  RETURNS TABLE(role_id uuid, role_name text, assigned_by text)
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO 'public'
AS $function$
#variable_conflict use_column
DECLARE
  calling_user_id UUID;
  mapped_role_ids UUID[];
BEGIN
  calling_user_id := auth.uid();
  IF calling_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Look up role IDs from az_group_role_mappings for the user's AZ groups
  SELECT ARRAY(
    SELECT DISTINCT m.role_id
    FROM public.az_group_role_mappings m
    JOIN public.roles r ON r.id = m.role_id
    WHERE m.group_id = ANY(p_group_ids)
      AND NOT r.is_system
  ) INTO mapped_role_ids;

  -- Insert new AZ group assignments
  INSERT INTO public.user_role_assignments (user_id, role_id, assigned_by)
  SELECT calling_user_id, rid, 'az_group'
  FROM unnest(mapped_role_ids) AS rid
  ON CONFLICT (user_id, role_id) DO NOTHING;

  -- Remove stale AZ group assignments (roles no longer mapped from any of user's groups)
  DELETE FROM public.user_role_assignments ura
  WHERE ura.user_id = calling_user_id
    AND ura.assigned_by = 'az_group'
    AND ura.role_id <> ALL(mapped_role_ids);

  -- Return all current assignments for this user
  RETURN QUERY
  SELECT ura.role_id, r.name, ura.assigned_by
  FROM public.user_role_assignments ura
  JOIN public.roles r ON r.id = ura.role_id
  WHERE ura.user_id = calling_user_id;
END;
$function$;
