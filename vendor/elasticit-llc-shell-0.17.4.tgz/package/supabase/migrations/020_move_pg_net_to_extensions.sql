-- 020_move_pg_net_to_extensions.sql
-- ==========================================================================
-- WHY THIS MIGRATION EXISTS
--
-- Supabase's Security Advisor flags any extension installed in the `public`
-- schema. The overtime-dashboard-app's sync-pattern migration ran
-- `CREATE EXTENSION IF NOT EXISTS pg_net;` without a schema qualifier, so
-- pg_net landed in `public` on Mainspring. The fix is to move it to the
-- `extensions` schema, which Supabase creates and recommends for all
-- project-level extensions.
--
-- pg_net is relocatable = FALSE (its control file doesn't permit
-- ALTER EXTENSION SET SCHEMA), so the move has to go through a DROP +
-- re-CREATE. Safety notes:
--
--   * pg_net's functions live in the `net.*` namespace which gets dropped
--     and recreated by the extension. Our trigger functions (e.g.
--     `trigger_<slug>_sync`) reference `net.http_post` in their bodies —
--     plpgsql late-binds these, so there's no pg_depend entry and the
--     DROP succeeds without CASCADE.
--
--   * Between the DROP and the CREATE there's a brief window where
--     `net.http_post` doesn't exist. If a pg_cron job fires in that window
--     it will raise a warning and skip; the hourly auto-retry picks it up.
--
--   * `net._http_response` (the response log table) gets dropped. We don't
--     read from it in application code — it's only used internally for
--     debugging HTTP responses and is safe to lose.
--
-- Idempotent: only runs the drop+recreate if pg_net is currently in public.
-- No-op on projects where pg_net is already in extensions or not installed.
-- ==========================================================================

DO $do$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_extension e
    JOIN pg_namespace n ON e.extnamespace = n.oid
    WHERE e.extname = 'pg_net' AND n.nspname = 'public'
  ) THEN
    -- extensions schema should exist on managed Supabase, but create
    -- defensively so self-hosted or older projects don't fail.
    CREATE SCHEMA IF NOT EXISTS extensions;

    -- pg_net is relocatable=false, so drop + recreate is the only path.
    DROP EXTENSION pg_net;
    CREATE EXTENSION pg_net WITH SCHEMA extensions;

    RAISE NOTICE 'Reinstalled pg_net into extensions schema';
  ELSE
    RAISE NOTICE 'pg_net not in public — no-op';
  END IF;
END;
$do$;
