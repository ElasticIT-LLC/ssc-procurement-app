-- 002_rbac_roles.sql
-- RBAC: Custom roles with per-app permission levels, AZ group auto-assignment
-- Runs on top of 001_base_schema.sql

-- ===========================================
-- New Tables
-- ===========================================

CREATE TABLE public.roles (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL UNIQUE,
  description TEXT,
  is_system   BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY roles_read ON public.roles FOR SELECT
  USING ((SELECT auth.uid()) IS NOT NULL);
CREATE POLICY roles_admin_insert ON public.roles FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY roles_admin_update ON public.roles FOR UPDATE
  USING (public.is_admin());
CREATE POLICY roles_admin_delete ON public.roles FOR DELETE
  USING (public.is_admin() AND NOT is_system);

-- Seed the system admin role
INSERT INTO public.roles (name, description, is_system)
VALUES ('Admin', 'System superuser with full access', true);

CREATE TABLE public.role_app_permissions (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id          UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  app_slug         TEXT NOT NULL,
  permission_level TEXT NOT NULL,
  UNIQUE(role_id, app_slug)
);

ALTER TABLE public.role_app_permissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY rap_read ON public.role_app_permissions FOR SELECT
  USING ((SELECT auth.uid()) IS NOT NULL);
CREATE POLICY rap_admin_insert ON public.role_app_permissions FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY rap_admin_update ON public.role_app_permissions FOR UPDATE
  USING (public.is_admin());
CREATE POLICY rap_admin_delete ON public.role_app_permissions FOR DELETE
  USING (public.is_admin());

CREATE TABLE public.user_role_assignments (
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_id     UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  assigned_by TEXT NOT NULL DEFAULT 'manual'
              CHECK (assigned_by IN ('manual', 'az_group')),
  assigned_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);

ALTER TABLE public.user_role_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY ura_read_own ON public.user_role_assignments FOR SELECT
  USING (user_id = (SELECT auth.uid()) OR public.is_admin());
CREATE POLICY ura_admin_insert ON public.user_role_assignments FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY ura_admin_update ON public.user_role_assignments FOR UPDATE
  USING (public.is_admin());
CREATE POLICY ura_admin_delete ON public.user_role_assignments FOR DELETE
  USING (public.is_admin());

-- ===========================================
-- AZ Group Sync Function (SECURITY DEFINER)
-- ===========================================

CREATE OR REPLACE FUNCTION public.sync_az_group_roles(
  group_ids TEXT[],
  group_role_mappings JSONB
)
RETURNS TABLE(role_id UUID, role_name TEXT, assigned_by TEXT) AS $$
DECLARE
  calling_user_id UUID;
  mapped_role_names TEXT[];
  r RECORD;
  group_id TEXT;
  role_names JSONB;
  role_name_text TEXT;
BEGIN
  calling_user_id := auth.uid();
  IF calling_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Collect all role names mapped from the user's AZ groups
  mapped_role_names := ARRAY[]::TEXT[];
  FOREACH group_id IN ARRAY group_ids LOOP
    role_names := group_role_mappings->group_id;
    IF role_names IS NOT NULL THEN
      FOR r IN SELECT jsonb_array_elements_text(role_names) AS name LOOP
        IF NOT r.name = ANY(mapped_role_names) THEN
          mapped_role_names := array_append(mapped_role_names, r.name);
        END IF;
      END LOOP;
    END IF;
  END LOOP;

  -- Insert new AZ group assignments for roles that exist in DB
  INSERT INTO public.user_role_assignments (user_id, role_id, assigned_by)
  SELECT calling_user_id, ro.id, 'az_group'
  FROM public.roles ro
  WHERE ro.name = ANY(mapped_role_names)
    AND NOT ro.is_system
  ON CONFLICT (user_id, role_id) DO NOTHING;

  -- Remove stale AZ group assignments (roles no longer mapped)
  DELETE FROM public.user_role_assignments ura
  WHERE ura.user_id = calling_user_id
    AND ura.assigned_by = 'az_group'
    AND ura.role_id NOT IN (
      SELECT ro.id FROM public.roles ro WHERE ro.name = ANY(mapped_role_names)
    );

  -- Return all current assignments for this user
  RETURN QUERY
  SELECT ura.role_id, ro.name, ura.assigned_by
  FROM public.user_role_assignments ura
  JOIN public.roles ro ON ro.id = ura.role_id
  WHERE ura.user_id = calling_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

-- ===========================================
-- Update is_admin() to use user_profiles directly
-- ===========================================

CREATE OR REPLACE FUNCTION public.is_admin() RETURNS BOOLEAN AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.user_profiles WHERE id = auth.uid() AND role = 'admin'
  )
$$ LANGUAGE sql SECURITY DEFINER STABLE SET search_path = 'public';

-- ===========================================
-- Update handle_new_user() — no longer inserts into user_roles
-- ===========================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, display_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, NEW.raw_user_meta_data->>'email', NEW.raw_user_meta_data->>'preferred_username', 'unknown'),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email, 'User'),
    'user'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

-- ===========================================
-- Replace apps_read RLS policy
-- ===========================================

DROP POLICY IF EXISTS apps_read ON public.apps;
CREATE POLICY apps_read ON public.apps FOR SELECT
  USING ((SELECT auth.uid()) IS NOT NULL);

-- ===========================================
-- Drop old columns from apps
-- ===========================================

ALTER TABLE public.apps DROP COLUMN IF EXISTS required_permission;
ALTER TABLE public.apps DROP COLUMN IF EXISTS required_role;

-- ===========================================
-- Drop old permissions column from user_profiles
-- ===========================================

ALTER TABLE public.user_profiles DROP COLUMN IF EXISTS permissions;

-- ===========================================
-- Drop old tables and functions
-- ===========================================

DROP TRIGGER IF EXISTS on_profile_role_change ON public.user_profiles;
DROP FUNCTION IF EXISTS public.sync_user_role();
DROP FUNCTION IF EXISTS public.current_user_role_rank();
DROP FUNCTION IF EXISTS public.role_rank(TEXT);
DROP POLICY IF EXISTS user_roles_no_direct_access ON public.user_roles;
DROP TABLE IF EXISTS public.user_roles;
