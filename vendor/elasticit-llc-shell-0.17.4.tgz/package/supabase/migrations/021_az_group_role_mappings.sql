-- 020_az_group_role_mappings.sql
-- Data-driven Azure AD group ↔ role mappings (replaces static rbacConfig.azGroupMappings)

-- ===========================================
-- New Table
-- ===========================================

CREATE TABLE public.az_group_role_mappings (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id   TEXT NOT NULL,
  group_name TEXT NOT NULL,
  role_id    UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(group_id, role_id)
);

ALTER TABLE public.az_group_role_mappings ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read (needed during login sync)
CREATE POLICY az_group_mappings_read ON public.az_group_role_mappings
  FOR SELECT USING ((SELECT auth.uid()) IS NOT NULL);

-- Only admins can insert/update/delete
CREATE POLICY az_group_mappings_admin_insert ON public.az_group_role_mappings
  FOR INSERT WITH CHECK (public.is_admin());

CREATE POLICY az_group_mappings_admin_update ON public.az_group_role_mappings
  FOR UPDATE USING (public.is_admin());

CREATE POLICY az_group_mappings_admin_delete ON public.az_group_role_mappings
  FOR DELETE USING (public.is_admin());

-- ===========================================
-- New single-param sync_az_group_roles (reads mappings from table)
-- ===========================================

-- The old two-param function (group_ids TEXT[], group_role_mappings JSONB)
-- is kept in migration 002 for backwards compat.
-- This new overload takes only the user's group IDs and reads mappings from the table.

CREATE OR REPLACE FUNCTION public.sync_az_group_roles(
  p_group_ids TEXT[]
)
RETURNS TABLE(role_id UUID, role_name TEXT, assigned_by TEXT) AS $$
DECLARE
  calling_user_id UUID;
  mapped_role_ids UUID[];
BEGIN
  calling_user_id := auth.uid();
  IF calling_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Look up role IDs from az_group_role_mappings for the user's AZ groups
  SELECT ARRAY(
    SELECT DISTINCT m.role_id
    FROM public.az_group_role_mappings m
    JOIN public.roles r ON r.id = m.role_id
    WHERE m.group_id = ANY(p_group_ids)
      AND NOT r.is_system
  ) INTO mapped_role_ids;

  -- Insert new AZ group assignments
  INSERT INTO public.user_role_assignments (user_id, role_id, assigned_by)
  SELECT calling_user_id, rid, 'az_group'
  FROM unnest(mapped_role_ids) AS rid
  ON CONFLICT (user_id, role_id) DO NOTHING;

  -- Remove stale AZ group assignments (roles no longer mapped from any of user's groups)
  DELETE FROM public.user_role_assignments ura
  WHERE ura.user_id = calling_user_id
    AND ura.assigned_by = 'az_group'
    AND ura.role_id <> ALL(mapped_role_ids);

  -- Return all current assignments for this user
  RETURN QUERY
  SELECT ura.role_id, r.name, ura.assigned_by
  FROM public.user_role_assignments ura
  JOIN public.roles r ON r.id = ura.role_id
  WHERE ura.user_id = calling_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';
