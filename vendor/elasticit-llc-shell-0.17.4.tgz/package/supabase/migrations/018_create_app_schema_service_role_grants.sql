-- 018_create_app_schema_service_role_grants.sql
-- ==========================================================================
-- WHY THIS MIGRATION EXISTS
--
-- The original `create_app_schema` (migration 009) grants USAGE + CRUD
-- defaults to `authenticated` and `anon` but NOT to `service_role`. Edge
-- functions that run as service_role (sync jobs, post-deploy hooks, etc.)
-- hit "permission denied for schema app_<slug>" on first write.
--
-- We discovered this the hard way during the Overtime Dashboard rollout —
-- the sync edge function couldn't write to its own schema until we ran
-- GRANTs manually via Management API. Every new schema-mode app with a
-- sync function would hit the same wall.
--
-- This migration does two things:
--   1. REPLACES `create_app_schema` to include service_role grants going
--      forward (idempotent — safe to re-run).
--   2. HEALS existing app_* schemas with a one-shot loop so we don't need
--      per-client manual SQL.
--
-- Per-schema errors in the heal loop are caught and logged as warnings so a
-- single bad schema doesn't block the whole migration.
-- ==========================================================================

CREATE OR REPLACE FUNCTION public.create_app_schema(p_schema_name TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Schema name must start with 'app_'
  IF NOT p_schema_name LIKE 'app_%' THEN
    RAISE EXCEPTION 'App schema names must start with app_. Got: %', p_schema_name;
  END IF;

  -- Create the schema
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', p_schema_name);

  -- Grant usage to authenticated, anon (PostgREST) + service_role (edge fns)
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO authenticated', p_schema_name);
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO anon', p_schema_name);
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO service_role', p_schema_name);

  -- Default privileges: authenticated can CRUD on future tables
  EXECUTE format(
    'ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO authenticated',
    p_schema_name
  );

  -- Default privileges: service_role gets full access (edge function writes,
  -- sync jobs, post-deploy hooks). ALL covers SELECT, INSERT, UPDATE, DELETE,
  -- TRUNCATE, REFERENCES, TRIGGER.
  EXECUTE format(
    'ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL ON TABLES TO service_role',
    p_schema_name
  );
  EXECUTE format(
    'ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL ON SEQUENCES TO service_role',
    p_schema_name
  );
END;
$$;

COMMENT ON FUNCTION public.create_app_schema(TEXT) IS
  'Creates app_* schema with grants for authenticated, anon, and service_role. Safe to re-run on existing schemas (grants are idempotent).';

-- ==========================================================================
-- HEAL PASS: extend grants to schemas that were created before this migration
-- ==========================================================================
DO $heal$
DECLARE
  s text;
BEGIN
  FOR s IN
    SELECT nspname
    FROM pg_namespace
    WHERE nspname LIKE 'app\_%' ESCAPE '\'
  LOOP
    BEGIN
      EXECUTE format('GRANT USAGE ON SCHEMA %I TO service_role', s);
      EXECUTE format('GRANT ALL ON ALL TABLES IN SCHEMA %I TO service_role', s);
      EXECUTE format('GRANT ALL ON ALL SEQUENCES IN SCHEMA %I TO service_role', s);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL ON TABLES TO service_role', s);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT ALL ON SEQUENCES TO service_role', s);
      RAISE NOTICE 'Granted service_role access to existing schema: %', s;
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING 'Failed to grant service_role access to %: % (continuing)', s, SQLERRM;
    END;
  END LOOP;
END;
$heal$;
