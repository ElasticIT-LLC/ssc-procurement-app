-- 023_security_definer_lockdown.sql
--
-- Resolves Supabase security advisor warnings:
--   0028_anon_security_definer_function_executable
--   0029_authenticated_security_definer_function_executable
--   0011_function_search_path_mutable
--
-- Strategy: two patterns depending on the function's call surface.
--
-- A) For triggers / event triggers / server-only functions never reached
--    via PostgREST: REVOKE EXECUTE FROM PUBLIC, anon, authenticated.
--    These never need user-role access. Service role retains EXECUTE.
--
-- B) For functions that ARE callable via PostgREST (RLS-internal
--    is_admin, admin RPCs called by client or edge function):
--    "Wrapper-in-public / DEFINER-in-internal" pattern:
--       1. ALTER FUNCTION public.X SET SCHEMA internal — moves the
--          DEFINER body to a non-exposed schema. OIDs are preserved,
--          so existing RLS policies that referenced public.X by OID
--          still resolve to the moved function.
--       2. CREATE OR REPLACE FUNCTION public.X(...) SECURITY INVOKER
--          AS $$ SELECT internal.X(...) $$ — a thin invoker shim in
--          the exposed schema. PostgREST routes /rest/v1/rpc/X to
--          this wrapper. The advisor lint only audits exposed schemas
--          and only flags SECURITY DEFINER, so the wrapper is silent
--          to the lint while the underlying privileged work still
--          happens inside internal.
--       3. GRANT EXECUTE on both layers to the appropriate roles.
--
-- Net effect: zero behavioral change. RLS works (OIDs preserved).
-- Frontend `.rpc()` calls work unchanged. Edge function `.rpc()` calls
-- work unchanged. Lint warnings cleared.
--
-- Idempotent + tolerant of missing functions: each statement is wrapped
-- in a DO block that catches `undefined_function` so the migration
-- succeeds on legacy projects with partial migration histories.

-- ===========================================================================
-- 0. Internal schema (not exposed via PostgREST)
--
-- Some shells ship with the `enforce_app_schema_prefix_trigger` event trigger
-- (migration 011+) that gates all schema creation to names starting with
-- `app_`. Postgres inherits roles transitively, so `postgres` (the role the
-- Management API runs as) is treated as a member of `app_developer` and the
-- trigger fires when we try to create the `internal` schema. We briefly
-- disable the trigger, create the schema, then re-enable. Idempotent —
-- handles projects with or without the trigger.
-- ===========================================================================

DO $$ BEGIN
  ALTER EVENT TRIGGER enforce_app_schema_prefix_trigger DISABLE;
EXCEPTION WHEN undefined_object THEN
  RAISE NOTICE 'enforce_app_schema_prefix_trigger not present — no need to disable';
END $$;

CREATE SCHEMA IF NOT EXISTS internal;

DO $$ BEGIN
  ALTER EVENT TRIGGER enforce_app_schema_prefix_trigger ENABLE;
EXCEPTION WHEN undefined_object THEN NULL;
END $$;

-- USAGE on the schema is required so wrappers can resolve `internal.X`.
-- This is NOT a security risk — actual function access is gated per-function
-- via EXECUTE grants below.
GRANT USAGE ON SCHEMA internal TO anon, authenticated, service_role;

-- ===========================================================================
-- A) PATTERN: Full revoke for non-PostgREST functions
-- ===========================================================================

-- Auth trigger — fires on auth.users INSERT, never client-invoked
DO $$ BEGIN
  REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'public.handle_new_user() not present — skipped';
END $$;

-- Event trigger on schema CREATE — never client-invoked
DO $$ BEGIN
  REVOKE EXECUTE ON FUNCTION public.auto_enable_app_rls() FROM PUBLIC, anon, authenticated;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'public.auto_enable_app_rls() not present — skipped';
END $$;

-- Internal PostgREST config helpers
DO $$ BEGIN
  REVOKE EXECUTE ON FUNCTION public._get_pgrst_db_schemas() FROM PUBLIC, anon, authenticated;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'public._get_pgrst_db_schemas() not present — skipped';
END $$;

DO $$ BEGIN
  REVOKE EXECUTE ON FUNCTION public._set_pgrst_db_schemas(p_schemas text[]) FROM PUBLIC, anon, authenticated;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'public._set_pgrst_db_schemas(text[]) not present — skipped';
END $$;

-- Vault read — server-only (called by proxy edge functions)
-- Also resolves lint 0011_function_search_path_mutable.
DO $$ BEGIN
  REVOKE EXECUTE ON FUNCTION public.get_vault_secret(secret_name text) FROM PUBLIC, anon, authenticated;
  GRANT EXECUTE ON FUNCTION public.get_vault_secret(secret_name text) TO service_role;
  ALTER FUNCTION public.get_vault_secret(secret_name text) SET search_path = pg_catalog, public;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'public.get_vault_secret(text) not present — skipped';
END $$;

-- ===========================================================================
-- B) PATTERN: Wrapper-in-public / DEFINER-in-internal for the 11 flagged fns
-- ===========================================================================

-- ---------------- is_admin() — used inside 30+ RLS policies ----------------
DO $$ BEGIN
  ALTER FUNCTION public.is_admin() SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.is_admin() already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.is_admin();
END $$;

CREATE OR REPLACE FUNCTION public.is_admin()
  RETURNS boolean
  LANGUAGE sql
  SECURITY INVOKER
  STABLE
  SET search_path = pg_catalog, public, internal
AS $$ SELECT internal.is_admin() $$;

REVOKE ALL ON FUNCTION public.is_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_admin() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION internal.is_admin() TO anon, authenticated, service_role;

-- ---------------- admin_list_vault_secrets() ----------------
DO $$ BEGIN
  ALTER FUNCTION public.admin_list_vault_secrets() SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.admin_list_vault_secrets() already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.admin_list_vault_secrets();
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.admin_list_vault_secrets()
    RETURNS TABLE(name text, description text, created_at timestamp with time zone, updated_at timestamp with time zone)
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT * FROM internal.admin_list_vault_secrets() $f$;
  REVOKE ALL ON FUNCTION public.admin_list_vault_secrets() FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.admin_list_vault_secrets() TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.admin_list_vault_secrets() TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'admin_list_vault_secrets — internal target missing, skipping wrapper';
END $$;

-- ---------------- admin_upsert_vault_secret(p_name, p_value, p_description) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.admin_upsert_vault_secret(p_name text, p_value text, p_description text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.admin_upsert_vault_secret(...) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.admin_upsert_vault_secret(p_name text, p_value text, p_description text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.admin_upsert_vault_secret(p_name text, p_value text, p_description text DEFAULT ''::text)
    RETURNS uuid
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.admin_upsert_vault_secret(p_name, p_value, p_description) $f$;
  REVOKE ALL ON FUNCTION public.admin_upsert_vault_secret(text, text, text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.admin_upsert_vault_secret(text, text, text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.admin_upsert_vault_secret(text, text, text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'admin_upsert_vault_secret — internal target missing, skipping wrapper';
END $$;

-- ---------------- admin_delete_vault_secret(p_name) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.admin_delete_vault_secret(p_name text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.admin_delete_vault_secret(text) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.admin_delete_vault_secret(p_name text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.admin_delete_vault_secret(p_name text)
    RETURNS boolean
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.admin_delete_vault_secret(p_name) $f$;
  REVOKE ALL ON FUNCTION public.admin_delete_vault_secret(text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.admin_delete_vault_secret(text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.admin_delete_vault_secret(text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'admin_delete_vault_secret — internal target missing, skipping wrapper';
END $$;

-- ---------------- create_app_schema(p_schema_name) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.create_app_schema(p_schema_name text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.create_app_schema(text) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.create_app_schema(p_schema_name text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.create_app_schema(p_schema_name text)
    RETURNS void
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.create_app_schema(p_schema_name) $f$;
  REVOKE ALL ON FUNCTION public.create_app_schema(text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.create_app_schema(text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.create_app_schema(text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'create_app_schema — internal target missing, skipping wrapper';
END $$;

-- ---------------- remove_app_schema(p_schema_name) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.remove_app_schema(p_schema_name text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.remove_app_schema(text) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.remove_app_schema(p_schema_name text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.remove_app_schema(p_schema_name text)
    RETURNS void
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.remove_app_schema(p_schema_name) $f$;
  REVOKE ALL ON FUNCTION public.remove_app_schema(text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.remove_app_schema(text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.remove_app_schema(text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'remove_app_schema — internal target missing, skipping wrapper';
END $$;

-- ---------------- apply_app_rls(p_schema_name, p_table_name, p_read_policy, p_write_policy) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.apply_app_rls(p_schema_name text, p_table_name text, p_read_policy text, p_write_policy text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.apply_app_rls(...) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.apply_app_rls(p_schema_name text, p_table_name text, p_read_policy text, p_write_policy text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.apply_app_rls(
    p_schema_name text,
    p_table_name text,
    p_read_policy text DEFAULT 'authenticated'::text,
    p_write_policy text DEFAULT 'authenticated'::text
  )
    RETURNS void
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.apply_app_rls(p_schema_name, p_table_name, p_read_policy, p_write_policy) $f$;
  REVOKE ALL ON FUNCTION public.apply_app_rls(text, text, text, text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.apply_app_rls(text, text, text, text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.apply_app_rls(text, text, text, text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'apply_app_rls — internal target missing, skipping wrapper';
END $$;

-- ---------------- get_schema_table_count(p_schema_name) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.get_schema_table_count(p_schema_name text) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.get_schema_table_count(text) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.get_schema_table_count(p_schema_name text);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.get_schema_table_count(p_schema_name text)
    RETURNS integer
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.get_schema_table_count(p_schema_name) $f$;
  REVOKE ALL ON FUNCTION public.get_schema_table_count(text) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.get_schema_table_count(text) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.get_schema_table_count(text) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'get_schema_table_count — internal target missing, skipping wrapper';
END $$;

-- ---------------- sync_app_permissions(manifests jsonb) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.sync_app_permissions(manifests jsonb) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.sync_app_permissions(jsonb) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.sync_app_permissions(manifests jsonb);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.sync_app_permissions(manifests jsonb)
    RETURNS void
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT internal.sync_app_permissions(manifests) $f$;
  REVOKE ALL ON FUNCTION public.sync_app_permissions(jsonb) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.sync_app_permissions(jsonb) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.sync_app_permissions(jsonb) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'sync_app_permissions — internal target missing, skipping wrapper';
END $$;

-- ---------------- sync_az_group_roles(group_ids text[], group_role_mappings jsonb) ----------------
DO $$ BEGIN
  ALTER FUNCTION public.sync_az_group_roles(group_ids text[], group_role_mappings jsonb) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.sync_az_group_roles(text[], jsonb) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.sync_az_group_roles(group_ids text[], group_role_mappings jsonb);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.sync_az_group_roles(group_ids text[], group_role_mappings jsonb)
    RETURNS TABLE(role_id uuid, role_name text, assigned_by text)
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT * FROM internal.sync_az_group_roles(group_ids, group_role_mappings) $f$;
  REVOKE ALL ON FUNCTION public.sync_az_group_roles(text[], jsonb) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.sync_az_group_roles(text[], jsonb) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.sync_az_group_roles(text[], jsonb) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'sync_az_group_roles(text[], jsonb) — internal target missing, skipping wrapper';
END $$;

-- ---------------- sync_az_group_roles(p_group_ids text[]) [overload] ----------------
DO $$ BEGIN
  ALTER FUNCTION public.sync_az_group_roles(p_group_ids text[]) SET SCHEMA internal;
EXCEPTION
  WHEN undefined_function THEN RAISE NOTICE 'public.sync_az_group_roles(text[]) already moved or absent';
  WHEN duplicate_function THEN
    RAISE NOTICE 'internal already has the function — dropping public stub for clean wrapper recreate';
    DROP FUNCTION IF EXISTS public.sync_az_group_roles(p_group_ids text[]);
END $$;

DO $$ BEGIN
  CREATE OR REPLACE FUNCTION public.sync_az_group_roles(p_group_ids text[])
    RETURNS TABLE(role_id uuid, role_name text, assigned_by text)
    LANGUAGE sql
    SECURITY INVOKER
    SET search_path = pg_catalog, public, internal
  AS $f$ SELECT * FROM internal.sync_az_group_roles(p_group_ids) $f$;
  REVOKE ALL ON FUNCTION public.sync_az_group_roles(text[]) FROM PUBLIC;
  GRANT EXECUTE ON FUNCTION public.sync_az_group_roles(text[]) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION internal.sync_az_group_roles(text[]) TO authenticated, service_role;
EXCEPTION WHEN undefined_function THEN RAISE NOTICE 'sync_az_group_roles(text[]) — internal target missing, skipping wrapper';
END $$;
