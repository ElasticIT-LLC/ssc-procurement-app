-- 013_remove_app_schema.sql
-- Function to cleanly remove an app's PostgreSQL schema.
-- Counterpart to create_app_schema (009). Drops policies, tables, and the schema itself,
-- then removes the schema from PostgREST's exposed schemas list.

CREATE OR REPLACE FUNCTION public.remove_app_schema(p_schema_name TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_table RECORD;
  v_policy RECORD;
  v_current_schemas TEXT;
  v_new_schemas TEXT;
BEGIN
  -- Schema name must start with 'app_'
  IF NOT p_schema_name LIKE 'app_%' THEN
    RAISE EXCEPTION 'App schema names must start with app_. Got: %', p_schema_name;
  END IF;

  -- Verify the schema exists
  IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = p_schema_name) THEN
    RAISE EXCEPTION 'Schema % does not exist', p_schema_name;
  END IF;

  -- 1. Remove the schema from pgrst.db_schemas (PostgREST exposed schemas)
  SELECT current_setting('pgrst.db_schemas', true) INTO v_current_schemas;
  IF v_current_schemas IS NOT NULL AND v_current_schemas LIKE '%' || p_schema_name || '%' THEN
    -- Build new comma-separated list without this schema
    SELECT string_agg(trim(s), ', ')
    INTO v_new_schemas
    FROM unnest(string_to_array(v_current_schemas, ',')) AS s
    WHERE trim(s) <> p_schema_name;

    IF v_new_schemas IS NULL THEN
      v_new_schemas := 'public';
    END IF;

    EXECUTE format('ALTER ROLE authenticator SET pgrst.db_schemas = %L', v_new_schemas);
    NOTIFY pgrst, 'reload config';
  END IF;

  -- 2. Drop all RLS policies on tables in this schema
  FOR v_table IN
    SELECT tablename FROM pg_tables WHERE schemaname = p_schema_name
  LOOP
    FOR v_policy IN
      SELECT policyname FROM pg_policies
      WHERE schemaname = p_schema_name AND tablename = v_table.tablename
    LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I',
        v_policy.policyname, p_schema_name, v_table.tablename);
    END LOOP;
  END LOOP;

  -- 3. Drop tables individually (no CASCADE)
  FOR v_table IN
    SELECT tablename FROM pg_tables WHERE schemaname = p_schema_name
  LOOP
    EXECUTE format('DROP TABLE %I.%I', p_schema_name, v_table.tablename);
  END LOOP;

  -- 4. Drop the now-empty schema
  EXECUTE format('DROP SCHEMA %I', p_schema_name);
END;
$$;
