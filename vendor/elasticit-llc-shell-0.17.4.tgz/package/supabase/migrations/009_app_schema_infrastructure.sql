-- 009_app_schema_infrastructure.sql
-- Infrastructure for app schema management (Option B) and self-service restricted role
-- Pre-validated against Supabase: all operations confirmed working

-- ============================================================================
-- FUNCTION: create_app_schema
-- Creates a PostgreSQL schema for an app with proper grants.
-- Enforces app_ prefix to prevent conflicts with system schemas.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.create_app_schema(p_schema_name TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Schema name must start with 'app_'
  IF NOT p_schema_name LIKE 'app_%' THEN
    RAISE EXCEPTION 'App schema names must start with app_. Got: %', p_schema_name;
  END IF;

  -- Create the schema
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', p_schema_name);

  -- Grant usage to authenticated and anon roles (PostgREST)
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO authenticated', p_schema_name);
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO anon', p_schema_name);

  -- Default privileges: authenticated can CRUD on future tables in this schema
  EXECUTE format(
    'ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO authenticated',
    p_schema_name
  );
END;
$$;

-- ============================================================================
-- FUNCTION: apply_app_rls
-- Applies standard RLS policies to a table in an app schema.
-- read_policy: 'authenticated' (any logged-in user) or 'admin' (admin only)
-- write_policy: 'authenticated' or 'admin'
-- ============================================================================
CREATE OR REPLACE FUNCTION public.apply_app_rls(
  p_schema_name TEXT,
  p_table_name TEXT,
  p_read_policy TEXT DEFAULT 'authenticated',
  p_write_policy TEXT DEFAULT 'authenticated'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_policy_prefix TEXT;
BEGIN
  -- Enable RLS
  EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', p_schema_name, p_table_name);

  -- Policy name prefix to avoid conflicts
  v_policy_prefix := p_schema_name || '_' || p_table_name;

  -- Service role always has full access (for edge functions)
  EXECUTE format(
    'CREATE POLICY %I ON %I.%I FOR ALL TO service_role USING (true) WITH CHECK (true)',
    v_policy_prefix || '_service', p_schema_name, p_table_name
  );

  -- Read policy
  IF p_read_policy = 'admin' THEN
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_read', p_schema_name, p_table_name
    );
  ELSE
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (true)',
      v_policy_prefix || '_read', p_schema_name, p_table_name
    );
  END IF;

  -- Write policies (INSERT, UPDATE, DELETE)
  IF p_write_policy = 'admin' THEN
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (public.is_admin())',
      v_policy_prefix || '_insert', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_update', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_delete', p_schema_name, p_table_name
    );
  ELSE
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (true)',
      v_policy_prefix || '_insert', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (true)',
      v_policy_prefix || '_update', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (true)',
      v_policy_prefix || '_delete', p_schema_name, p_table_name
    );
  END IF;
END;
$$;

-- ============================================================================
-- SELF-SERVICE: Restricted app_developer role
-- Clients who want to manage their own schemas get this role.
-- Can ONLY create schemas with app_ prefix. Cannot touch public/auth/storage/vault.
-- ============================================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'app_developer') THEN
    CREATE ROLE app_developer NOLOGIN;
  END IF;
END $$;

-- Allow creating schemas (prefix enforced by event trigger below)
GRANT CREATE ON DATABASE postgres TO app_developer;

-- Block access to shell and system schemas
REVOKE ALL ON SCHEMA public FROM app_developer;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM app_developer;

-- Event trigger function: enforce app_ prefix on schema creation
CREATE OR REPLACE FUNCTION public.enforce_app_schema_prefix()
RETURNS event_trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF obj.object_type = 'schema' THEN
      -- Extract schema name from object_identity
      IF obj.object_identity IS NOT NULL AND NOT obj.object_identity LIKE 'app_%' THEN
        -- Only enforce for app_developer role, not for superusers/service_role
        IF EXISTS (
          SELECT 1 FROM pg_roles
          WHERE rolname = current_user
          AND pg_has_role(current_user, 'app_developer', 'member')
        ) THEN
          RAISE EXCEPTION 'Client schemas must start with app_ prefix. Got: %', obj.object_identity;
        END IF;
      END IF;
    END IF;
  END LOOP;
END;
$$;

-- Only create the trigger if it doesn't already exist
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_event_trigger WHERE evtname = 'enforce_app_schema_prefix_trigger') THEN
    CREATE EVENT TRIGGER enforce_app_schema_prefix_trigger
      ON ddl_command_end
      WHEN TAG IN ('CREATE SCHEMA')
      EXECUTE FUNCTION public.enforce_app_schema_prefix();
  END IF;
END $$;
