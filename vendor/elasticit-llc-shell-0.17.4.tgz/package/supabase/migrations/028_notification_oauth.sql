-- Migration: 028_notification_oauth
--
-- Switches notifications from app-only Graph (Mail.Send Application) to
-- delegated OAuth (Mail.Send Delegated + offline_access). Avoids per-mailbox
-- Exchange Online licensing requirements and tenant-level AppOnly access
-- policies (e.g. [RAOP] errors): mail rides on the connected user's
-- existing license.
--
-- New columns:
--   connected_user_email   — UPN of the user who authorized; mail sends as them
--   connected_at           — when the OAuth handshake completed
--   oauth_state            — short-lived state token (CSRF guard) during initiate→callback
--   oauth_state_expires_at — TTL for the above (5 min)
--
-- The existing tenant_id + client_id columns stay (still needed for OAuth flow).
-- The sender_mailbox column is now derived from connected_user_email; column kept
-- nullable for backward-compat but no longer read by the edge function.
--
-- Vault secrets:
--   notification_m365_client_secret  — still required (for token exchange)
--   notification_m365_refresh_token  — NEW (long-lived, replaces app-only secret as the runtime auth)

ALTER TABLE public.notification_config
  ADD COLUMN IF NOT EXISTS connected_user_email TEXT,
  ADD COLUMN IF NOT EXISTS connected_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS oauth_state TEXT,
  ADD COLUMN IF NOT EXISTS oauth_state_expires_at TIMESTAMPTZ;

COMMENT ON COLUMN public.notification_config.connected_user_email IS
  'UPN of the M365 user who authorized via delegated OAuth. Mail sends as this user.';
COMMENT ON COLUMN public.notification_config.connected_at IS
  'Timestamp of the most recent successful OAuth handshake.';
COMMENT ON COLUMN public.notification_config.oauth_state IS
  'CSRF state token set during oauth-initiate, cleared during oauth-callback.';
COMMENT ON COLUMN public.notification_config.oauth_state_expires_at IS
  'TTL for oauth_state (5 minutes from initiate).';
