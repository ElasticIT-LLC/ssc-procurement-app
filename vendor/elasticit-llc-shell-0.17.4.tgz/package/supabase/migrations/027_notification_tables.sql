-- Migration: 027_notification_tables
--
-- Creates the per-portal email-notification config + subscriber tables.
-- The feature is opt-in: notification_config singleton ships with
-- enabled=false so no emails go out until an admin explicitly enables
-- it via the new /admin/notifications page.
--
-- Subscriber model: notification_subscriptions rows are EITHER role-based
-- (role_id set, email NULL) OR a manual email (email set, role_id NULL).
-- Enforced via CHECK + two UNIQUE constraints. Recipient resolution is a
-- UNION of (users assigned to subscribed roles) + (manual emails).

-- Singleton config table: enforced via CHECK (id = 1)
-- tenant_id + client_id are non-secret M365 identifiers (they appear in
-- public OAuth redirect URLs), kept here as plain columns so the admin
-- configures them inline on /admin/notifications. Only the client secret
-- is kept in Vault under `notification_m365_client_secret`.
CREATE TABLE public.notification_config (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled BOOLEAN NOT NULL DEFAULT false,
  sender_mailbox TEXT,
  tenant_id TEXT,
  client_id TEXT,
  updated_at TIMESTAMPTZ DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

INSERT INTO public.notification_config (id, enabled) VALUES (1, false)
  ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.notification_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notification_config_admin_all" ON public.notification_config
  FOR ALL USING (public.is_admin());

COMMENT ON TABLE public.notification_config IS
  'Singleton config for per-portal email notifications. enabled=false silences all sends. tenant_id + client_id are non-secret M365 identifiers; client secret is in Vault.';

-- Subscriber table
CREATE TABLE public.notification_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id UUID REFERENCES public.roles(id) ON DELETE CASCADE,
  email TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  CHECK ((role_id IS NOT NULL AND email IS NULL) OR (role_id IS NULL AND email IS NOT NULL)),
  UNIQUE(role_id),
  UNIQUE(email)
);

ALTER TABLE public.notification_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notification_subscriptions_admin_all" ON public.notification_subscriptions
  FOR ALL USING (public.is_admin());

COMMENT ON TABLE public.notification_subscriptions IS
  'Subscriber list for app notifications. Each row is either a role-based subscription (role_id set) or a manual email (email set), never both.';

-- Recipient resolver: union of role-based + manual subscribers, deduped, lowercased
CREATE OR REPLACE FUNCTION public.resolve_notification_recipients()
RETURNS TABLE(email text)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  WITH admin_role AS (
    SELECT id FROM public.roles WHERE is_system = true AND name = 'Admin' LIMIT 1
  ),
  recipients AS (
    -- role-based subscribers (via user_role_assignments)
    SELECT lower(up.email) AS email
    FROM public.user_role_assignments ura
    JOIN public.user_profiles up ON up.id = ura.user_id
    JOIN public.notification_subscriptions ns ON ns.role_id = ura.role_id
    WHERE up.email IS NOT NULL AND up.email <> ''
    UNION ALL
    -- Admin system role special-case (admins typically have no explicit assignment)
    SELECT lower(up.email)
    FROM public.user_profiles up
    WHERE up.role = 'admin' AND up.email IS NOT NULL AND up.email <> ''
      AND EXISTS (
        SELECT 1 FROM public.notification_subscriptions ns
        WHERE ns.role_id = (SELECT id FROM admin_role)
      )
    UNION ALL
    -- manual emails
    SELECT lower(ns.email)
    FROM public.notification_subscriptions ns
    WHERE ns.email IS NOT NULL AND ns.email <> ''
  )
  SELECT DISTINCT email FROM recipients;
$$;

REVOKE ALL ON FUNCTION public.resolve_notification_recipients() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.resolve_notification_recipients() TO authenticated, service_role;
