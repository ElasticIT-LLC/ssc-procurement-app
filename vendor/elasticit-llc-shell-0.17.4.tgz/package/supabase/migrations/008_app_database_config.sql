-- 008_app_database_config.sql
-- Adds database configuration support for apps
-- Option A (proxy): app uses separate Supabase, accessed via generic app-proxy
-- Option B (schema): app gets its own PostgreSQL schema within client's Supabase

-- db_mode: how the app accesses data
-- 'none'   = no database (default, e.g., static UI apps)
-- 'proxy'  = separate Supabase project, accessed via generic app-proxy edge function
-- 'schema' = own schema within this client's Supabase (e.g., app_scheduling)
ALTER TABLE apps ADD COLUMN IF NOT EXISTS db_mode TEXT DEFAULT 'none'
  CHECK (db_mode IN ('none', 'proxy', 'schema'));

-- proxy_config: configuration for the generic app-proxy (db_mode='proxy' only)
-- Stores allowlists, vault secret prefix, tenant isolation config, API config
ALTER TABLE apps ADD COLUMN IF NOT EXISTS proxy_config JSONB;

-- schema_config: configuration for app schemas (db_mode='schema' only)
-- Stores schema name, migration version, applied migrations, table list
ALTER TABLE apps ADD COLUMN IF NOT EXISTS schema_config JSONB;

-- db_status: current database status
ALTER TABLE apps ADD COLUMN IF NOT EXISTS db_status TEXT DEFAULT 'pending'
  CHECK (db_status IN ('pending', 'active', 'error', 'migrating'));

-- db_status_detail: human-readable status message (e.g., error details)
ALTER TABLE apps ADD COLUMN IF NOT EXISTS db_status_detail TEXT;

-- Set existing apps to 'none' (safe default)
UPDATE apps SET db_mode = 'none' WHERE db_mode IS NULL;
