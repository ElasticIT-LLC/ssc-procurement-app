-- 016_fix_auto_rls_invalid_syntax.sql
-- Fix invalid SQL in the auto_enable_app_rls event trigger.
--
-- Problem: migration 011 used "CREATE POLICY IF NOT EXISTS" which is NOT
-- valid PostgreSQL syntax — CREATE POLICY does not support IF NOT EXISTS.
-- This caused every CREATE TABLE in an app_* schema to fail with:
--   "syntax error at or near NOT"
-- The error bubbled up through publish-app's exec_sql call as if the app's
-- migration SQL itself was bad — wasted hours of debugging.
--
-- Fix: use the standard idempotent pattern: DROP POLICY IF EXISTS + CREATE
-- POLICY. This works correctly when the trigger fires on the same table
-- multiple times (re-uploads) or on a freshly created table.

CREATE OR REPLACE FUNCTION public.auto_enable_app_rls()
RETURNS event_trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  obj record;
  v_schema TEXT;
  v_table TEXT;
  v_prefix TEXT;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    -- Only handle tables
    IF obj.object_type = 'table' THEN
      -- Parse schema.table from object_identity
      v_schema := split_part(obj.object_identity, '.', 1);
      v_table  := split_part(obj.object_identity, '.', 2);

      -- Only apply to app_* schemas
      IF v_schema LIKE 'app_%' THEN
        v_prefix := v_schema || '_' || v_table;

        -- Enable RLS
        EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', v_schema, v_table);

        -- Service role: full access (for edge functions)
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_service', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR ALL TO service_role USING (true) WITH CHECK (true)',
          v_prefix || '_service', v_schema, v_table
        );

        -- Authenticated: read access
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_read', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (true)',
          v_prefix || '_read', v_schema, v_table
        );

        -- Authenticated: write access (INSERT, UPDATE, DELETE)
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_insert', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (true)',
          v_prefix || '_insert', v_schema, v_table
        );
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_update', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (true)',
          v_prefix || '_update', v_schema, v_table
        );
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_delete', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (true)',
          v_prefix || '_delete', v_schema, v_table
        );
      END IF;
    END IF;
  END LOOP;
END;
$body$;
