-- Migration: 035_in_app_notifications
--
-- Adds the in-portal bell notification system. Same per-user opt-in catalog
-- drives BOTH email delivery and in-app bell entries: when send-notification
-- resolves recipients for an event_type, it inserts one row per recipient
-- into public.notifications and sends the email.
--
-- Three changes:
--   1. public.notifications table (per-user notification records)
--   2. Replace resolve_notification_recipients(text) to return (user_id, email)
--      so the edge function can fan out both email + in-app writes from a
--      single round-trip.
--   3. Add public.notifications to the supabase_realtime publication so the
--      bell UI can subscribe via Supabase Realtime (no polling).

CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  app_slug TEXT,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_recent
  ON public.notifications(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
  ON public.notifications(user_id, created_at DESC)
  WHERE read_at IS NULL;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notifications_select_own" ON public.notifications;
CREATE POLICY "notifications_select_own" ON public.notifications
  FOR SELECT USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "notifications_update_own" ON public.notifications;
CREATE POLICY "notifications_update_own" ON public.notifications
  FOR UPDATE
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "notifications_delete_own" ON public.notifications;
CREATE POLICY "notifications_delete_own" ON public.notifications
  FOR DELETE USING (user_id = (SELECT auth.uid()));

COMMENT ON TABLE public.notifications IS
  'Per-user in-portal notification feed. Service-role inserts; users read/update/delete their own rows. Realtime-published.';

-- Replace resolver: now returns (user_id, email) so the edge function can
-- both insert per-user notification rows and send to the email list in one pass.
DROP FUNCTION IF EXISTS public.resolve_notification_recipients(text);
DROP FUNCTION IF EXISTS public.resolve_notification_recipients();

CREATE OR REPLACE FUNCTION public.resolve_notification_recipients(p_event_type text)
RETURNS TABLE(user_id uuid, email text)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $func$
  SELECT DISTINCT up.id AS user_id, lower(up.email) AS email
  FROM public.user_profiles up
  WHERE up.email IS NOT NULL
    AND up.email <> ''
    AND (up.settings->'notifications'->>p_event_type)::boolean = true;
$func$;

REVOKE ALL ON FUNCTION public.resolve_notification_recipients(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.resolve_notification_recipients(text) TO authenticated, service_role;

-- Add to the supabase_realtime publication. supabase_realtime is created
-- automatically by Supabase; ALTER PUBLICATION ADD TABLE is idempotent via
-- the IF NOT EXISTS check below using a DO block.
DO $do$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public'
        AND tablename = 'notifications'
    ) THEN
      EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications';
    END IF;
  END IF;
END;
$do$;
