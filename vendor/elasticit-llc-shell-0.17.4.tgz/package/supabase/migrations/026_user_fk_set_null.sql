-- ===========================================
-- 026_user_fk_set_null.sql
--
-- Make DELETE FROM auth.users idempotent for the User Management
-- "Remove" flow. Three FKs to auth.users default to NO ACTION,
-- which means deleting an auth.users row fails when any of these
-- tables still reference it.
--
-- Switch them to ON DELETE SET NULL so the historical rows
-- (audit_log entries, credential ownership, mapping authorship)
-- survive the user delete with their pointer nulled. The text
-- columns next to them (user_email on audit_log) preserve the
-- human-readable trail.
--
-- Tables left alone (already ON DELETE CASCADE, correct behaviour):
--   public.user_profiles.id              → auth.users(id)
--   public.user_role_assignments.user_id → auth.users(id)
--   public.user_roles.user_id            → auth.users(id)
-- ===========================================

ALTER TABLE public.audit_log
  DROP CONSTRAINT IF EXISTS audit_log_user_id_fkey;

ALTER TABLE public.audit_log
  ADD CONSTRAINT audit_log_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.credentials
  DROP CONSTRAINT IF EXISTS credentials_created_by_fkey;

ALTER TABLE public.credentials
  ADD CONSTRAINT credentials_created_by_fkey
  FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.az_group_role_mappings
  DROP CONSTRAINT IF EXISTS az_group_role_mappings_created_by_fkey;

ALTER TABLE public.az_group_role_mappings
  ADD CONSTRAINT az_group_role_mappings_created_by_fkey
  FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;
