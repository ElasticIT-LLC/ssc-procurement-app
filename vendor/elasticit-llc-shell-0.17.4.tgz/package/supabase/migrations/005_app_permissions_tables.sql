-- App permission catalog (seeded from app permissions.json manifests)
CREATE TABLE IF NOT EXISTS public.app_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_slug TEXT NOT NULL,
  permission_key TEXT NOT NULL,
  label TEXT NOT NULL,
  description TEXT,
  group_name TEXT,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(app_slug, permission_key)
);

-- App sidebar pages (seeded from app permissions.json manifests)
CREATE TABLE IF NOT EXISTS public.app_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_slug TEXT NOT NULL,
  page_key TEXT NOT NULL,
  label TEXT NOT NULL,
  permission_key TEXT,
  sort_order INT DEFAULT 0,
  UNIQUE(app_slug, page_key)
);

-- RLS
ALTER TABLE public.app_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "app_permissions_read" ON public.app_permissions
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "app_permissions_admin" ON public.app_permissions
  FOR ALL USING (public.is_admin());

CREATE POLICY "app_pages_read" ON public.app_pages
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "app_pages_admin" ON public.app_pages
  FOR ALL USING (public.is_admin());

-- SECURITY DEFINER function for auto-seeding from app manifests
CREATE OR REPLACE FUNCTION public.sync_app_permissions(manifests JSONB)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  app_slug_val TEXT;
  app_data JSONB;
  perm JSONB;
  pg JSONB;
  idx INT;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  FOR app_slug_val, app_data IN SELECT * FROM jsonb_each(manifests)
  LOOP
    idx := 0;
    IF app_data ? 'permissions' THEN
      FOR perm IN SELECT * FROM jsonb_array_elements(app_data->'permissions')
      LOOP
        INSERT INTO public.app_permissions (app_slug, permission_key, label, description, group_name, sort_order)
        VALUES (
          app_slug_val,
          perm->>'key',
          perm->>'label',
          perm->>'description',
          perm->>'group',
          idx
        )
        ON CONFLICT (app_slug, permission_key)
        DO UPDATE SET
          label = EXCLUDED.label,
          description = EXCLUDED.description,
          group_name = EXCLUDED.group_name,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;

    idx := 0;
    IF app_data ? 'pages' THEN
      FOR pg IN SELECT * FROM jsonb_array_elements(app_data->'pages')
      LOOP
        INSERT INTO public.app_pages (app_slug, page_key, label, permission_key, sort_order)
        VALUES (
          app_slug_val,
          pg->>'key',
          pg->>'label',
          pg->>'permission',
          idx
        )
        ON CONFLICT (app_slug, page_key)
        DO UPDATE SET
          label = EXCLUDED.label,
          permission_key = EXCLUDED.permission_key,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;
  END LOOP;
END;
$$;
