-- 010_app_version_history.sql
-- Stores every published version of an app for rollback support.
-- Used by the auto-publish CI/CD workflow and Admin UI rollback feature.

-- Version history table
CREATE TABLE IF NOT EXISTS public.app_versions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_id          UUID NOT NULL REFERENCES public.apps(id) ON DELETE CASCADE,
  version         TEXT NOT NULL,
  channel         TEXT NOT NULL DEFAULT 'production'
                  CHECK (channel IN ('production', 'preview')),
  bundle_url      TEXT NOT NULL,
  css_url         TEXT,
  integrity_hash  TEXT,
  metadata        JSONB DEFAULT '{}',
  published_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_by    TEXT,  -- 'ci', 'admin-ui', 'cli'
  git_sha         TEXT,
  UNIQUE(app_id, version)
);

-- Fast lookup: latest versions per app per channel
CREATE INDEX IF NOT EXISTS idx_app_versions_lookup
  ON public.app_versions(app_id, channel, published_at DESC);

-- RLS
ALTER TABLE public.app_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "app_versions_read" ON public.app_versions
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "app_versions_admin_insert" ON public.app_versions
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.user_profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Allow service_role (used by publish-to-feed.ts) to insert without RLS
-- service_role bypasses RLS by default, so no extra policy needed.

-- Extend loading_mode on apps table to support 'preview'
DO $$
BEGIN
  -- Drop existing check constraint if it exists
  ALTER TABLE public.apps DROP CONSTRAINT IF EXISTS apps_loading_mode_check;
  -- Add new constraint including 'preview'
  ALTER TABLE public.apps ADD CONSTRAINT apps_loading_mode_check
    CHECK (loading_mode IS NULL OR loading_mode IN ('native', 'remote', 'preview'));
EXCEPTION WHEN others THEN
  -- Constraint may not exist, that's fine
  NULL;
END $$;
