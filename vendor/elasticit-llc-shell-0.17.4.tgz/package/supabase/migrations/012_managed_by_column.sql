-- 012_managed_by_column.sql
-- Adds managed_by column to apps table to distinguish ElasticIT-managed apps from client apps.
-- ElasticIT-managed apps (printix, screening, msr-gul) are hidden from the Publish App dropdown
-- so clients can't accidentally overwrite them.

ALTER TABLE apps ADD COLUMN IF NOT EXISTS managed_by TEXT NOT NULL DEFAULT 'client';

-- Mark ElasticIT-managed apps
UPDATE apps SET managed_by = 'elasticit' WHERE slug IN ('printix', 'screening', 'msr-gul');
