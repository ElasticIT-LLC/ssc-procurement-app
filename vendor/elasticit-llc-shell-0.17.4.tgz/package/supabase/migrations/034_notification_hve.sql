-- Migration: 034_notification_hve
--
-- Pivots notification delivery from Azure Communication Services (REST) to
-- M365 High Volume Email (SMTP), fronted by a mailpit container in Azure.
-- All portals submit SMTP to one shared mailpit gateway; mailpit relays to
-- smtp-hve.office365.com. Single rotation surface for the HVE credential,
-- single From: address across all portals (notifications@elasticit.com).
--
-- New columns on notification_config:
--   hve_host         — mailpit gateway hostname in Azure
--   hve_port         — mailpit SMTP listener port (default 1025)
--   hve_username     — SMTP AUTH user; shared "portal-relay" across portals
--   hve_from_address — From: header; defaults to notifications@elasticit.com
--   hve_use_tls      — Enables STARTTLS on the SMTP connection (default true;
--                      set false only for local-dev mailpit)
--
-- The ACS-era columns (acs_endpoint, acs_sender_address) and SMTP-era
-- columns (smtp_host, smtp_port, smtp_username, smtp_from_address) are
-- NOT dropped. They remain nullable for backward compatibility with
-- portals not yet bootstrapped. The new edge function reads only hve_*
-- columns.
--
-- Vault secrets:
--   notification_hve_password — shared portal-relay SMTP password.
--                                Same value on every portal; rotated by
--                                updating mailpit's htpasswd + syncing to
--                                every portal's Vault.

ALTER TABLE public.notification_config
  ADD COLUMN IF NOT EXISTS hve_host TEXT,
  ADD COLUMN IF NOT EXISTS hve_port INTEGER NOT NULL DEFAULT 1025,
  ADD COLUMN IF NOT EXISTS hve_username TEXT NOT NULL DEFAULT 'portal-relay',
  ADD COLUMN IF NOT EXISTS hve_from_address TEXT NOT NULL
    DEFAULT 'notifications@elasticit.com',
  ADD COLUMN IF NOT EXISTS hve_use_tls BOOLEAN NOT NULL DEFAULT true;

COMMENT ON COLUMN public.notification_config.hve_host IS
  'Mailpit gateway hostname in Azure (e.g. mailpit-relay-<env>.<region>.azurecontainer.io).';
COMMENT ON COLUMN public.notification_config.hve_port IS
  'Mailpit SMTP listener port. Default 1025 (mailpit default).';
COMMENT ON COLUMN public.notification_config.hve_username IS
  'SMTP AUTH user for mailpit. Shared across all portals as "portal-relay".';
COMMENT ON COLUMN public.notification_config.hve_from_address IS
  'From header on outgoing notification mail. Defaults to notifications@elasticit.com; must match an HVE Accepted Domain.';
COMMENT ON COLUMN public.notification_config.hve_use_tls IS
  'Enables STARTTLS on the SMTP connection to mailpit. Default true; set false only for local-dev mailpit.';
