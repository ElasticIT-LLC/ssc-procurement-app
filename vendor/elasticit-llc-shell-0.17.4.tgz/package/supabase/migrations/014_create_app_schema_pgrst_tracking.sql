-- 014_create_app_schema_pgrst_tracking.sql
-- Completes the pgrst.db_schemas lifecycle started by 013_remove_app_schema.sql.
--
-- Problem solved:
--   1. create_app_schema (009) does NOT add new schemas to pgrst.db_schemas —
--      admins must manually expose each schema via the Supabase Dashboard.
--   2. remove_app_schema (013) uses current_setting('pgrst.db_schemas') to
--      read the current list, but that returns NULL when called from SECURITY
--      DEFINER contexts (service_role via edge functions, SET ROLE, etc.)
--      because pg_db_role_setting values only load at actual LOGIN, not via
--      SET ROLE. Result: schema gets dropped but pgrst.db_schemas is never
--      cleaned → orphan entries → PGRST002 lockup.
--   3. Existing projects may already have stale entries from prior manual
--      schema drops (this is what locked Certus out).
--
-- Fix strategy:
--   - Add _get_pgrst_db_schemas() that reads from pg_db_role_setting directly
--     (the authoritative source, role-agnostic)
--   - Add _set_pgrst_db_schemas() that ALTER ROLEs and NOTIFYs PostgREST
--   - Update create_app_schema to call _set_pgrst_db_schemas automatically
--   - Replace remove_app_schema with a version that uses the reliable helpers
--   - Run a one-time repair block to heal pre-existing stale entries

-- ============================================================================
-- HELPER: _get_pgrst_db_schemas
-- Reads the authenticator role's pgrst.db_schemas setting from pg_db_role_setting.
-- Unlike current_setting(), this works regardless of the calling role because
-- it reads the persisted configuration directly, not the session state.
-- Returns TEXT[] of schema names (always includes 'public' as fallback).
-- ============================================================================
CREATE OR REPLACE FUNCTION public._get_pgrst_db_schemas()
RETURNS TEXT[]
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_setting TEXT;
BEGIN
  SELECT split_part(cfg, '=', 2)
  INTO v_setting
  FROM pg_db_role_setting s
  JOIN pg_roles r ON s.setrole = r.oid
  CROSS JOIN LATERAL unnest(s.setconfig) AS cfg
  WHERE r.rolname = 'authenticator'
    AND cfg LIKE 'pgrst.db_schemas=%'
  LIMIT 1;

  IF v_setting IS NULL THEN
    RETURN ARRAY['public'];
  END IF;

  -- Split on comma, trim whitespace on each element
  RETURN ARRAY(
    SELECT trim(s)
    FROM unnest(string_to_array(v_setting, ',')) AS s
    WHERE trim(s) <> ''
  );
END;
$$;

-- ============================================================================
-- HELPER: _set_pgrst_db_schemas
-- Persists the authenticator role's pgrst.db_schemas setting and signals
-- PostgREST to reload its config + schema cache.
-- Always ensures 'public' is present, and removes duplicates.
-- ============================================================================
CREATE OR REPLACE FUNCTION public._set_pgrst_db_schemas(p_schemas TEXT[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_csv TEXT;
BEGIN
  -- Dedupe, ensure 'public' is always included, produce comma-separated list
  SELECT string_agg(DISTINCT s, ', ' ORDER BY s)
  INTO v_csv
  FROM unnest(array_prepend('public', p_schemas)) AS s
  WHERE s IS NOT NULL AND trim(s) <> '';

  EXECUTE format('ALTER ROLE authenticator SET pgrst.db_schemas = %L', v_csv);

  NOTIFY pgrst, 'reload config';
  NOTIFY pgrst, 'reload schema';
END;
$$;

-- ============================================================================
-- UPDATED: create_app_schema
-- Now auto-registers the new schema in pgrst.db_schemas so it's exposed via
-- the REST API without manual Dashboard intervention.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.create_app_schema(p_schema_name TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current TEXT[];
BEGIN
  -- Schema name must start with 'app_'
  IF NOT p_schema_name LIKE 'app_%' THEN
    RAISE EXCEPTION 'App schema names must start with app_. Got: %', p_schema_name;
  END IF;

  -- Create the schema
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', p_schema_name);

  -- Grant usage to authenticated and anon roles (PostgREST)
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO authenticated', p_schema_name);
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO anon', p_schema_name);

  -- Default privileges: authenticated can CRUD on future tables in this schema
  EXECUTE format(
    'ALTER DEFAULT PRIVILEGES IN SCHEMA %I GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO authenticated',
    p_schema_name
  );

  -- Track the schema in pgrst.db_schemas so PostgREST exposes it via REST.
  -- On managed Supabase, ALTER ROLE authenticator may fail with
  -- "permission denied to set parameter" because postgres is not a
  -- full superuser. In that case, emit a WARNING — admin must add the
  -- schema manually via Supabase Dashboard > Project Settings > API >
  -- "Exposed schemas". This still lets create_app_schema succeed.
  BEGIN
    v_current := public._get_pgrst_db_schemas();
    IF NOT (p_schema_name = ANY(v_current)) THEN
      PERFORM public._set_pgrst_db_schemas(array_append(v_current, p_schema_name));
    END IF;
  EXCEPTION WHEN insufficient_privilege THEN
    RAISE WARNING 'Could not auto-register % in pgrst.db_schemas (%). Add it manually via Supabase Dashboard > Project Settings > API > Exposed schemas.',
      p_schema_name, SQLERRM;
  END;
END;
$$;

-- ============================================================================
-- REPLACED: remove_app_schema
-- Original in 013 used current_setting() which returns NULL in SECURITY DEFINER
-- contexts (when called by service_role from edge functions, etc.). This version
-- uses _get/_set_pgrst_db_schemas which read pg_db_role_setting directly,
-- ensuring pgrst.db_schemas is always cleaned up regardless of caller.
--
-- Also: removes from pgrst.db_schemas BEFORE dropping tables/schema. This is
-- critical to prevent the PGRST002 cache lockup.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.remove_app_schema(p_schema_name TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current TEXT[];
  v_table RECORD;
  v_policy RECORD;
BEGIN
  -- Safety: only allow removing app_* schemas
  IF NOT p_schema_name LIKE 'app_%' THEN
    RAISE EXCEPTION 'App schema names must start with app_. Got: %', p_schema_name;
  END IF;

  -- 1. Remove from pgrst.db_schemas FIRST (prevents cache lockup when tables are dropped)
  v_current := public._get_pgrst_db_schemas();
  IF p_schema_name = ANY(v_current) THEN
    PERFORM public._set_pgrst_db_schemas(array_remove(v_current, p_schema_name));
  END IF;

  -- 2. Clear schema_config on any apps row pointing at this schema.
  -- Without this, if the app gets re-published later, publish-app's
  -- "skip already-applied migrations" logic thinks tables still exist
  -- and skips the initial migrations — leaving an empty schema. This
  -- caused a real incident (scheduling app showed 406 errors after the
  -- schema was dropped then re-published).
  UPDATE public.apps
  SET
    schema_config = NULL,
    db_status = 'pending',
    db_status_detail = 'schema dropped via remove_app_schema'
  WHERE (schema_config->>'schema_name') = p_schema_name;

  -- If schema already gone, the above cleanup is all that was needed
  IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = p_schema_name) THEN
    RETURN;
  END IF;

  -- 2. Drop all RLS policies on tables in this schema
  FOR v_table IN
    SELECT tablename FROM pg_tables WHERE schemaname = p_schema_name
  LOOP
    FOR v_policy IN
      SELECT policyname FROM pg_policies
      WHERE schemaname = p_schema_name AND tablename = v_table.tablename
    LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I',
        v_policy.policyname, p_schema_name, v_table.tablename);
    END LOOP;
  END LOOP;

  -- 3. Drop tables individually (no CASCADE — safer for PostgREST)
  FOR v_table IN
    SELECT tablename FROM pg_tables WHERE schemaname = p_schema_name
  LOOP
    EXECUTE format('DROP TABLE IF EXISTS %I.%I', p_schema_name, v_table.tablename);
  END LOOP;

  -- 4. Drop the now-empty schema
  EXECUTE format('DROP SCHEMA IF EXISTS %I', p_schema_name);
END;
$$;

-- ============================================================================
-- ONE-TIME REPAIR: reconcile pgrst.db_schemas with pg_namespace
-- Removes any tracked schemas that no longer exist. This heals existing
-- projects where DROP SCHEMA was run without first calling remove_app_schema
-- (the situation that caused the Certus lockup).
-- ============================================================================
DO $$
DECLARE
  v_current TEXT[];
  v_alive TEXT[];
  v_schema TEXT;
BEGIN
  v_current := public._get_pgrst_db_schemas();
  v_alive := ARRAY[]::TEXT[];

  FOREACH v_schema IN ARRAY v_current LOOP
    IF v_schema = 'public' OR EXISTS (
      SELECT 1 FROM pg_namespace WHERE nspname = v_schema
    ) THEN
      v_alive := array_append(v_alive, v_schema);
    END IF;
  END LOOP;

  IF array_length(v_alive, 1) IS DISTINCT FROM array_length(v_current, 1) THEN
    PERFORM public._set_pgrst_db_schemas(v_alive);
    RAISE NOTICE 'Repaired pgrst.db_schemas — removed % stale entries',
      array_length(v_current, 1) - array_length(v_alive, 1);
  END IF;
END $$;
