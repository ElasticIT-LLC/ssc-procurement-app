-- 007_app_feed.sql
-- Adds runtime app loading support (Piral-inspired feed service)
-- Apps can now be loaded dynamically at runtime from Supabase Storage

-- Extend apps table with runtime loading metadata
ALTER TABLE apps ADD COLUMN IF NOT EXISTS bundle_url TEXT;
ALTER TABLE apps ADD COLUMN IF NOT EXISTS css_url TEXT;
ALTER TABLE apps ADD COLUMN IF NOT EXISTS integrity_hash TEXT;
ALTER TABLE apps ADD COLUMN IF NOT EXISTS permissions_manifest JSONB;
ALTER TABLE apps ADD COLUMN IF NOT EXISTS loading_mode TEXT NOT NULL DEFAULT 'native'
  CHECK (loading_mode IN ('native', 'remote'));

-- Create storage bucket for app bundles
INSERT INTO storage.buckets (id, name, public)
VALUES ('app-bundles', 'app-bundles', false)
ON CONFLICT DO NOTHING;

-- Storage policies: admins can upload, authenticated users can download
CREATE POLICY "app_bundles_admin_upload" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'app-bundles'
    AND public.is_admin()
  );

CREATE POLICY "app_bundles_admin_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'app-bundles'
    AND public.is_admin()
  );

CREATE POLICY "app_bundles_admin_delete" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'app-bundles'
    AND public.is_admin()
  );

CREATE POLICY "app_bundles_auth_download" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'app-bundles'
    AND auth.role() = 'authenticated'
  );
