-- Migration: 036_app_notifications_catalog
--
-- Codifies the app_notifications catalog table. Each row is an event type
-- declared by an installed app's manifest.notifications[]. publish-app
-- upserts these from the .eitapp manifest on every upload; the portal's
-- NotificationsPage queries them to render per-app opt-in checkboxes.
--
-- Backstory: this table was first applied via MCP directly to the
-- ElasticIT Supabase during the per-user-opt-in pivot. Codifying it here
-- so new portals (Mainspring/Certus/Solterra) and the local-dev stack
-- shipped with elasticit-app-template both get it without manual SQL.
--
-- IF NOT EXISTS guards make this a no-op on ElasticIT (the table is
-- already there from MCP) and a clean create everywhere else.

CREATE TABLE IF NOT EXISTS public.app_notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_slug TEXT NOT NULL,
  key TEXT NOT NULL,
  label TEXT NOT NULL,
  description TEXT,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (app_slug, key),
  FOREIGN KEY (app_slug) REFERENCES public.apps(slug) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_app_notifications_slug
  ON public.app_notifications(app_slug, sort_order);

ALTER TABLE public.app_notifications ENABLE ROW LEVEL SECURITY;

-- Anyone who's authenticated can read the catalog — every user needs to
-- see which events exist to choose their opt-ins on the Notifications page.
DROP POLICY IF EXISTS "app_notifications_read_all" ON public.app_notifications;
CREATE POLICY "app_notifications_read_all" ON public.app_notifications
  FOR SELECT TO authenticated USING (true);

-- Only service_role writes (publish-app does the upsert). No write policy
-- for authenticated users — service_role bypasses RLS so it doesn't need one.

COMMENT ON TABLE public.app_notifications IS
  'Per-app notification event catalog. Populated by publish-app from each app manifest.notifications[]. Used by NotificationsPage to render per-user opt-in checkboxes.';
