-- 011_auto_rls_for_app_schemas.sql
-- Automatically enable RLS with default policies on ALL tables created in app_* schemas.
-- This eliminates the need for per-table apply_app_rls calls for the common case
-- (authenticated read/write). Only tables needing admin-only access require explicit overrides.

-- ============================================================================
-- EVENT TRIGGER FUNCTION: auto_enable_app_rls
-- Fires after CREATE TABLE. If the table is in an app_* schema, automatically:
--   1. Enables RLS
--   2. Creates service_role full-access policy
--   3. Creates authenticated read policy (SELECT USING true)
--   4. Creates authenticated write policies (INSERT/UPDATE/DELETE WITH CHECK true)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.auto_enable_app_rls()
RETURNS event_trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  obj record;
  v_schema TEXT;
  v_table TEXT;
  v_prefix TEXT;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    -- Only handle tables
    IF obj.object_type = 'table' THEN
      -- Parse schema.table from object_identity
      v_schema := split_part(obj.object_identity, '.', 1);
      v_table := split_part(obj.object_identity, '.', 2);

      -- Only apply to app_* schemas
      IF v_schema LIKE 'app_%' THEN
        v_prefix := v_schema || '_' || v_table;

        -- Enable RLS
        EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', v_schema, v_table);

        -- Service role: full access (for edge functions)
        EXECUTE format(
          'CREATE POLICY IF NOT EXISTS %I ON %I.%I FOR ALL TO service_role USING (true) WITH CHECK (true)',
          v_prefix || '_service', v_schema, v_table
        );

        -- Authenticated: read access
        EXECUTE format(
          'CREATE POLICY IF NOT EXISTS %I ON %I.%I FOR SELECT TO authenticated USING (true)',
          v_prefix || '_read', v_schema, v_table
        );

        -- Authenticated: write access (INSERT, UPDATE, DELETE)
        EXECUTE format(
          'CREATE POLICY IF NOT EXISTS %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (true)',
          v_prefix || '_insert', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY IF NOT EXISTS %I ON %I.%I FOR UPDATE TO authenticated USING (true)',
          v_prefix || '_update', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY IF NOT EXISTS %I ON %I.%I FOR DELETE TO authenticated USING (true)',
          v_prefix || '_delete', v_schema, v_table
        );
      END IF;
    END IF;
  END LOOP;
END;
$$;

-- ============================================================================
-- EVENT TRIGGER: auto_enable_app_rls_trigger
-- Fires after CREATE TABLE — applies default RLS to app_* schema tables.
-- ============================================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_event_trigger WHERE evtname = 'auto_enable_app_rls_trigger') THEN
    CREATE EVENT TRIGGER auto_enable_app_rls_trigger
      ON ddl_command_end
      WHEN TAG IN ('CREATE TABLE')
      EXECUTE FUNCTION public.auto_enable_app_rls();
  END IF;
END $$;
