-- 015_exec_sql_and_sync_perms_fix.sql
-- Adds two pieces that were previously applied to client DBs via Dashboard
-- (out of source control), causing fresh Supabase projects (including local
-- dev) to fail:
--
-- 1. public.exec_sql(sql text) — used by publish-app to run app migrations.
--    Without it: "Could not find the function public.exec_sql(sql)..."
--
-- 2. sync_app_permissions fix — allow service_role callers. The original
--    function (migration 005) rejects any caller where auth.uid() IS NULL,
--    but publish-app calls it via service_role which has no user context.
--    Result: "Not authenticated" warning on every app publish.

-- ============================================================================
-- FUNCTION: public.exec_sql
-- Executes arbitrary SQL as a superuser. Used by publish-app to run app
-- migrations (CREATE TABLE, etc.) in app_* schemas.
--
-- SECURITY: restricted to service_role only. Revoking from public/anon/
-- authenticated prevents ANY client-side role from calling it — this is
-- an SQL-injection API by design, so access must be gated to server-side
-- edge functions using the service key.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.exec_sql(sql TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  stmt TEXT;
BEGIN
  -- plpgsql EXECUTE only runs a single SQL statement at a time. App migration
  -- files typically contain multiple statements (CREATE TABLE + CREATE INDEX +
  -- INSERT, etc.), so we split on a semicolon followed by whitespace plus a
  -- newline (or end of input) and run each piece separately.
  --
  -- Limitation: the naive split below does NOT correctly handle semicolons
  -- embedded inside string literals or inline comments. For migrations with
  -- such constructs, split across multiple files or avoid the embedded ;.
  FOR stmt IN
    SELECT regexp_split_to_table(sql, E';\\s*(\\n|$)')
  LOOP
    stmt := trim(stmt);
    IF stmt <> '' THEN
      EXECUTE stmt;
    END IF;
  END LOOP;
END;
$body$;

-- Revoke from everyone, then grant only to service_role
REVOKE ALL ON FUNCTION public.exec_sql(TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.exec_sql(TEXT) FROM anon;
REVOKE ALL ON FUNCTION public.exec_sql(TEXT) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.exec_sql(TEXT) TO service_role;

COMMENT ON FUNCTION public.exec_sql(TEXT) IS
  'Execute arbitrary SQL as superuser. service_role only. Used by publish-app to run app schema migrations.';

-- ============================================================================
-- FUNCTION: public.get_schema_table_count
-- Returns the number of tables in a given schema. Used by publish-app to
-- verify that an app's schema actually has its expected tables before
-- trusting the cached migration_version in apps.schema_config.
--
-- Safe to expose (read-only catalog query).
-- ============================================================================
CREATE OR REPLACE FUNCTION public.get_schema_table_count(p_schema_name TEXT)
RETURNS INT
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::int FROM pg_tables WHERE schemaname = p_schema_name;
$$;

GRANT EXECUTE ON FUNCTION public.get_schema_table_count(TEXT) TO service_role, authenticated;

-- ============================================================================
-- FUNCTION: public.sync_app_permissions (UPDATED)
-- Original (migration 005) rejects callers with NULL auth.uid() — which
-- includes service_role invocations from edge functions. This version
-- accepts either:
--   (a) An authenticated user (auth.uid() IS NOT NULL), OR
--   (b) A service_role caller (which has full access to the DB anyway)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.sync_app_permissions(manifests JSONB)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  app_slug_val TEXT;
  app_data JSONB;
  perm JSONB;
  page JSONB;
  idx INT;
  v_jwt_role TEXT;
BEGIN
  -- Detect service_role callers. Because this is SECURITY DEFINER, current_role
  -- is always 'postgres' (the owner) and session_user is 'authenticator' (the
  -- pooler role). The authoritative signal is the JWT claim, which PostgREST
  -- exposes via the 'request.jwt.claims' GUC.
  v_jwt_role := (NULLIF(current_setting('request.jwt.claims', true), '')::jsonb)->>'role';

  -- Allow:
  --   (a) authenticated users (auth.uid() IS NOT NULL), OR
  --   (b) service_role callers from edge functions
  IF v_jwt_role <> 'service_role' AND auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  FOR app_slug_val, app_data IN SELECT * FROM jsonb_each(manifests)
  LOOP
    idx := 0;
    IF app_data ? 'permissions' THEN
      FOR perm IN SELECT * FROM jsonb_array_elements(app_data->'permissions')
      LOOP
        INSERT INTO public.app_permissions (
          app_slug, permission_key, label, description, group_name, sort_order
        ) VALUES (
          app_slug_val,
          perm->>'key',
          perm->>'label',
          perm->>'description',
          COALESCE(perm->>'group', 'General'),
          idx
        )
        ON CONFLICT (app_slug, permission_key) DO UPDATE SET
          label = EXCLUDED.label,
          description = EXCLUDED.description,
          group_name = EXCLUDED.group_name,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;

    idx := 0;
    IF app_data ? 'pages' THEN
      FOR page IN SELECT * FROM jsonb_array_elements(app_data->'pages')
      LOOP
        INSERT INTO public.app_pages (
          app_slug, page_key, label, permission_key, sort_order
        ) VALUES (
          app_slug_val,
          page->>'key',
          page->>'label',
          page->>'permission',
          idx
        )
        ON CONFLICT (app_slug, page_key) DO UPDATE SET
          label = EXCLUDED.label,
          permission_key = EXCLUDED.permission_key,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;

    -- Prune stale pages: remove app_pages rows whose page_key is no longer
    -- in the manifest. This handles renamed/removed pages.
    IF app_data ? 'pages' THEN
      DELETE FROM public.app_pages
      WHERE app_slug = app_slug_val
        AND page_key NOT IN (
          SELECT p->>'key' FROM jsonb_array_elements(app_data->'pages') AS p
        );
    END IF;
  END LOOP;
END;
$$;

COMMENT ON FUNCTION public.sync_app_permissions(JSONB) IS
  'Auto-seed app_permissions and app_pages from bundled permission manifests. Accepts calls from authenticated users AND service_role (for edge function invocations).';
