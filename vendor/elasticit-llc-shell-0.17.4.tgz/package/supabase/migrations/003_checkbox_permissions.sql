-- 003_checkbox_permissions.sql
-- Convert single permission level per app to independent permission keys
-- Runs on top of 002_rbac_roles.sql

-- ===========================================
-- Allow multiple permissions per app per role
-- ===========================================

-- Drop the one-per-app constraint
ALTER TABLE public.role_app_permissions
  DROP CONSTRAINT IF EXISTS role_app_permissions_role_id_app_slug_key;

-- Rename column from permission_level to permission_key
ALTER TABLE public.role_app_permissions
  RENAME COLUMN permission_level TO permission_key;

-- New constraint: one row per permission per app per role
ALTER TABLE public.role_app_permissions
  ADD CONSTRAINT role_app_permissions_role_app_perm_key
  UNIQUE(role_id, app_slug, permission_key);
