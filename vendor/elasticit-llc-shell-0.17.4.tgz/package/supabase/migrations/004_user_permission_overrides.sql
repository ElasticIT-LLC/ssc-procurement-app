-- 004_user_permission_overrides.sql
-- Add per-user permission overrides (grants/revokes) on top of role-based permissions
-- Runs on top of 003_checkbox_permissions.sql

ALTER TABLE public.user_profiles
  ADD COLUMN IF NOT EXISTS permission_overrides JSONB DEFAULT '{}';
