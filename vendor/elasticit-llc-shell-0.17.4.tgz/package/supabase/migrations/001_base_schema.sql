-- 001_base_schema.sql
-- Base schema for ElasticIT Portal Shell
-- Applied to each client's Supabase project during onboarding
-- Consolidated: includes 2-role system, credential vault v2, vault helper

-- ===========================================
-- Role Hierarchy
-- ===========================================

CREATE OR REPLACE FUNCTION public.role_rank(r TEXT) RETURNS INT AS $$
  SELECT CASE r
    WHEN 'admin' THEN 2
    WHEN 'user'  THEN 1
    ELSE 0
  END;
$$ LANGUAGE sql IMMUTABLE SET search_path = 'public';

-- ===========================================
-- User Roles (non-RLS lookup for is_admin)
-- ===========================================

CREATE TABLE public.user_roles (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role    TEXT NOT NULL DEFAULT 'user'
          CHECK (role IN ('admin', 'user'))
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY user_roles_no_direct_access ON public.user_roles FOR SELECT USING (false);

CREATE OR REPLACE FUNCTION public.is_admin() RETURNS BOOLEAN AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin'
  )
$$ LANGUAGE sql SECURITY DEFINER STABLE SET search_path = 'public';

-- ===========================================
-- User Profiles (RBAC layer on Supabase Auth)
-- ===========================================

CREATE TABLE public.user_profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email         TEXT NOT NULL,
  display_name  TEXT,
  avatar_url    TEXT,
  role          TEXT NOT NULL DEFAULT 'user'
                CHECK (role IN ('admin', 'user')),
  permissions   TEXT[] DEFAULT '{}',
  settings      JSONB DEFAULT '{}',
  created_at    TIMESTAMPTZ DEFAULT now(),
  updated_at    TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY profiles_read ON public.user_profiles FOR SELECT
  USING (id = (SELECT auth.uid()) OR public.is_admin());
CREATE POLICY profiles_admin_insert ON public.user_profiles FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY profiles_admin_update ON public.user_profiles FOR UPDATE
  USING (public.is_admin());
CREATE POLICY profiles_admin_delete ON public.user_profiles FOR DELETE
  USING (public.is_admin());

-- Auto-create profile + role on first login
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, display_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, NEW.raw_user_meta_data->>'email', NEW.raw_user_meta_data->>'preferred_username', 'unknown'),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email, 'User'),
    'user'
  );
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Keep user_roles in sync when role is changed via user_profiles
CREATE OR REPLACE FUNCTION public.sync_user_role()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, NEW.role)
  ON CONFLICT (user_id) DO UPDATE SET role = EXCLUDED.role;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

CREATE TRIGGER on_profile_role_change
  AFTER UPDATE OF role ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.sync_user_role();

-- ===========================================
-- App Registry (no url column)
-- ===========================================

CREATE TABLE public.apps (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug                TEXT NOT NULL UNIQUE,
  name                TEXT NOT NULL,
  description         TEXT,
  icon                TEXT,
  category            TEXT,
  sort_order          INT DEFAULT 0,
  required_permission TEXT,
  required_role       TEXT,
  status              TEXT DEFAULT 'active'
                      CHECK (status IN ('active', 'disabled', 'maintenance')),
  version             TEXT,
  metadata            JSONB DEFAULT '{}',
  created_at          TIMESTAMPTZ DEFAULT now(),
  updated_at          TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.apps ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.current_user_role_rank() RETURNS INT AS $$
  SELECT public.role_rank(role) FROM public.user_roles WHERE user_id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE SET search_path = 'public';

CREATE POLICY apps_read ON public.apps FOR SELECT USING (
  (SELECT auth.uid()) IS NOT NULL
  AND (
    required_role IS NULL
    OR public.current_user_role_rank() >= public.role_rank(required_role)
  )
);
CREATE POLICY apps_admin_insert ON public.apps FOR INSERT WITH CHECK (public.is_admin());
CREATE POLICY apps_admin_update ON public.apps FOR UPDATE USING (public.is_admin());
CREATE POLICY apps_admin_delete ON public.apps FOR DELETE USING (public.is_admin());

-- ===========================================
-- Audit Log
-- ===========================================

CREATE TABLE public.audit_log (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES auth.users(id),
  user_email    TEXT,
  action        TEXT NOT NULL,
  resource_type TEXT,
  resource_id   TEXT,
  metadata      JSONB DEFAULT '{}',
  ip_address    TEXT,
  created_at    TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_audit_log_created_at ON public.audit_log (created_at DESC);
CREATE INDEX idx_audit_log_user_id ON public.audit_log (user_id);
CREATE INDEX idx_audit_log_action ON public.audit_log (action);

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY audit_insert ON public.audit_log FOR INSERT
  WITH CHECK ((SELECT auth.uid()) IS NOT NULL);
CREATE POLICY audit_admin_read ON public.audit_log FOR SELECT
  USING (public.is_admin());

-- ===========================================
-- Credentials (encrypted, with app linking + verification)
-- ===========================================

CREATE TABLE public.credentials (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider        TEXT NOT NULL,
  label           TEXT NOT NULL,
  credential_type TEXT NOT NULL
                  CHECK (credential_type IN ('database', 'api_key', 'oauth2', 'bearer')),
  encrypted_data  TEXT NOT NULL,
  token_expiry    TIMESTAMPTZ,
  metadata        JSONB DEFAULT '{}',
  created_by      UUID REFERENCES auth.users(id),
  app_id          UUID REFERENCES public.apps(id) ON DELETE CASCADE,
  verified        BOOLEAN DEFAULT false,
  verified_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now(),
  updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_credentials_provider ON public.credentials (provider);
CREATE INDEX idx_credentials_created_by ON public.credentials (created_by);
CREATE INDEX idx_credentials_app_id ON public.credentials (app_id);

ALTER TABLE public.credentials ENABLE ROW LEVEL SECURITY;
CREATE POLICY credentials_admin_read ON public.credentials FOR SELECT
  USING (public.is_admin());
CREATE POLICY credentials_admin_insert ON public.credentials FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY credentials_admin_update ON public.credentials FOR UPDATE
  USING (public.is_admin());
CREATE POLICY credentials_admin_delete ON public.credentials FOR DELETE
  USING (public.is_admin());

-- ===========================================
-- Client Settings (key-value config per client)
-- ===========================================

CREATE TABLE public.client_settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

ALTER TABLE public.client_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY client_settings_read ON public.client_settings FOR SELECT
  USING (true);
CREATE POLICY client_settings_admin_insert ON public.client_settings FOR INSERT
  WITH CHECK (public.is_admin());
CREATE POLICY client_settings_admin_update ON public.client_settings FOR UPDATE
  USING (public.is_admin());
CREATE POLICY client_settings_admin_delete ON public.client_settings FOR DELETE
  USING (public.is_admin());

-- ===========================================
-- Vault Helper (reads secrets from Supabase Vault)
-- ===========================================

CREATE OR REPLACE FUNCTION public.get_vault_secret(secret_name TEXT)
RETURNS TEXT AS $$
  SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name = secret_name LIMIT 1;
$$ LANGUAGE sql SECURITY DEFINER STABLE SET search_path = 'vault';

-- ===========================================
-- Supabase Auth Schema — Enable RLS on OAuth tables
-- ===========================================
ALTER TABLE IF EXISTS auth.custom_oauth_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS auth.oauth_authorizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS auth.oauth_client_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS auth.oauth_clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS auth.oauth_consents ENABLE ROW LEVEL SECURITY;
