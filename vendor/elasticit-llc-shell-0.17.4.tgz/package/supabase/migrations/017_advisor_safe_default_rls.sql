-- 017_advisor_safe_default_rls.sql
-- Make default app-schema RLS policies satisfy Supabase's security advisor.
--
-- Problem: the auto_enable_app_rls event trigger (last set in migration 016)
-- creates INSERT/UPDATE/DELETE policies that use USING (true) / WITH CHECK (true).
-- The Supabase security advisor lint `0024_permissive_rls_policy` flags these
-- as "RLS Policy Always True" because the expression trivially evaluates to
-- true regardless of row or user. Every freshly uploaded schema-mode app
-- (scheduling, calc2, etc.) produces 9+ warnings on an otherwise-clean
-- project.
--
-- Fix: replace the trivially-true expression with `auth.uid() IS NOT NULL`.
-- Since the policies already target the `authenticated` role, this is the
-- same effective security model (any logged-in user can read/write any row)
-- but the expression has a function call and is no longer flagged as
-- trivially true. The advisor specifically permits `USING (true)` for SELECT
-- policies (intentional public-read pattern), so those stay unchanged.
--
-- Scope of this migration:
--   1. Replace auto_enable_app_rls() so future CREATE TABLE events in app_*
--      schemas produce advisor-safe defaults.
--   2. Heal already-installed client databases by dropping and recreating
--      every existing *_insert / *_update / *_delete policy on tables in
--      app_* schemas with the new expression. Client DBs (Certus, etc.)
--      will clear their existing warnings without requiring a re-upload.
--
-- App-author-defined policies (e.g. scheduling's slots_write FOR ALL
-- USING (true) WITH CHECK (true)) are NOT touched here — they are the
-- app's source of truth and fixing them would mask real authoring issues.
-- The CLAUDE.md templates now document the recommended pattern so future
-- app authors avoid this mistake.

-- ---------------------------------------------------------------------------
-- 1. Replace the event-trigger function with advisor-safe defaults
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.auto_enable_app_rls()
RETURNS event_trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  obj record;
  v_schema TEXT;
  v_table TEXT;
  v_prefix TEXT;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    -- Only handle tables
    IF obj.object_type = 'table' THEN
      -- Parse schema.table from object_identity
      v_schema := split_part(obj.object_identity, '.', 1);
      v_table  := split_part(obj.object_identity, '.', 2);

      -- Only apply to app_* schemas
      IF v_schema LIKE 'app_%' THEN
        v_prefix := v_schema || '_' || v_table;

        -- Enable RLS
        EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', v_schema, v_table);

        -- Service role: full access (for edge functions)
        -- Not flagged by advisor — service_role policies are exempt.
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_service', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR ALL TO service_role USING (true) WITH CHECK (true)',
          v_prefix || '_service', v_schema, v_table
        );

        -- Authenticated: read access
        -- SELECT with USING (true) is intentionally allowed by advisor.
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_read', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (true)',
          v_prefix || '_read', v_schema, v_table
        );

        -- Authenticated: write access (INSERT, UPDATE, DELETE)
        -- auth.uid() IS NOT NULL is functionally equivalent to `true` when
        -- the policy targets the `authenticated` role (authenticator cannot
        -- reach this role without a JWT), but the expression is non-trivial
        -- so the advisor does not flag it.
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_insert', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL)',
          v_prefix || '_insert', v_schema, v_table
        );
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_update', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL)',
          v_prefix || '_update', v_schema, v_table
        );
        EXECUTE format(
          'DROP POLICY IF EXISTS %I ON %I.%I',
          v_prefix || '_delete', v_schema, v_table
        );
        EXECUTE format(
          'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL)',
          v_prefix || '_delete', v_schema, v_table
        );
      END IF;
    END IF;
  END LOOP;
END;
$body$;

-- ---------------------------------------------------------------------------
-- 2. Fix apply_app_rls() — the "non-admin" branch also uses USING (true)
-- ---------------------------------------------------------------------------
-- apply_app_rls() (migration 009) is called by publish-app ONLY when a table
-- declares rls.read='admin' or rls.write='admin' in its manifest. The admin
-- branch uses public.is_admin() which is advisor-safe. The non-admin branch
-- uses USING (true) / WITH CHECK (true) — currently dead code, but a
-- landmine: any future caller of apply_app_rls() with write_policy other
-- than 'admin' would suddenly produce flagged policies. Patch it defensively
-- so the function is always advisor-safe regardless of caller.

CREATE OR REPLACE FUNCTION public.apply_app_rls(
  p_schema_name TEXT,
  p_table_name TEXT,
  p_read_policy TEXT DEFAULT 'authenticated',
  p_write_policy TEXT DEFAULT 'authenticated'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $apply_rls$
DECLARE
  v_policy_prefix TEXT;
BEGIN
  -- Enable RLS
  EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', p_schema_name, p_table_name);

  v_policy_prefix := p_schema_name || '_' || p_table_name;

  -- Drop any prior default policies with the same names so this function is
  -- idempotent on re-runs (event-trigger defaults share these names).
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', v_policy_prefix || '_service', p_schema_name, p_table_name);
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', v_policy_prefix || '_read',    p_schema_name, p_table_name);
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', v_policy_prefix || '_insert',  p_schema_name, p_table_name);
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', v_policy_prefix || '_update',  p_schema_name, p_table_name);
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', v_policy_prefix || '_delete',  p_schema_name, p_table_name);

  -- Service role always has full access (for edge functions)
  -- service_role policies are not flagged by advisor.
  EXECUTE format(
    'CREATE POLICY %I ON %I.%I FOR ALL TO service_role USING (true) WITH CHECK (true)',
    v_policy_prefix || '_service', p_schema_name, p_table_name
  );

  -- Read policy
  IF p_read_policy = 'admin' THEN
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_read', p_schema_name, p_table_name
    );
  ELSE
    -- SELECT with USING (true) is intentionally allowed by advisor.
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR SELECT TO authenticated USING (true)',
      v_policy_prefix || '_read', p_schema_name, p_table_name
    );
  END IF;

  -- Write policies (INSERT, UPDATE, DELETE)
  IF p_write_policy = 'admin' THEN
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (public.is_admin())',
      v_policy_prefix || '_insert', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_update', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (public.is_admin())',
      v_policy_prefix || '_delete', p_schema_name, p_table_name
    );
  ELSE
    -- auth.uid() IS NOT NULL is functionally equivalent to `true` when the
    -- policy targets the `authenticated` role, but advisor-safe.
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL)',
      v_policy_prefix || '_insert', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL)',
      v_policy_prefix || '_update', p_schema_name, p_table_name
    );
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL)',
      v_policy_prefix || '_delete', p_schema_name, p_table_name
    );
  END IF;
END;
$apply_rls$;

-- ---------------------------------------------------------------------------
-- 3. Heal existing flagged policies on already-installed app_* schemas
-- ---------------------------------------------------------------------------
-- One-time cleanup: scan every table in every app_* schema and replace any
-- *_insert / *_update / *_delete policy that uses the trivially-true
-- expression with one that uses auth.uid() IS NOT NULL.
--
-- We target ONLY the three auto-RLS default policy names (*_insert, *_update,
-- *_delete built from schema+table). App-author-defined policies with other
-- names (e.g. slots_write) are left alone intentionally.

DO $cleanup$
DECLARE
  v_schema TEXT;
  v_table TEXT;
  v_prefix TEXT;
BEGIN
  FOR v_schema, v_table IN
    SELECT n.nspname, c.relname
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relkind = 'r'
      AND n.nspname LIKE 'app_%'
  LOOP
    v_prefix := v_schema || '_' || v_table;

    -- INSERT
    IF EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = v_schema
        AND tablename  = v_table
        AND policyname = v_prefix || '_insert'
    ) THEN
      EXECUTE format(
        'DROP POLICY %I ON %I.%I',
        v_prefix || '_insert', v_schema, v_table
      );
      EXECUTE format(
        'CREATE POLICY %I ON %I.%I FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL)',
        v_prefix || '_insert', v_schema, v_table
      );
    END IF;

    -- UPDATE
    IF EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = v_schema
        AND tablename  = v_table
        AND policyname = v_prefix || '_update'
    ) THEN
      EXECUTE format(
        'DROP POLICY %I ON %I.%I',
        v_prefix || '_update', v_schema, v_table
      );
      EXECUTE format(
        'CREATE POLICY %I ON %I.%I FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL)',
        v_prefix || '_update', v_schema, v_table
      );
    END IF;

    -- DELETE
    IF EXISTS (
      SELECT 1 FROM pg_policies
      WHERE schemaname = v_schema
        AND tablename  = v_table
        AND policyname = v_prefix || '_delete'
    ) THEN
      EXECUTE format(
        'DROP POLICY %I ON %I.%I',
        v_prefix || '_delete', v_schema, v_table
      );
      EXECUTE format(
        'CREATE POLICY %I ON %I.%I FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL)',
        v_prefix || '_delete', v_schema, v_table
      );
    END IF;
  END LOOP;
END;
$cleanup$;
