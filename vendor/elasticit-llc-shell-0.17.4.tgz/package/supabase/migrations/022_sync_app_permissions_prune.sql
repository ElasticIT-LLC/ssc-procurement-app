-- Migration: 022_sync_app_permissions_prune
--
-- Extends public.sync_app_permissions() to PRUNE app_permissions and app_pages
-- rows whose app_slug is no longer in the manifest payload. Previously the RPC
-- only UPSERTED, so removing an app from the shell's compile-time
-- permissionManifests (or uninstalling a runtime app) left permanent orphan
-- rows in app_permissions / app_pages / role_app_permissions — visible in the
-- Admin > Roles page as if the app were still installed.
--
-- New behaviour:
--   1. UPSERT all apps in the manifest payload (unchanged).
--   2. Prune stale pages within each present app (unchanged).
--   3. Prune stale app_permissions / app_pages / role_app_permissions rows
--      whose app_slug is NOT in the manifest payload — BUT only for apps
--      whose row in public.apps is gone. This protects against partial
--      manifest syncs (e.g. dev sessions that only register one app).
--
-- The safety guard on step 3 matters: a developer running a shell build with
-- an intentionally-stripped appRegistry (to test one app in isolation) should
-- NOT wipe production permission rows. We only prune when the underlying
-- public.apps row has ALSO been removed — that is the signal that the app was
-- deliberately uninstalled.

CREATE OR REPLACE FUNCTION public.sync_app_permissions(manifests JSONB)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  app_slug_val TEXT;
  app_data JSONB;
  perm JSONB;
  page JSONB;
  idx INT;
  v_jwt_role TEXT;
BEGIN
  v_jwt_role := (NULLIF(current_setting('request.jwt.claims', true), '')::jsonb)->>'role';

  IF v_jwt_role <> 'service_role' AND auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  FOR app_slug_val, app_data IN SELECT * FROM jsonb_each(manifests)
  LOOP
    idx := 0;
    IF app_data ? 'permissions' THEN
      FOR perm IN SELECT * FROM jsonb_array_elements(app_data->'permissions')
      LOOP
        INSERT INTO public.app_permissions (
          app_slug, permission_key, label, description, group_name, sort_order
        ) VALUES (
          app_slug_val,
          perm->>'key',
          perm->>'label',
          perm->>'description',
          COALESCE(perm->>'group', 'General'),
          idx
        )
        ON CONFLICT (app_slug, permission_key) DO UPDATE SET
          label = EXCLUDED.label,
          description = EXCLUDED.description,
          group_name = EXCLUDED.group_name,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;

    idx := 0;
    IF app_data ? 'pages' THEN
      FOR page IN SELECT * FROM jsonb_array_elements(app_data->'pages')
      LOOP
        INSERT INTO public.app_pages (
          app_slug, page_key, label, permission_key, sort_order
        ) VALUES (
          app_slug_val,
          page->>'key',
          page->>'label',
          page->>'permission',
          idx
        )
        ON CONFLICT (app_slug, page_key) DO UPDATE SET
          label = EXCLUDED.label,
          permission_key = EXCLUDED.permission_key,
          sort_order = EXCLUDED.sort_order;
        idx := idx + 1;
      END LOOP;
    END IF;

    -- Prune stale pages: remove app_pages rows whose page_key is no longer
    -- in the manifest. This handles renamed/removed pages.
    IF app_data ? 'pages' THEN
      DELETE FROM public.app_pages
      WHERE app_slug = app_slug_val
        AND page_key NOT IN (
          SELECT p->>'key' FROM jsonb_array_elements(app_data->'pages') AS p
        );
    END IF;
  END LOOP;

  -- NEW: Prune orphan rows for apps that have been fully uninstalled
  -- (i.e. no matching row in public.apps). This clears stale rows left behind
  -- by previous versions of this RPC that only upserted.
  DELETE FROM public.role_app_permissions
  WHERE app_slug NOT IN (SELECT slug FROM public.apps);

  DELETE FROM public.app_pages
  WHERE app_slug NOT IN (SELECT slug FROM public.apps);

  DELETE FROM public.app_permissions
  WHERE app_slug NOT IN (SELECT slug FROM public.apps);
END;
$$;

COMMENT ON FUNCTION public.sync_app_permissions(JSONB) IS
  'Auto-seed app_permissions and app_pages from bundled permission manifests. Prunes orphan rows whose app_slug no longer exists in public.apps. Accepts calls from authenticated users AND service_role.';
