-- Migration: 031_admin_vault_rpc_service_role
--
-- Edge functions authenticate as service_role internally. The original 019
-- migration gated admin_upsert_vault_secret / admin_delete_vault_secret on
-- public.is_admin(), which returns false for service_role (no auth.uid()).
--
-- That broke the send-notification edge function's oauth-callback path
-- (introduced in v0.13.8) when it tried to persist the M365 refresh token:
--   "admin_upsert_vault_secret(notification_m365_refresh_token) failed:
--    Admin role required"
--
-- Adding `auth.role() = 'service_role'` to both functions' allow-checks.
-- Service role can already write anywhere in the database (bypasses RLS),
-- so this grants no new privilege — it just unblocks the legitimate
-- edge-function caller path. Existing admin-JWT callers still work.

CREATE OR REPLACE FUNCTION public.admin_upsert_vault_secret(p_name text, p_value text, p_description text DEFAULT '') RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public, vault' AS $fn$ DECLARE v_existing uuid; v_new uuid; BEGIN IF NOT (public.is_admin() OR auth.role() = 'service_role') THEN RAISE EXCEPTION 'Admin role required'; END IF; SELECT id INTO v_existing FROM vault.secrets WHERE name = p_name; IF v_existing IS NULL THEN SELECT vault.create_secret(p_value, p_name, COALESCE(p_description, '')) INTO v_new; RETURN v_new; ELSE PERFORM vault.update_secret(v_existing, p_value, p_name, COALESCE(p_description, '')); RETURN v_existing; END IF; END; $fn$;

CREATE OR REPLACE FUNCTION public.admin_delete_vault_secret(p_name text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public, vault' AS $fn$ DECLARE v_existing uuid; BEGIN IF NOT (public.is_admin() OR auth.role() = 'service_role') THEN RAISE EXCEPTION 'Admin role required'; END IF; SELECT id INTO v_existing FROM vault.secrets WHERE name = p_name; IF v_existing IS NULL THEN RETURN false; END IF; DELETE FROM vault.secrets WHERE id = v_existing; RETURN true; END; $fn$;

GRANT EXECUTE ON FUNCTION public.admin_upsert_vault_secret(text, text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_delete_vault_secret(text) TO service_role;
