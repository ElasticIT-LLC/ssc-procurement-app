# ElasticIT Portal — Developer Guide

Comprehensive guide for ElasticIT developers and client developers building on the portal platform.

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Adding a New App](#adding-a-new-app)
3. [Onboarding a New Client](#onboarding-a-new-client)
4. [Role-Based Access Control (RBAC)](#role-based-access-control)
5. [App Development Guide](#app-development-guide)
6. [App Database Management](#app-database-management)
7. [Publishing & Deployment](#publishing--deployment)
8. [Admin Portal Guide](#admin-portal-guide)
9. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

The ElasticIT portal is a multi-tenant application platform where each client (company) gets their own isolated portal deployment. Apps are micro-frontends that load into the portal at runtime.

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                        Client Portal                         │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ @elasticit-llc/shell (Framework)                        ││
│  │  • Auth (Microsoft Entra ID)                            ││
│  │  • Layout (Sidebar + TopBar)                            ││
│  │  • RBAC (Roles + Permission Keys)                       ││
│  │  • Admin Pages (Users, Roles, Apps, Credentials, Audit) ││
│  │  • App Loader (Runtime Discovery from Feed)             ││
│  │  • Credential Vault (AES-256-GCM encrypted)             ││
│  └─────────────────────────────────────────────────────────┘│
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Printix  │  │   GUL    │  │  App C   │  │  App D   │   │
│  │  (app)   │  │  (app)   │  │  (app)   │  │  (app)   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│          ↑ Uses @elasticit-llc/app-bridge hooks ↑           │
└─────────────────────────────────────────────────────────────┘
         │                          │
    Supabase (per client)     Supabase Storage
    • Auth + DB + RLS         • App JS/CSS bundles
    • Edge Functions          • Served via signed URLs
    • App Feed table
```

### How Apps Load

Apps are loaded **at runtime** from a feed service — no client shell rebuild needed to add, remove, or update apps.

```
User opens portal
  → Shell authenticates via Microsoft Entra ID
  → FeedLoader component detects auth is complete
  → Shell calls app-feed edge function (POST, authenticated)
  → Feed returns list of active remote apps with bundle URLs
  → For each app: inject CSS <link>, dynamic import(bundle_url)
  → Import map resolves react/app-bridge to shell's copies (single React instance)
  → Each app's setup(api) function registers pages, extensions
  → Sidebar renders permission-gated pages from app_pages table
  → User navigates to an app page → NativeAppHost resolves component
  → NativeAppHost checks: compile-time appRegistry first, then runtime AppLoader
```

**Key timing:** The feed is loaded AFTER authentication completes (inside `FeedLoader` component, which lives inside `AuthProvider`). This ensures the edge function receives a valid Bearer token. If the user navigates to a remote app while the feed is still loading, `NativeAppHost` shows a loading spinner instead of "App not installed."

### Dependency Chain

```
@elasticit-llc/app-bridge (v0.7.0)    ← React hooks SDK for apps
        ↑
@elasticit-llc/shell (v0.6.2)         ← Framework (auth, layout, RBAC, app loader)
        ↑
client-*-shell                         ← Client portal (brand theme, Supabase config, import maps)
        ↑
apps (printix, gul, etc.)              ← Micro-frontend apps (load at runtime via feed)
```

### Import Maps — How Shared Dependencies Work

Remote app bundles externalize `react`, `react-dom`, and `@elasticit-llc/app-bridge` (they are NOT bundled into the app). When the browser dynamically imports an app bundle, it needs to resolve these bare specifiers to the shell's copies.

This is handled by **import maps** — a native browser feature that maps bare module specifiers to URLs:

```html
<!-- Injected by vite-plugin-shared-deps.ts -->
<script type="importmap">
{
  "imports": {
    "react": "/shared/react-shim.js",
    "react-dom": "/node_modules/.vite/deps/react-dom.js",
    "react/jsx-runtime": "/shared/jsx-runtime-shim.js",
    "@elasticit-llc/app-bridge": "/node_modules/.vite/deps/@elasticit-llc_app-bridge.js"
  }
}
</script>
```

**Why shims are needed (dev mode):** Vite pre-bundles CJS dependencies with only a `default` export. But app bundles use ESM named imports (e.g., `import { useState } from 'react'`). The shim files in `public/shared/` re-export all named exports from the default:

```js
// public/shared/react-shim.js
import React from '/node_modules/.vite/deps/react.js'
export default React
export const { useState, useEffect, lazy, memo, /* ... */ } = React
```

**In production builds**, the import map plugin generates proper ESM wrappers from Vite's chunked output — no shims needed.

### Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 / TypeScript / Vite 6 / Tailwind CSS v4 |
| Backend | Supabase (Auth + PostgreSQL + RLS + Edge Functions + Storage) |
| Auth | Microsoft Entra ID via Supabase Auth |
| RBAC | Custom roles with Azure-style hierarchical permission keys |
| App Loading | Runtime discovery via feed service + import maps for shared deps |
| Deployment | Azure Static Web Apps |
| Packages | GitHub Packages (`@elasticit-llc` scope) |
| CI/CD | GitHub Actions (auto-publish to client feeds) |

---

## Adding a New App

### Step 1: Scaffold

```bash
npx create-elasticit-app
```

Interactive prompts:
- **App slug** (e.g., `inventory`) — used in routes, package name, permission keys
- **Display name** (e.g., "Inventory Manager") — shown in sidebar
- **Icon** (emoji) — shown next to app name
- **Pages** (comma-separated, e.g., `dashboard, products, orders`)
- **Needs proxy?** — yes if the app accesses external data

Output: a complete app directory with:
```
inventory-app/
├── src/
│   ├── index.ts          # setup() + App export
│   ├── App.tsx            # Backward-compat component
│   ├── app.css            # Tailwind with shell tokens
│   ├── pages/
│   │   ├── DashboardPage.tsx
│   │   ├── ProductsPage.tsx
│   │   └── OrdersPage.tsx
│   ├── hooks/             # Proxy hooks (if proxy requested)
│   └── components/
├── permissions.json       # RBAC manifest
├── package.json           # elasticitApp: true
├── vite.config.ts         # ESM + CSS output
└── CLAUDE.md
```

### Step 2: Develop

```bash
cd inventory-app
npm install
npm run dev          # Watch mode — rebuilds on file changes
```

The app receives shell context via `@elasticit-llc/app-bridge` hooks:

```tsx
import { useShellContext, usePermissions, useToast } from '@elasticit-llc/app-bridge'

function DashboardPage() {
  const { user, currentPage } = useShellContext()
  const { hasPermission } = usePermissions()
  const { showToast } = useToast()

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-shell-100">Dashboard</h1>
      <p className="text-shell-400">Welcome, {user?.name}</p>
      {hasPermission('apps/inventory/orders/manage') && (
        <button className="px-4 py-2 bg-brand-600 text-white rounded">Create Order</button>
      )}
    </div>
  )
}
```

### Step 3: Define Permissions

Edit `permissions.json`:

```json
{
  "slug": "inventory",
  "name": "Inventory Manager",
  "icon": "📦",
  "permissions": [
    { "key": "apps/inventory/*", "label": "Full Access", "description": "Full access to all features", "group": "Administration" },
    { "key": "apps/inventory/dashboard/view", "label": "View Dashboard", "description": "View dashboard and KPIs", "group": "General" },
    { "key": "apps/inventory/products/read", "label": "View Products", "description": "View product catalog", "group": "Products" },
    { "key": "apps/inventory/products/manage", "label": "Manage Products", "description": "Add, edit, delete products", "group": "Products" },
    { "key": "apps/inventory/orders/read", "label": "View Orders", "description": "View order history", "group": "Orders" },
    { "key": "apps/inventory/orders/manage", "label": "Manage Orders", "description": "Create and process orders", "group": "Orders" }
  ],
  "pages": [
    { "key": "dashboard", "label": "Dashboard", "permission": "apps/inventory/dashboard/view" },
    { "key": "products", "label": "Products", "permission": "apps/inventory/products/read" },
    { "key": "orders", "label": "Orders", "permission": "apps/inventory/orders/read" }
  ]
}
```

**Permission key format:** `apps/{slug}/{resource}/{action}`
- Common actions: `view`, `read`, `manage`, `create`, `delete`
- Wildcard: `apps/{slug}/*` grants all permissions for the app
- Pages reference permission keys — the sidebar only shows pages the user has permission for

### Step 4: Publish

There are **two publishing paths** depending on who's publishing:

#### For ElasticIT Developers (publishing to client feeds)

ElasticIT publishes apps across multiple clients via CLI or CI/CD:

```bash
# Publish to a specific client
npm run publish-to-feed -- \
  --supabase-url https://certus-project.supabase.co \
  --service-role-key eyJ...

# Or publish to all clients via CI (push a version tag)
git tag v1.0.0 && git push --tags
# GitHub Action: publish-to-feeds.yml deploys to all target clients
```

#### For Client Developers (self-service publishing)

Clients publish apps to their **own portal** — no ElasticIT approval needed:

**Option A: Via Admin UI (no CLI required)**
1. Build the app: `npm run build`
2. Open their portal → **Admin > App Management**
3. Click "Upload & Deploy"
4. Select the JS bundle (`dist/*.js`) and optionally CSS (`dist/*.css`)
5. Set version number → click upload
6. App appears immediately for all users

**Option B: Via CLI (if client has service role key)**
```bash
npm run publish-to-feed -- \
  --supabase-url https://their-project.supabase.co \
  --service-role-key eyJ...
```

**What happens during publish:**
1. Builds the app (`vite build`)
2. Uploads `dist/*.js` + `dist/*.css` to Supabase Storage (`app-bundles/{slug}/{version}/`)
3. Computes SHA-256 integrity hash
4. Upserts the `apps` table row with `loading_mode='remote'`, `bundle_url`, `css_url`, `permissions_manifest`
5. If `proxy.json` exists: sets `db_mode='proxy'`, `proxy_config` (Option A database)
6. If `database.json` exists: creates schema, applies migrations, sets RLS (Option B database)
7. Syncs permissions to `app_permissions` + `app_pages` tables
8. Logs an audit entry

**The app appears in the portal on the next page load. No shell rebuild needed. No ElasticIT approval required.**

### Step 5: Assign Permissions

In the portal, go to **Admin > Roles** and assign the new app's permissions to appropriate roles:

1. Select a role (e.g., "Basic User")
2. Find the new app in the permissions list
3. Check the permissions you want to grant
4. Save

Users with that role will now see the app's pages in their sidebar.

---

## Publishing Model: Self-Service with Oversight

The ElasticIT portal follows the **Piral publishing model**: each team publishes independently, with platform oversight but no approval gate.

### How It Works

```
Client developer builds and publishes app
  → App is immediately active in their portal
  → ElasticIT is notified (audit log)
  → ElasticIT can see all apps across all client portals
  → ElasticIT can disable/remove an app if there's an issue
  → No approval gate — clients move at their own speed
```

### Who Can Do What

| Actor | Can Publish | Can Disable | Can See All Clients | Scope |
|-------|-----------|-----------|-------------------|-------|
| **Client admin** | Yes (own portal) | Yes (own apps) | No (own portal only) | Their Supabase project |
| **Client developer** | Yes (via CLI or Admin UI) | No | No | Their Supabase project |
| **ElasticIT developer** | Yes (any client) | Yes (any client) | Yes (all portals) | All Supabase projects |

### ElasticIT Oversight Capabilities

ElasticIT manages all client Supabase projects and has full visibility:

- **Audit log**: Every publish/update/disable is logged with user, timestamp, and details
- **App Management**: See all apps in each client portal (versions, db status, bundle URLs)
- **Supabase dashboard**: Direct access to each client's database, storage, and edge functions
- **Override power**: Can disable any app across any client portal if it causes issues
- **Notifications**: Audit entries can trigger webhooks (Slack, email) for new app publishes

### Isolation Guarantee

Each client's feed is their **own Supabase project** — completely isolated:
- Client A publishing a bad app cannot affect Client B's portal
- Client A cannot see or access Client B's Supabase
- ElasticIT can see all clients but clients cannot see each other

### Comparison with Piral

| Aspect | Piral | ElasticIT |
|--------|-------|-----------|
| Publishing model | Teams publish independently | Same — clients publish independently |
| Approval gate | None | None |
| Platform oversight | Piral Cloud dashboard | Admin UI + audit log + Supabase dashboard |
| Override control | Platform can disable pilets | ElasticIT can disable any app |
| Feed isolation | Shared feed (filtered by rules) | Per-client feed (separate Supabase — stronger isolation) |

---

## Onboarding a New Client

### Step 1: Scaffold the Client Shell

```bash
npx create-elasticit-shell
```

Interactive prompts:
- **Client slug** (e.g., `acme`)
- **Client display name** (e.g., "Acme Corp")
- **Brand hex color** (e.g., `#1f81b2`) — generates full 50-900 palette
- **Supabase URL** — the client's Supabase project URL
- **Supabase anon key**

Output: a complete client shell with brand colors, dark mode, import maps, and feed integration.

### Step 2: Create Supabase Project

1. Create a new Supabase project for the client
2. Apply database migrations (001-007) in order:

```bash
# Via Supabase CLI
npx supabase db push --linked

# Or manually via SQL editor in Supabase dashboard
# Run each migration file in order: 001_base_schema.sql through 007_app_feed.sql
```

### Step 3: Configure Authentication

In the Supabase dashboard:
1. Go to **Authentication > Providers > Azure**
2. Set the client's **Entra ID Tenant ID**, **Client ID**, and **Client Secret**
3. The redirect URL is `https://{supabase-ref}.supabase.co/auth/v1/callback`

### Step 4: Deploy Edge Functions

```bash
# Deploy credential vault (required for all clients)
npx supabase functions deploy credential-vault --no-verify-jwt

# Deploy app feed (required for runtime app loading)
npx supabase functions deploy app-feed --no-verify-jwt

# Deploy app-specific proxies as needed
npx supabase functions deploy printix-proxy --no-verify-jwt
```

Set required secrets:
```bash
npx supabase secrets set \
  CREDENTIAL_ENCRYPTION_KEY=<hex-key>
```

### Step 5: Deploy the Client Shell

```bash
cd client-acme-shell
npm install
npm run build
# Deploy to Azure Static Web Apps
```

Set GitHub environment secrets for CI/CD:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `SWA_DEPLOYMENT_TOKEN`

### Step 6: Publish Apps to the Client

```bash
# For each app the client needs:
cd ../my-app
npm run publish-to-feed -- \
  --supabase-url https://acme-project.supabase.co \
  --service-role-key eyJ...
```

Or upload bundles via **Admin > App Management** in the portal.

### Step 7: First Admin Login

1. Navigate to the deployed portal URL
2. Sign in with Microsoft (Entra ID)
3. The first user is auto-created with `role: 'user'`
4. Manually set this user to `role: 'admin'` in Supabase:
   ```sql
   UPDATE user_profiles SET role = 'admin' WHERE email = 'admin@acme.com';
   ```
5. Refresh the portal — admin pages appear
6. Go to **Admin > Roles** — create custom roles and assign permissions

---

## Role-Based Access Control

### Overview

RBAC controls what each user can see and do in the portal. It has 4 layers:

```
Layer 1: System Role (admin/user)
  ↓
Layer 2: Custom Roles with Permission Keys
  ↓
Layer 3: Role-to-User Assignment (manual or Azure AD group)
  ↓
Layer 4: Per-User Overrides (grants/revokes)
```

### Layer 1: System Roles

Every user has a `role` in `user_profiles`: `admin` or `user`.

| Role | Access |
|------|--------|
| `admin` | Full access to everything — bypasses all permission checks. Sees all admin pages. |
| `user` | Access controlled by RBAC. Only sees apps/pages their assigned roles permit. |

### Layer 2: Permission Keys

Permission keys are Azure-style hierarchical strings:

```
apps/{app-slug}/{resource}/{action}

Format examples:
  apps/printix/*                      → Wildcard: full Printix access
  apps/printix/dashboards/read        → Specific: view dashboards only
  apps/printix/printers/manage        → Specific: manage printer configs
  apps/msr-gul/reports/view-pl        → Specific: view P&L report
```

**Wildcard `*`** matches all sub-keys. `apps/printix/*` includes `apps/printix/dashboards/read`, `apps/printix/billing/manage`, etc.

**Permission groups** organize permissions in the admin UI:
```json
{ "key": "apps/printix/dashboards/read", "label": "View Dashboards", "group": "Dashboards" }
{ "key": "apps/printix/printers/read", "label": "View Printers", "group": "Printers" }
{ "key": "apps/printix/printers/manage", "label": "Manage Printers", "group": "Printers" }
```

### Layer 3: Role Assignment

Users get roles through two mechanisms:

**Manual Assignment (Admin > Users page):**
- Admin selects a user → assigns one or more custom roles
- Stored in `user_role_assignments` with `assigned_by: 'manual'`

**Azure AD Group Auto-Sync (on every login):**
- Configure in `src/rbac.json`:
  ```json
  {
    "azGroupMappings": {
      "a1b2c3d4-e5f6-...": ["Billing Manager"],
      "g7h8i9j0-k1l2-...": ["Basic User", "Fleet Viewer"]
    },
    "defaultRole": "Basic User"
  }
  ```
- When a user logs in, `sync_az_group_roles()` checks their Azure AD group memberships
- Automatically creates/removes role assignments with `assigned_by: 'az_group'`
- Users who don't match any group get the `defaultRole`

### Layer 4: Per-User Overrides

Admins can grant or revoke specific permissions for individual users without changing their roles:

```
Admin > Users > Select user > Permission Overrides
  ✓ Grant: apps/printix/billing/manage    (extra permission)
  ✗ Revoke: apps/msr-gul/connections/manage  (removed permission)
```

Stored in `user_profiles.permission_overrides`:
```json
{
  "grants": ["apps/printix/billing/manage"],
  "revokes": ["apps/msr-gul/connections/manage"]
}
```

### How Permission Resolution Works

```
1. Get user's role assignments (manual + AZ group)
2. For each role, get role_app_permissions
3. Aggregate all permission keys into per-app map:
   { "printix": ["apps/printix/dashboards/read", "apps/printix/printers/read"],
     "msr-gul": ["apps/msr-gul/dashboard/view"] }
4. Apply per-user overrides:
   - Add grants
   - Remove revokes
5. Final permission set used for:
   - Sidebar page visibility
   - Feature gating in apps (hasPermission())
   - API access control
```

### How It Affects the UI

**Sidebar** only shows pages the user has permission for:
```
User with "Basic User" role (dashboards/read + printers/read):

  Apps
    Printix
      Dashboard     ← visible
      Printers      ← visible
      [Users]       ← hidden (no users/read)
      [Sites]       ← hidden (no sites/read)
      [Billing]     ← hidden (no billing/manage)
```

**In-app feature gating:**
```tsx
const { hasPermission } = usePermissions()

// Show/hide UI elements based on permissions
{hasPermission('apps/printix/printers/manage') && (
  <button>Edit Printer Config</button>
)}

// Check role directly
{hasRole('admin') && (
  <DangerZone />
)}
```

### Database Tables

| Table | Purpose |
|-------|---------|
| `roles` | Custom role definitions (name, description, is_system) |
| `role_app_permissions` | Permission keys assigned to each role per app |
| `user_role_assignments` | Which users have which roles (manual or az_group) |
| `app_permissions` | Permission catalog (auto-synced from app manifests) |
| `app_pages` | Page catalog with permission requirements (auto-synced) |
| `user_profiles.permission_overrides` | Per-user grants/revokes |

### Creating a Role (Admin UI)

1. Go to **Admin > Roles**
2. Click **New Role**
3. Enter name (e.g., "Billing Manager") and description
4. For each app, check the permissions to grant:
   ```
   Printix
     ☑ Dashboards > View Dashboards
     ☑ Printers > View Printers
     ☑ Billing > Billing (generate reports)
     ☐ Printers > Manage Printers
   
   Grand Unified Ledger
     ☑ Reports > View P&L
     ☑ Reports > View Balance Sheet
     ☐ Administration > Manage Connections
   ```
5. Save — the role is immediately available for assignment

---

## App Development Guide

### App-Bridge Hooks (Complete Reference)

| Hook | Returns | When to Use |
|------|---------|-------------|
| `useShellContext()` | Full `AppContext` | When you need multiple context values |
| `useAuth()` | `{ user, hasAppAccess }` | Checking who's logged in |
| `useSupabase()` | Supabase client | Querying the client shell's own Supabase |
| `useTheme()` | `{ primary, background, surface, text, textMuted }` | Programmatic theme values |
| `useToast()` | `{ showToast }` | Notifications (success/error/info/warning) |
| `usePermissions()` | `{ hasPermission, hasRole, appPermissions }` | Feature gating |
| `useCredentials()` | `{ getCredentials(appId) }` | Decrypted credentials from vault |
| `useProxyClient(fn)` | `ProxyClient` | External data access via proxy edge functions |
| `useEventBus()` | `{ emit }` | Cross-app event communication |
| `useSharedData(key)` | `{ data, setSharedData, getSharedData }` | Cross-app reactive state |
| `useExtensionSlot(name)` | `ExtensionRegistration[]` | Consume extension slots |

### The setup() Function (Runtime Loading)

Apps export a `setup()` function for the shell to call at runtime:

```tsx
// src/index.ts
import { lazy } from 'react'
import type { AppSetupFunction } from '@elasticit-llc/app-bridge'

export { default as App } from './App'  // Backward compat

export const setup: AppSetupFunction = (api) => {
  // Register pages (lazy-loaded for code splitting)
  api.registerPage('dashboard', lazy(() => import('./pages/DashboardPage')))
  api.registerPage('products', lazy(() => import('./pages/ProductsPage')))
  
  // Register extensions into named slots
  api.registerExtension('home-widgets', InventoryWidget, 10)
  
  // Subscribe to cross-app events
  api.on('tenant-changed', ({ tenantId }) => {
    console.log('Tenant switched to:', tenantId)
  })
}
```

### External Data Access (Proxy Pattern)

Apps access external data through proxy edge functions:

```tsx
// src/hooks/useMyAppProxy.ts
import { useProxyClient } from '@elasticit-llc/app-bridge'

export function useMyAppDB(): any {
  return useProxyClient('my-app-proxy')
}

// Usage in components
const db = useMyAppDB()
const { data } = await db.from('products').select('*').eq('active', true).order('name')
```

### Styling Rules

- **DO** use `shell-*` tokens for backgrounds, borders, text (consistent dark theme)
- **DO** use `brand-*` tokens for accent colors (adapts to each client's brand)
- **DO NOT** hardcode hex colors
- **DO NOT** use default Tailwind palette (`gray-*`, `zinc-*`, `slate-*`)

```tsx
// Good
<div className="bg-shell-800 border border-shell-700 text-shell-100">
  <button className="bg-brand-600 hover:bg-brand-500 text-white">Action</button>
</div>

// Bad
<div className="bg-gray-800 border border-gray-700 text-white">
  <button className="bg-blue-600">Action</button>
</div>
```

---

## App Database Management

Apps that need backend data have two options for database access. Neither requires clients to touch the Supabase dashboard directly.

### Option A: Separate Supabase Project (Proxy)

For ElasticIT-developed apps that need their own database (e.g., Printix, GUL). Data lives in a **separate Supabase project**, accessed through the **generic `app-proxy` edge function**.

**How it works:**
```
App → useProxyClient('app-proxy', { app: 'printix' })
    → POST /functions/v1/app-proxy { app: 'printix', type: 'query', table: 'px_printers', ... }
    → app-proxy reads proxy_config from apps table
    → Validates table against allowlist
    → Fetches remote Supabase client via vault secrets (printix_supabase_url)
    → Applies tenant isolation (tenant_id from client_settings)
    → Returns data
```

**Setup:** Add `proxy.json` to the app repo:

```json
{
  "vault_prefix": "printix",
  "allowed_tables": ["px_tenants", "px_printers", "printer_configs", ...],
  "allowed_rpcs": ["dashboard_kpis", "fleet", ...],
  "allowed_api_endpoints": ["printers", "users", ...],
  "write_requires_admin": false,
  "tenant_isolation": {
    "enabled": true,
    "setting_key": "printix_tenant_id",
    "column": "tenant_id"
  }
}
```

**Required vault secrets** (per client Supabase):
```sql
SELECT vault.create_secret('https://app-project.supabase.co', '{prefix}_supabase_url');
SELECT vault.create_secret('eyJ...service-role-key...', '{prefix}_service_role_key');
```

**App hook:**
```tsx
import { useProxyClient } from '@elasticit-llc/app-bridge'

export function useMyAppDB(): any {
  return useProxyClient('app-proxy', { app: 'my-app' })
}
```

### Option B: Schema Within Client's Supabase

For client-developed apps that need a few tables. The app gets its own **PostgreSQL schema** (e.g., `app_scheduling`) within the client's existing Supabase project.

**How it works:**
- App declares tables in `database.json`
- The publish script creates the schema and applies migrations
- Shell enforces standard RLS on all app tables
- App accesses tables via `supabase.schema('app_scheduling').from('appointments')`

**Setup:** Add `database.json` to the app repo:

```json
{
  "schema": "app_scheduling",
  "migrations": [
    { "version": 1, "description": "Initial schema", "up": "migrations/001_initial.sql" }
  ],
  "tables": [
    { "name": "appointments", "rls": { "read": "authenticated", "write": "authenticated" } },
    { "name": "providers", "rls": { "read": "authenticated", "write": "admin" } }
  ]
}
```

**Migration SQL** (in `migrations/001_initial.sql`):
```sql
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_name TEXT NOT NULL,
  provider_id UUID,
  scheduled_at TIMESTAMPTZ,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

**App hook:**
```tsx
import { useSupabase } from '@elasticit-llc/app-bridge'

function AppointmentList() {
  const supabase = useSupabase()
  const { data } = await supabase
    .schema('app_scheduling')
    .from('appointments')
    .select('*')
    .order('scheduled_at')
}
```

### Self-Service for Clients

Clients who want to manage their own app schemas get a **restricted database role** (`app_developer`):

- Can create schemas with `app_` prefix only
- **Cannot** touch `public` schema (shell tables), `auth`, `storage`, or `vault`
- Event trigger enforces the `app_` prefix at the PostgreSQL level

**Setup:** ElasticIT creates a Supabase user with the `app_developer` role for the client. The client then manages their own schemas via SQL or Supabase Studio.

### When to Use Which Option

| Scenario | Option |
|----------|--------|
| ElasticIT app with shared data source (e.g., Printix Cloud) | **Option A** — separate Supabase + proxy |
| ElasticIT app with its own database | **Option A** — separate Supabase + proxy |
| Client-built app needing a few tables | **Option B** — schema in client's Supabase |
| App with existing external API/backend | Neither — use `useProxyClient` to call your own API |

### Admin UI — Database Status

The App Management page shows database status badges on each app:

- **Proxy: printix** — app uses separate Supabase via vault secrets (12 tables, 10 RPCs)
- **Schema: app_scheduling** — app has its own schema (v2, 3 tables)
- **Remote v0.3.3** — app is loaded at runtime from the feed
- **DB: active** (green) / **error** (red) / **migrating** (yellow)

### Database Schema Protection

| Schema | Who Can Access | Protected By |
|--------|---------------|-------------|
| `public` (shell tables) | ElasticIT only | RLS + `app_developer` role revoked |
| `auth`, `storage`, `vault` | Supabase system only | Revoked from all app roles |
| `app_*` (app schemas) | App + authenticated users | RLS via `apply_app_rls()` |

---

## Publishing & Deployment

### Publishing an App

**Manual (for development):**
```bash
npm run build
npm run publish-to-feed -- --supabase-url <url> --service-role-key <key>
```

**Via CI (for production):**
```bash
git tag v1.0.0 && git push --tags
# GitHub Action: publish-to-feeds.yml
# Builds → uploads to each target client's Supabase Storage → updates feed
```

**Via Admin UI:**
1. Go to **Admin > App Management**
2. Find the app → click "Runtime Loading" section
3. Upload JS + CSS files
4. Set version number
5. Click "Upload & Deploy"

### Deploying a Client Shell

```bash
# Build
npm run build

# Deploy to Azure Static Web Apps
# Automatic via .github/workflows/deploy.yml on push to main
```

### Edge Function Deployment

```bash
# From the elasticit-shell repo:
SUPABASE_ACCESS_TOKEN=<token> npx supabase functions deploy <function-name> \
  --project-ref <client-project-ref> --no-verify-jwt
```

---

## Admin Portal Guide

### Admin Pages

| Page | Purpose |
|------|---------|
| **Users** | View all users, edit roles, set permission overrides |
| **Roles** | Create/edit custom roles, assign per-app permissions |
| **App Management** | View apps, edit metadata, upload bundles, toggle remote loading, database status |
| **Credential Vault** | Manage encrypted credentials (DB, API keys, OAuth2) |
| **Audit Log** | View immutable trail of all admin actions |

### App Management — What Client Admins See

Each app card shows:
- **Status badges**: Active/Disabled/Maintenance + Proxy/Schema/Remote
- **Database status**: active (green), error (red), migrating (yellow)
- **Upload section**: Upload JS + CSS bundles, set version, deploy immediately
- **Version info**: Current version, bundle URL, integrity hash

Client admins can:
- Upload new app bundles (self-service publishing)
- Enable/disable remote loading per app
- View database configuration (proxy config or schema info)
- View permission manifest

### App Management — What ElasticIT Sees

ElasticIT has the same view but across ALL client portals (via Supabase dashboard access). Additionally:
- Can modify `proxy_config` and `schema_config` directly
- Can set `db_mode`, create vault secrets
- Can override any app's status across any client
- Can view the full audit trail of publish/update/disable actions

### Credential Vault

Stores encrypted credentials (AES-256-GCM) that apps access via `useCredentials()`:

| Type | Fields |
|------|--------|
| Database | server, database, username, password, port, base_url |
| API Key | key, value, add_to (header/query), base_url |
| OAuth2 (Client Credentials) | client_id, client_secret, token_url, base_url |
| OAuth2 (Authorization Code) | auth_url, token_url, client_id, client_secret, scope |
| Bearer Token | token, base_url |

---

## Troubleshooting

### Compile-Time (Legacy) Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| Grid layouts collapse to single column | Missing `@source` directive | Add `@source "../node_modules/@elasticit-llc/{app}/dist/**/*.js"` to `src/index.css` |
| Native `<select>` options have white background | Missing `color-scheme: dark` | Add `@layer base { :root { color-scheme: dark; } }` to `src/index.css` |

### Runtime Loading Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| "App not installed" shows briefly then loads | Feed still loading when user navigates | Normal behavior — spinner shows while feed loads. If persistent, check console for `[app-loader]` errors |
| `[app-loader] Failed to fetch feed` | Feed edge function not deployed or auth failed | Deploy `app-feed` function: `npx supabase functions deploy app-feed --no-verify-jwt`. Check that `FeedLoader` runs after auth. |
| `Failed to resolve module specifier "react"` | Import map not injected | Verify `vite-plugin-shared-deps.ts` is in `vite.config.ts` plugins array. Check page source for `<script type="importmap">` |
| `does not provide an export named 'jsx'` | JSX runtime shim missing or incorrect | Ensure `public/shared/jsx-runtime-shim.js` exists and import map points `react/jsx-runtime` to it |
| `does not provide an export named 'useState'` (or `lazy`, `memo`, etc.) | React shim missing | Ensure `public/shared/react-shim.js` exists and import map points `react` to it |
| `[app-loader] Feed returned 0 remote app(s)` | No apps with `loading_mode='remote'` in DB | Set `loading_mode` to `'remote'` and `bundle_url` in the `apps` table |
| "App failed to load" error | Bundle URL invalid, CORS blocked, or module error | Check `apps.bundle_url` in DB. Bundle server must have CORS enabled. Check console for the specific import error. |
| `useShellContext must be used within ShellBridgeProvider` | Duplicate React instances | Import map must resolve `react` to shell's single copy. Check that app externalizes react in its Vite config. |

### General Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| App not visible in sidebar | Permissions not assigned or `app_pages` empty | Admin > Roles → assign app permissions. Check `app_pages` table has entries for the app. |
| Permission changes not taking effect | Browser cache | Hard refresh (Ctrl+Shift+R) or clear `staleTime` cache |
| Hooks error after app update | Version skew between shell and app | Rebuild app against latest `@elasticit-llc/app-bridge` version |
| Printer billing columns show "—" | `printer_configs` tenant_id mismatch | Verify `tenant_id` in `printer_configs` matches `printix_tenant_id` in `client_settings` |

### Import Map Shim Files

Client shells need these files in `public/shared/` for dev mode:

**`public/shared/react-shim.js`** — Re-exports React named exports:
```js
import React from '/node_modules/.vite/deps/react.js'
export default React
export const { Children, Component, Fragment, Profiler, PureComponent,
  StrictMode, Suspense, cloneElement, createContext, createElement,
  createRef, forwardRef, isValidElement, lazy, memo, startTransition,
  use, useCallback, useContext, useDebugValue, useDeferredValue,
  useEffect, useId, useImperativeHandle, useInsertionEffect,
  useLayoutEffect, useMemo, useOptimistic, useReducer, useRef,
  useState, useSyncExternalStore, useTransition, version } = React
```

**`public/shared/jsx-runtime-shim.js`** — Provides `jsx`/`jsxs` named exports:
```js
import React from '/node_modules/.vite/deps/react.js'
const { createElement, Fragment } = React
export { Fragment }
export function jsx(type, props, key) {
  if (key !== undefined) props = { ...props, key }
  return createElement(type, props)
}
export function jsxs(type, props, key) {
  if (key !== undefined) props = { ...props, key }
  return createElement(type, props)
}
```

These are only needed in **dev mode**. Production builds generate proper ESM wrappers from Vite's chunked output.
