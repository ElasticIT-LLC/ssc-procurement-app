# @elasticit-llc/ui-kit

React component library + design token system for ElasticIT client portals.

Published as **v0.5.4** to GitHub Packages.

## What's in the box

- **9 components** — `KPICard`, `DataTable`, `StatusBadge`, `Chart`, `ReportPage`, `CardContainer`, `EmptyState`, `PageHeader`, `LoadingSkeleton` — built with semantic tokens, work in dark + light modes
- **`exportCsv()`** utility
- **Token foundation** — neutral/brand/secondary palettes, typography, radii, shadows, motion, z-index
- **`brandCompiler` Vite plugin** — consumes a client's `brand.json` and emits a Tailwind v4 `@theme` block plus typed runtime config

## Install

```bash
npm install @elasticit-llc/ui-kit recharts
```

Requires `.npmrc` scoping `@elasticit-llc` to GitHub Packages:

```
@elasticit-llc:registry=https://npm.pkg.github.com
```

## Quick start (client shell)

1. Drop a `brand.json` at your client shell's repo root (see [docs/brand-json.md](docs/brand-json.md))
2. Add the Vite plugin:

   ```ts
   // vite.config.ts
   import { brandCompiler } from '@elasticit-llc/ui-kit/vite'

   export default defineConfig({
     plugins: [brandCompiler(), react(), tailwindcss()],
   })
   ```

3. Import the generated CSS in your `src/index.css`:

   ```css
   @import 'tailwindcss';
   @import './generated-brand.css';
   @source "../node_modules/@elasticit-llc/ui-kit/dist/**/*.js";
   ```

4. Use components with semantic tokens:

   ```tsx
   import { KPICard, DataTable } from '@elasticit-llc/ui-kit'

   <KPICard label="Revenue" value="$1.2M" valueColor="text-primary" />
   ```

## Docs

| Doc | What's in it |
|-----|--------------|
| [docs/app-ui-adaptation-guide.md](docs/app-ui-adaptation-guide.md) | **Start here if you're building a portal app.** Complete guide to writing apps that adapt to any client shell's UI design |
| [docs/tokens.md](docs/tokens.md) | Full token reference — primitives, semantic tokens, chrome vs content split |
| [docs/brand-json.md](docs/brand-json.md) | `brand.json` schema, full example, field-by-field reference |
| [docs/migration-guide.md](docs/migration-guide.md) | Migrating apps from legacy `shell-*` / `brand-*` / raw Tailwind palettes to semantic tokens |
| [CLAUDE.md](CLAUDE.md) | Rules, component API reference, and guidance for AI coding assistants |

## Development

```bash
npm install
npm run build      # Vite library build (ESM + CJS + types)
npm test
npm publish        # to GitHub Packages (on version bump)
```

## Architecture summary

- **Pure UI + token library** — no auth, no data fetching, no shell dependencies
- Components emit Tailwind class strings against semantic tokens; the generated CSS (from the client's `brand.json`) provides the concrete values
- Same bundle re-skins per client just by changing `brand.json`
- Supports light/dark mode via an asymmetric token split: **chrome tokens** (sidebar/topbar) stay dark always; **content tokens** flip based on the user's toggle
